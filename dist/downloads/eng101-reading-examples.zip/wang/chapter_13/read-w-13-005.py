# Instructor: Prof. Yanwei Wang
# Wang · Ch. 13 · Example 5
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

T = 100.0          # deg C
T_ambient = 25.0   # deg C
k = 0.05           # 1/s
dt = 1.0           # s
time_end = 60.0    # s

time = 0.0

while time <= time_end:
    print(f"t = {time:5.1f} s, T = {T:6.2f} deg C")

    dTdt = -k * (T - T_ambient)
    T = T + dTdt * dt
    time = time + dt
