# Instructor: Prof. Yanwei Wang
# Wang · Ch. 13 · Example 3
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

a = 2.0       # m/s^2
v = 0.0       # m/s
dt = 1.0      # s

for step in range(6):
    print(f"step = {step}, velocity = {v:.2f} m/s")
    v = v + a * dt
