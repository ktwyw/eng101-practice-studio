# Instructor: Prof. Yanwei Wang
# Wang · Ch. 13 · Example 9
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

T_initial = 100.0
T_ambient = 25.0
k = 0.05
dt = 2.0
time_end = 80.0

times = np.arange(0.0, time_end + dt, dt)
T_euler = np.zeros(len(times))
T_euler[0] = T_initial

for i in range(1, len(times)):
    T_old = T_euler[i - 1]
    dTdt = -k * (T_old - T_ambient)
    T_euler[i] = T_old + dTdt * dt

T_exact = T_ambient + (T_initial - T_ambient) * np.exp(-k * times)

error = T_euler - T_exact
max_abs_error = np.max(np.abs(error))

print(f"Maximum absolute error = {max_abs_error:.3f} deg C")

plt.plot(times, T_exact, label="Exact model")
plt.plot(times, T_euler, "o", label="Euler approximation")
plt.xlabel("Time (s)")
plt.ylabel("Temperature (deg C)")
plt.title("Euler Method Compared with Exact Cooling Model")
plt.legend()
plt.grid(True)
plt.show()
