# Instructor: Prof. Yanwei Wang
# Wang · Ch. 13 · Example 8
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

T_initial = 100.0
T_ambient = 25.0
k = 0.05
time_end = 60.0

for dt in [10.0, 5.0, 1.0, 0.5]:
    times = np.arange(0.0, time_end + dt, dt)
    temperatures = np.zeros(len(times))
    temperatures[0] = T_initial

    for i in range(1, len(times)):
        T_old = temperatures[i - 1]
        dTdt = -k * (T_old - T_ambient)
        temperatures[i] = T_old + dTdt * dt

    plt.plot(times, temperatures, label=f"dt = {dt} s")

plt.xlabel("Time (s)")
plt.ylabel("Temperature (deg C)")
plt.title("Effect of Time Step on Cooling Simulation")
plt.legend()
plt.grid(True)
plt.show()
print("Figure created")
