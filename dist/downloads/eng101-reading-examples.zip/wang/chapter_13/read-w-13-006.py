# Instructor: Prof. Yanwei Wang
# Wang · Ch. 13 · Example 6
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import matplotlib.pyplot as plt

T = 100.0
T_ambient = 25.0
k = 0.05
dt = 1.0
time_end = 60.0

time = 0.0

times = []
temperatures = []

while time <= time_end:
    times.append(time)
    temperatures.append(T)

    dTdt = -k * (T - T_ambient)
    T = T + dTdt * dt
    time = time + dt

plt.plot(times, temperatures)
plt.xlabel("Time (s)")
plt.ylabel("Temperature (deg C)")
plt.title("Cooling Simulation Using Euler Method")
plt.grid(True)
plt.show()
print("Figure created")
