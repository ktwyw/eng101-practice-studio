# Instructor: Prof. Yanwei Wang
# Wang · Ch. 13 · Example 12
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

T = 100.0
T_ambient = 25.0
k = 0.05
dt = 1.0
T_safe = 40.0

time = 0.0
max_time = 1000.0

while T > T_safe and time <= max_time:
    dTdt = -k * (T - T_ambient)
    T = T + dTdt * dt
    time = time + dt

if T <= T_safe:
    print(f"Safe temperature reached after {time:.1f} s")
else:
    print("Safe temperature was not reached within the maximum time")
