# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 14
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

mass = 1200       # kg
velocity = 20     # m/s

kinetic_energy = 0.5 * mass * velocity**2
print(f"Kinetic energy = {kinetic_energy:.1f} J")
