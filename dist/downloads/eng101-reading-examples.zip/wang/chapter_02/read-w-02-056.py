# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 56
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 8000
area = 400
stress = force / area
print(stress)
