# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 15
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

measurement_1 = 10.2
measurement_2 = 10.5
measurement_3 = 10.4

average = (measurement_1 + measurement_2 + measurement_3) / 3
print(f"Average = {average:.2f}")
