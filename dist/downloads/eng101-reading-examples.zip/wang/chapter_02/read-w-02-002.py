# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 2
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

a = 12.0
b = 4.0
c = a / b
print(c)
