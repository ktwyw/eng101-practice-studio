# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 50
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltage = 12
resistance = 4
current = voltage / resistance

# Teaching observation: expose the computed result.
print(current)
