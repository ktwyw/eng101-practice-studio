# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 38
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

current_a = 3.0
print(f"Current = {current_a} A")
