# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 54
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

stress_mpa = 20
print(f"Stress = {stress_mpa} MPa")
