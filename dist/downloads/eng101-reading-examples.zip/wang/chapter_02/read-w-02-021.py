# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 21
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force_n = 8000               # N
area_mm2 = 400               # mm^2
area_m2 = area_mm2 / 1_000_000

stress_pa = force_n / area_m2
stress_mpa = stress_pa / 1_000_000

print(f"Force = {force_n:.1f} N")
print(f"Area = {area_mm2:.1f} mm^2")
print(f"Stress = {stress_mpa:.2f} MPa")
