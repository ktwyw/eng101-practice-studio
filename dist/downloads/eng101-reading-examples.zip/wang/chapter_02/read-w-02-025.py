# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 25
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material = "steel"
density_kg_m3 = 7850

print(material)
print(f"Density of {material} = {density_kg_m3} kg/m^3")
