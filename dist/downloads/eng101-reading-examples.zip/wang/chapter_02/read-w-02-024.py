# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 24
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material = "aluminum"
unit = 'MPa'
message = "Engineering report"

# Teaching observation: expose the computed result.
print(message)
