# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 30
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

stress_mpa = 120
allowable_stress_mpa = 150

is_within_limit = stress_mpa <= allowable_stress_mpa

print(is_within_limit)
print(type(is_within_limit))
