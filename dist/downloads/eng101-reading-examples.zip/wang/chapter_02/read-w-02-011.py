# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 11
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

yield_strength_pa = 250_000_000
population = 1_250_000

# Teaching observation: expose the computed result.
print(population)
