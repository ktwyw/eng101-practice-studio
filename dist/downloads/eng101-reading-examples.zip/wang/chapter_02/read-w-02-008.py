# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 8
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

number_of_bolts = 8
beam_length_m = 2.5

a = type(number_of_bolts)
b = type(beam_length_m)

print(a)
print(b)
