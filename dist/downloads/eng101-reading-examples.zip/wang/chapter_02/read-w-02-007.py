# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 7
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

beam_length_m = 2.5
applied_force_n = 1000
cross_section_area_m2 = 0.0004

# Teaching observation: expose the computed result.
print(cross_section_area_m2)
