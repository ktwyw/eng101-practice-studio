# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 18
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltage_v = 12.0
resistance_ohm = 4.0

power_w = voltage_v**2 / resistance_ohm
print(f"Power = {power_w:.2f} W")
