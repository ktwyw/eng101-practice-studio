# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 10
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

stress_pa = 125e6
stress_mpa = stress_pa / 1e6
print(stress_mpa)
