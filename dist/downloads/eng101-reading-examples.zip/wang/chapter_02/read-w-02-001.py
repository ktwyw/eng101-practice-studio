# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltage = 12.0       # V
resistance = 4.0     # ohm
current = voltage / resistance

print(current)
