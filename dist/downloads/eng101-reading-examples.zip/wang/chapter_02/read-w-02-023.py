# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 23
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature_c = 25.0
temperature_k = temperature_c + 273.15

print(f"Temperature = {temperature_c:.2f} deg C")
print(f"Temperature = {temperature_k:.2f} K")
