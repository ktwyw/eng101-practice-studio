# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 19
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force_n = 5000
area_m2 = 0.002
change_in_length_m = 0.001
original_length_m = 2.0

stress_pa = force_n / area_m2
strain = change_in_length_m / original_length_m

print(f"Stress = {stress_pa:.2f} Pa")
print(f"Strain = {strain:.6f}")
