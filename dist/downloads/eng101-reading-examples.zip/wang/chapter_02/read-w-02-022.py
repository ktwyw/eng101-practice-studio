# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 22
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

length_mm = 500
length_m = length_mm / 1000

area_mm2 = 400
area_m2 = area_mm2 / 1_000_000

volume_mm3 = 2_000_000
volume_m3 = volume_mm3 / 1_000_000_000

print(f"Length = {length_m:.3f} m")
print(f"Area = {area_m2:.6f} m^2")
print(f"Volume = {volume_m3:.6f} m^3")
