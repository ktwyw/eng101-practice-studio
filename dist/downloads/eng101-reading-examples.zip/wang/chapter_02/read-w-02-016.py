# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 16
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltage_v = 12.0
resistance_ohm = 4.0

current_a = voltage_v / resistance_ohm
print(f"Current = {current_a:.3f} A")
