# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 29
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material = "  Aluminum  "

clean_material = material.strip()
lower_material = clean_material.lower()
upper_material = clean_material.upper()

print(clean_material)
print(lower_material)
print(upper_material)
