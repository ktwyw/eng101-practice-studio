# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 44
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force_n = 8000
area_mm2 = 400

# Teaching observation: expose the computed result.
print(area_mm2)
