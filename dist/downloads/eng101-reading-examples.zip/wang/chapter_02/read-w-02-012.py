# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 12
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

result = 0.1 + 0.2
print(result)
