# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 26
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

first = "Engineering"
second = "Computation"
course_name = first + " " + second

print(course_name)
