# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 20
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

load_intensity_n_per_m = 800     # N/m
beam_length_m = 3.0              # m

total_load_n = load_intensity_n_per_m * beam_length_m
reaction_a_n = total_load_n / 2
reaction_b_n = total_load_n / 2

print(f"Total load = {total_load_n:.1f} N")
print(f"Reaction at A = {reaction_a_n:.1f} N")
print(f"Reaction at B = {reaction_b_n:.1f} N")
