# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 28
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material = "aluminum"
print(len(material))
