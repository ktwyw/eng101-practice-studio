# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 40
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltage_v = 12.0

resistance_1_ohm = 2.0
current_1_a = voltage_v / resistance_1_ohm

resistance_2_ohm = 4.0
current_2_a = voltage_v / resistance_2_ohm

resistance_3_ohm = 8.0
current_3_a = voltage_v / resistance_3_ohm

print("OHM'S LAW DESIGN TABLE")
print("-" * 36)
print(f"{'Resistance (ohm)':>18} {'Current (A)':>14}")
print(f"{resistance_1_ohm:18.2f} {current_1_a:14.3f}")
print(f"{resistance_2_ohm:18.2f} {current_2_a:14.3f}")
print(f"{resistance_3_ohm:18.2f} {current_3_a:14.3f}")
