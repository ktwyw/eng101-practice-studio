# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 4
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature = 20
print(temperature)

temperature = temperature + 5
print(temperature)
