# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 57
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force_n = 8000
area_mm2 = 400
area_m2 = area_mm2 / 1_000_000

stress_pa = force_n / area_m2
stress_mpa = stress_pa / 1_000_000

print(f"Stress = {stress_mpa:.2f} MPa")
