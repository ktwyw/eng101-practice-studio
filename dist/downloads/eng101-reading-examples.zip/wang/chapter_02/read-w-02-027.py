# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 27
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

print("-" * 30)
print("OHM'S LAW REPORT")
print("-" * 30)
