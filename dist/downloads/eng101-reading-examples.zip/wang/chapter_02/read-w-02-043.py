# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 43
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material = "aluminum"

density_kg_m3 = 2700
elastic_modulus_gpa = 69

density_g_cm3 = density_kg_m3 / 1000
elastic_modulus_pa = elastic_modulus_gpa * 1e9

print("MATERIAL PROPERTY REPORT")
print("-" * 32)
print(f"Material:        {material}")
print(f"Density:         {density_kg_m3:.0f} kg/m^3")
print(f"Density:         {density_g_cm3:.2f} g/cm^3")
print(f"Elastic modulus: {elastic_modulus_gpa:.1f} GPa")
print(f"Elastic modulus: {elastic_modulus_pa:.3e} Pa")
