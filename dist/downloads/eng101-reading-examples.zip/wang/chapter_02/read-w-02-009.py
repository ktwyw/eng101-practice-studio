# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 9
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

yield_strength_pa = 250e6       # 250,000,000 Pa
area_m2 = 4.0e-4                # 0.0004 m^2
speed_of_light = 3.0e8          # m/s

# Teaching observation: expose the computed result.
print(speed_of_light)
