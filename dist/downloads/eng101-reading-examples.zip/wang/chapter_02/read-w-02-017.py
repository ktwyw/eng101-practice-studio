# Instructor: Prof. Yanwei Wang
# Wang · Ch. 2 · Example 17
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltage_v = 12.0
current_a = 3.0

power_w = voltage_v * current_a
print(f"Power = {power_w:.2f} W")
