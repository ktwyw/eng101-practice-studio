# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 11
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 5000      # N
area = 0.002      # m^2

stress = force / area

print(f"Stress = {stress:.2f} Pa")
