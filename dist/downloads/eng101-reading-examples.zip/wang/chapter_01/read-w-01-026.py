# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 26
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

x = 5000
y = 0.002
z = x / y

# Teaching observation: expose the computed result.
print(z)
