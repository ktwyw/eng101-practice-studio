# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 9
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

a = 5000
b = 0.002
c = a / b

# Teaching observation: expose the computed result.
print(c)
