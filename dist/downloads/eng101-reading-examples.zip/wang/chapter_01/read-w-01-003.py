# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 3
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

speed = 20       # m/s
time = 15        # s

distance = speed * time

print(distance)
