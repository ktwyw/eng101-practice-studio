# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 12
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 5000      # N
area = 0.002      # m^2

stress_pa = force / area
stress_mpa = stress_pa / 1_000_000

print(f"Stress = {stress_pa:.2f} Pa")
print(f"Stress = {stress_mpa:.2f} MPa")
