# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 15
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

power_w = 1500              # W
power_kw = power_w / 1000   # kW

time_h = 2                  # h
cost_per_kwh = 0.12         # dollars/kWh

energy_kwh = power_kw * time_h
cost = energy_kwh * cost_per_kwh

print(f"Energy used = {energy_kwh:.2f} kWh")
print(f"Cost = ${cost:.2f}")
