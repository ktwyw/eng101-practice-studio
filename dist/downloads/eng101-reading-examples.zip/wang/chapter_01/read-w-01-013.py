# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 13
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

area_mm2 = 2000
area_m2 = area_mm2 / 1_000_000

print(f"Area = {area_m2:.6f} m^2")
