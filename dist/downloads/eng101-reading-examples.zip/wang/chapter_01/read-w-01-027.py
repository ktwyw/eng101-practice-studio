# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 27
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

time_s = 10       # seconds
voltage_v = 12    # volts

# Teaching observation: expose the computed result.
print(voltage_v)
