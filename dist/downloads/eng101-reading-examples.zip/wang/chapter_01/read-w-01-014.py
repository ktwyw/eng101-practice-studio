# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 14
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 5000          # N
area_mm2 = 2000       # mm^2

area_m2 = area_mm2 / 1_000_000
stress_pa = force / area_m2
stress_mpa = stress_pa / 1_000_000

print(f"Stress = {stress_mpa:.2f} MPa")
