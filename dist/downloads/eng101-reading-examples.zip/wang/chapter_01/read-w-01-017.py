# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 17
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

mass_kg = 70
height_m = 1.75

bmi = mass_kg / height_m**2

print(f"BMI = {bmi:.1f}")
