# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 8
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 5000
area = 0.002
stress = force / area

# Teaching observation: expose the computed result.
print(stress)
