# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 16
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

power_w = 1500       # W = J/s
time_h = 2           # h

time_s = time_h * 3600
energy_j = power_w * time_s

print(f"Energy used = {energy_j:.0f} J")
