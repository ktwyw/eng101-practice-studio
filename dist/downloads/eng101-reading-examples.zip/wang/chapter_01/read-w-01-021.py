# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 21
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 10
area = 2
stress = force / area

print(stress)
