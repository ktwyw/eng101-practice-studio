# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 24
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 10000                 # N
area = 0.0005                 # m^2
change_in_length = 0.001      # m
original_length = 2.0         # m
material_strength = 250e6     # Pa

stress_pa = force / area
stress_mpa = stress_pa / 1_000_000

strain = change_in_length / original_length
factor_of_safety = material_strength / stress_pa

print("ENGINEERING CALCULATION REPORT")
print("------------------------------")
print(f"Force: {force:.0f} N")
print(f"Area: {area:.6f} m^2")
print(f"Stress: {stress_pa:.2f} Pa")
print(f"Stress: {stress_mpa:.2f} MPa")
print(f"Strain: {strain:.6f}")
print(f"Factor of Safety: {factor_of_safety:.2f}")
