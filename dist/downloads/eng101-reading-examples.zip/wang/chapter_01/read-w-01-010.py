# Instructor: Prof. Yanwei Wang
# Wang · Ch. 1 · Example 10
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 5000
Force = 7000

print(force)
print(Force)
