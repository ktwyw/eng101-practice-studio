# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 12
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def f(x):
    return x**2 - 9

low = 0
high = 5
tolerance = 1e-6
max_iterations = 100

for iteration in range(max_iterations):
    mid = (low + high) / 2

    if abs(f(mid)) < tolerance:
        break

    if f(low) * f(mid) < 0:
        high = mid
    else:
        low = mid

print(f"Root = {mid:.8f}")
print(f"f(root) = {f(mid):.3e}")
print(f"Iterations = {iteration + 1}")
