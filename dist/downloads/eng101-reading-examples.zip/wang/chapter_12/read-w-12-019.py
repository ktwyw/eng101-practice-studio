# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 19
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

from scipy.optimize import root_scalar

def f(x):
    return x**2 - 9

solution = root_scalar(f, bracket=[0, 5], method="bisect")

print(solution.root)
print(solution.iterations)
print(solution.converged)
