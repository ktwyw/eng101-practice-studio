# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 7
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def f(x):
    return x**2 - 9

step = 0.1
tolerance = 0.05
x = 0

while x <= 5:
    if abs(f(x)) < tolerance:
        print(f"Found approximate root: x = {x:.2f}")
        break
    x = x + step
