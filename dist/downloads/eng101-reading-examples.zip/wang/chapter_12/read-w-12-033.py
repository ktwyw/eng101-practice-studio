# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 33
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

temperature = np.array([20, 30, 40, 50, 60])
voltage = np.array([0.48, 0.74, 1.01, 1.29, 1.55])

# Teaching observation: expose the computed result.
print(voltage)
