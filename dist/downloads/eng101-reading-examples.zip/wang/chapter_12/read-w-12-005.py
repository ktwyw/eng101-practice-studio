# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 5
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def f(x):
    return x**2 - 9

x = 2.99
if abs(f(x)) < 0.1:
    print("Close enough for this tolerance")
else:
    print("Not close enough")
