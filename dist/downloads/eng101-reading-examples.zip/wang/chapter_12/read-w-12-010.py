# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 10
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def f(x):
    return x**2 - 9

low = 0
high = 5

for step in range(30):
    mid = (low + high) / 2

    if f(low) * f(mid) <= 0:
        high = mid
    else:
        low = mid

root = (low + high) / 2
print(f"Root is approximately {root:.6f}")
print(f"f(root) = {f(root):.6e}")
