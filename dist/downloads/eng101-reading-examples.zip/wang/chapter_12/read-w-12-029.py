# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 29
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

strain = np.array([0.0000, 0.0005, 0.0010, 0.0015, 0.0020])
stress_mpa = np.array([0, 101, 198, 304, 397])

coefficients = np.polyfit(strain, stress_mpa, 1)
fit_line = np.poly1d(coefficients)

strain_smooth = np.linspace(strain.min(), strain.max(), 100)
stress_fit = fit_line(strain_smooth)

plt.scatter(strain, stress_mpa, label="Measured data")
plt.plot(strain_smooth, stress_fit, label="Best-fit line")
plt.xlabel("Strain")
plt.ylabel("Stress (MPa)")
plt.title("Stress-Strain Linear Fit")
plt.grid(True)
plt.legend()
plt.show()
print("Figure created")
