# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 8
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def f(x):
    return x**2 - 9

low = 0
high = 5

print(f(low))
print(f(high))
print(f(low) * f(high))
