# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def f(x):
    return x**2 - 9

print(f(-3))
print(f(3))
print(f(2))
