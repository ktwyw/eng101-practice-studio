# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 25
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

strain = np.array([0.0000, 0.0005, 0.0010, 0.0015, 0.0020])
stress_mpa = np.array([0, 101, 198, 304, 397])

coefficients = np.polyfit(strain, stress_mpa, 1)
slope = coefficients[0]
intercept = coefficients[1]

print(f"Slope = {slope:.1f} MPa")
print(f"Intercept = {intercept:.2f} MPa")
