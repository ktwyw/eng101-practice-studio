# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 20
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def linear_interpolate(x, x1, y1, x2, y2):
    return y1 + (x - x1) / (x2 - x1) * (y2 - y1)

voltage = 1.25
temperature = linear_interpolate(voltage, 1.0, 40, 1.5, 60)

print(f"Estimated temperature = {temperature:.1f} deg C")
