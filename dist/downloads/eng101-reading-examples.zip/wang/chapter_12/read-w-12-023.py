# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 23
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

voltages = np.array([0.5, 1.0, 1.5, 2.0])
temperatures = np.array([20, 40, 60, 80])

query_voltages = np.array([0.75, 1.25, 1.75])
query_temperatures = np.interp(query_voltages, voltages, temperatures)

for V, T in zip(query_voltages, query_temperatures):
    print(f"Voltage = {V:.2f} V, estimated T = {T:.1f} deg C")
