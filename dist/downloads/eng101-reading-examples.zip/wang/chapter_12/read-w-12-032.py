# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 32
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

x = np.array([0, 1, 2, 3, 4, 5])
y = np.array([2.1, 2.9, 6.2, 10.8, 18.1, 27.4])

coefficients = np.polyfit(x, y, 2)
model = np.poly1d(coefficients)

print(coefficients)
print(model(2.5))
