# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 22
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

voltages = np.array([0.5, 1.0, 1.5, 2.0])
temperatures = np.array([20, 40, 60, 80])

voltage_query = 1.25
temperature_query = np.interp(voltage_query, voltages, temperatures)

print(f"Estimated temperature = {temperature_query:.1f} deg C")
