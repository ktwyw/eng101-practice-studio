# Instructor: Prof. Yanwei Wang
# Wang · Ch. 12 · Example 3
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def f(x):
    return x**2 - 9

guesses = [1, 2, 2.5, 2.9, 3.0, 3.1]

for x in guesses:
    print(f"x = {x:4.1f}, f(x) = {f(x):7.3f}")
