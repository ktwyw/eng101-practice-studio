# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 21
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def calculate_power(voltage, current):
    power = voltage * current
    return power


p = calculate_power(12, 3)
print(p)
