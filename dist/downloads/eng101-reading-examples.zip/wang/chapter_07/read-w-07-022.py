# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 22
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def calculate_current(voltage, resistance):
    return voltage / resistance


def calculate_power(voltage, current):
    return voltage * current


current = calculate_current(12, 4)
power = calculate_power(12, current)

print(f"Current = {current:.2f} A")
print(f"Power = {power:.2f} W")
