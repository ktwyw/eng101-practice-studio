# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 40
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def correct_temperature_readings(readings, offset):
    corrected = []

    for reading in readings:
        corrected.append(reading - offset)

    return corrected


raw_readings = [22.3, 22.5, 22.8, 23.0]
corrected_readings = correct_temperature_readings(raw_readings, offset=0.2)

print(corrected_readings)
