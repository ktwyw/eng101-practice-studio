# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 41
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np


def calculate_stress(force, area):
    return force / area


areas = np.array([100, 200, 300, 400]) / 1e6   # convert mm^2 to m^2
force = 8000

stresses = calculate_stress(force, areas)
print(stresses / 1e6)
