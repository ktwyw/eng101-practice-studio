# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 15
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def calculate_stress(force, area):
    return force / area


stress = calculate_stress(5000, 0.002)

# Teaching observation: expose the computed result.
print(stress)
