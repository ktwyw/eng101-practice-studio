# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 38
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def calculate_average(values):
    total = sum(values)
    average = total / len(values)
    return average


readings = [22.1, 22.4, 22.8, 23.0, 23.2]
average_temperature = calculate_average(readings)

print(f"Average temperature = {average_temperature:.2f} C")
