# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 44
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def projectile_state(time, initial_height, initial_velocity, gravity=9.81):
    height = initial_height + initial_velocity * time - 0.5 * gravity * time**2
    velocity = initial_velocity - gravity * time
    return height, velocity


height, velocity = projectile_state(3.0, initial_height=20.0, initial_velocity=15.0)

print(f"Height = {height:.2f} m")
print(f"Velocity = {velocity:.2f} m/s")
