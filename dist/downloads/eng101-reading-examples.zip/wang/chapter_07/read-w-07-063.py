# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 63
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)


print(factorial(5))
