# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 18
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def calculate_reynolds_number(density, velocity, diameter, viscosity):
    return density * velocity * diameter / viscosity


re = calculate_reynolds_number(
    density=1000,
    velocity=2.0,
    diameter=0.05,
    viscosity=0.001
)

print(re)
