# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 39
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def calculate_rms(values):
    total_square = 0

    for value in values:
        total_square = total_square + value**2

    mean_square = total_square / len(values)
    rms = mean_square**0.5
    return rms


voltages = [1.2, 1.4, 1.1, 1.3]
print(f"RMS voltage = {calculate_rms(voltages):.3f} V")
