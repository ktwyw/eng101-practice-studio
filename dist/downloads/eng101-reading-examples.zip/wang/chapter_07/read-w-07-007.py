# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 7
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def calculate_stress(force, area):
    stress = force / area
    return stress


result = calculate_stress(5000, 0.002)
print(result)
