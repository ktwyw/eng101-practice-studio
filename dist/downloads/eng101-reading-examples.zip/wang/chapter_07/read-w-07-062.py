# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 62
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def convert_mm2_to_m2(area_mm2):
    """Return area in m^2 from area in mm^2."""
    return area_mm2 / 1e6


def calculate_stress(force, area):
    """Return normal stress in Pa from force in N and area in m^2."""
    return force / area


def calculate_factor_of_safety(strength, stress):
    """Return factor of safety from material strength and stress."""
    return strength / stress


def classify_design(factor_of_safety, required_fos=2.0):
    """Return design status based on required factor of safety."""
    if factor_of_safety >= required_fos:
        return "ACCEPTABLE"
    else:
        return "NOT ACCEPTABLE"


def print_design_report(force, area_mm2, strength, required_fos):
    """Print a design report for an axially loaded bar."""
    area_m2 = convert_mm2_to_m2(area_mm2)
    stress = calculate_stress(force, area_m2)
    fos = calculate_factor_of_safety(strength, stress)
    status = classify_design(fos, required_fos)

    print("BAR DESIGN REPORT")
    print("-----------------")
    print(f"Force:              {force:.2f} N")
    print(f"Area:               {area_mm2:.2f} mm^2")
    print(f"Stress:             {stress / 1e6:.2f} MPa")
    print(f"Material strength:  {strength / 1e6:.2f} MPa")
    print(f"Factor of safety:   {fos:.2f}")
    print(f"Required FoS:       {required_fos:.2f}")
    print(f"Design status:      {status}")


print_design_report(
    force=10000,
    area_mm2=500,
    strength=250e6,
    required_fos=2.0
)
