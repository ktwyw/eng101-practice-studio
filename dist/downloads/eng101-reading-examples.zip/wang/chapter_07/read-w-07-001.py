# Instructor: Prof. Yanwei Wang
# Wang · Ch. 7 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 5000
area = 0.002
stress = force / area

strength = 250e6
factor_of_safety = strength / stress

voltage = 12
resistance = 4
current = voltage / resistance

# Teaching observation: expose the computed result.
print(current)
