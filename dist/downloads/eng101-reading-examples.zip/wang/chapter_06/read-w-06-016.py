# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 16
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import matplotlib.pyplot as plt

voltage = [0, 1, 2, 3, 4, 5]
current = [0.00, 0.10, 0.20, 0.30, 0.40, 0.50]

plt.plot(voltage, current, marker="o")
plt.xlabel("Voltage (V)")
plt.ylabel("Current (A)")
plt.title("Current-Voltage Curve")
plt.grid(True)
plt.show()
print("Figure created")
