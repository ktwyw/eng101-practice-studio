# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 20
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

frequency = np.array([1, 10, 100, 1000, 10000])
gain = np.array([1.0, 0.98, 0.70, 0.12, 0.01])

plt.semilogx(frequency, gain, marker="o")
plt.xlabel("Frequency (Hz)")
plt.ylabel("Gain (-)")
plt.title("Gain versus Frequency")
plt.grid(True)
plt.show()
print("Figure created")
