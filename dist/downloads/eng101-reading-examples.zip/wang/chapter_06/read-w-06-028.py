# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 28
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import matplotlib.pyplot as plt

materials = ["Aluminum", "Steel", "Copper", "Titanium"]
density = [2700, 7850, 8960, 4500]

plt.bar(materials, density)
plt.xlabel("Material")
plt.ylabel("Density (kg/m^3)")
plt.title("Density of Selected Materials")
plt.grid(axis="y")
plt.show()
print("Figure created")
