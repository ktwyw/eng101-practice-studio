# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 6
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import matplotlib.pyplot as plt

h0 = 100.0
g = 9.81

time = [0, 1, 2, 3, 4]
height = []

for t in time:
    h = h0 - 0.5 * g * t**2
    height.append(h)

plt.plot(time, height)
plt.xlabel("Time (s)")
plt.ylabel("Height (m)")
plt.title("Height of a Falling Object")
plt.grid(True)
plt.show()
print("Figure created")
