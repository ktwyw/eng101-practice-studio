# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 23
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt


time = np.linspace(0, 10, 100)
velocity = 9.81 * time

plt.figure(figsize=(7, 4))
plt.plot(time, velocity)
plt.xlabel("Time (s)")
plt.ylabel("Velocity (m/s)")
plt.title("Velocity-Time Graph")
plt.grid(True)
plt.savefig("velocity_time_graph.png", dpi=300, bbox_inches="tight")
plt.show()
print("Figure created")
