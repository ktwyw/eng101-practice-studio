# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 24
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

force = 5000.0  # N
area_mm2 = np.array([100, 150, 200, 250, 300, 350, 400])
area_m2 = area_mm2 / 1_000_000

stress_pa = force / area_m2
stress_mpa = stress_pa / 1_000_000

plt.plot(area_mm2, stress_mpa, marker="o")
plt.xlabel("Area (mm^2)")
plt.ylabel("Stress (MPa)")
plt.title("Stress versus Cross-Sectional Area")
plt.grid(True)
plt.show()
print("Figure created")
