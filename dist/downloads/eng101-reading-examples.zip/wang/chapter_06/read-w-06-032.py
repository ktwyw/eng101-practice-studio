# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 32
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

force = 6000.0  # N
area_mm2 = np.array([150, 200, 250, 300, 350, 400, 450])
allowable_stress_mpa = 30.0

area_m2 = area_mm2 / 1_000_000
stress_pa = force / area_m2
stress_mpa = stress_pa / 1_000_000

safe = stress_mpa <= allowable_stress_mpa

print("Area (mm^2)   Stress (MPa)   Safe?")
print("-------------------------------------")

for area, stress, is_safe in zip(area_mm2, stress_mpa, safe):
    if is_safe:
        status = "yes"
    else:
        status = "no"
    print(f"{area:10.0f}   {stress:12.2f}   {status}")

plt.plot(area_mm2, stress_mpa, marker="o", label="Calculated stress")
plt.axhline(allowable_stress_mpa, linestyle="--", label="Allowable stress")

plt.xlabel("Area (mm^2)")
plt.ylabel("Stress (MPa)")
plt.title("Stress versus Area Design Check")
plt.grid(True)
plt.legend()
plt.show()
