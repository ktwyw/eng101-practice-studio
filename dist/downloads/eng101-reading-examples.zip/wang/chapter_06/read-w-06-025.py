# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 25
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

force = 5000.0
area_mm2 = np.array([100, 150, 200, 250, 300, 350, 400])
area_m2 = area_mm2 / 1_000_000
stress_mpa = (force / area_m2) / 1_000_000

allowable_stress = 25.0

plt.plot(area_mm2, stress_mpa, marker="o", label="Calculated stress")
plt.axhline(allowable_stress, linestyle="--", label="Allowable stress")

plt.xlabel("Area (mm^2)")
plt.ylabel("Stress (MPa)")
plt.title("Stress Design Check")
plt.grid(True)
plt.legend()
plt.show()
print("Figure created")
