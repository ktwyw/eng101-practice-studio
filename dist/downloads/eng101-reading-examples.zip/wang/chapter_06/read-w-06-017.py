# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 17
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

T0 = 100.0
T_ambient = 25.0
k = 0.04

time = np.linspace(0, 120, 200)
temperature = T_ambient + (T0 - T_ambient) * np.exp(-k * time)

plt.plot(time, temperature)
plt.xlabel("Time (s)")
plt.ylabel("Temperature (C)")
plt.title("Cooling of a Hot Object")
plt.grid(True)
plt.show()
print("Figure created")
