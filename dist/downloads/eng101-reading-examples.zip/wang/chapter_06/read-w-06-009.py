# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 9
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import matplotlib.pyplot as plt

voltage = [0, 1, 2, 3, 4]
current = [0.00, 0.21, 0.39, 0.61, 0.79]

plt.scatter(voltage, current)
plt.xlabel("Voltage (V)")
plt.ylabel("Current (A)")
plt.title("Current-Voltage Measurements")
plt.grid(True)
plt.show()
print("Figure created")
