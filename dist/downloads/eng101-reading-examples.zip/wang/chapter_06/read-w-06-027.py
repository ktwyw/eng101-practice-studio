# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 27
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt


time = np.linspace(0, 10, 100)
acceleration = 2.0
velocity = acceleration * time
displacement = 0.5 * acceleration * time**2

fig, axes = plt.subplots(2, 1, figsize=(7, 6))

axes[0].plot(time, displacement)
axes[0].set_ylabel("Displacement (m)")
axes[0].set_title("Motion with Constant Acceleration")
axes[0].grid(True)

axes[1].plot(time, velocity)
axes[1].set_xlabel("Time (s)")
axes[1].set_ylabel("Velocity (m/s)")
axes[1].grid(True)

plt.tight_layout()
plt.show()
print("Figure created")
