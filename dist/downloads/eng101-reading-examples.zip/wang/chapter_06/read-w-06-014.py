# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 14
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

g = 9.81

time_model = np.linspace(0, 5, 100)
velocity_model = g * time_model

time_measured = [0, 1, 2, 3, 4, 5]
velocity_measured = [0.1, 9.5, 19.9, 29.0, 39.7, 48.8]

plt.plot(time_model, velocity_model, label="Model")
plt.scatter(time_measured, velocity_measured, label="Measurements")

plt.xlabel("Time (s)")
plt.ylabel("Velocity (m/s)")
plt.title("Model and Measured Velocity")
plt.grid(True)
plt.legend()
plt.show()
print("Figure created")
