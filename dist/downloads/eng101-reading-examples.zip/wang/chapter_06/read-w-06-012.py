# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 12
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

h0 = 100.0
g = 9.81

time = np.linspace(0, 5, 100)
height = h0 - 0.5 * g * time**2

plt.plot(time, height)
plt.xlabel("Time (s)")
plt.ylabel("Height (m)")
plt.title("Falling Object Model")
plt.grid(True)
plt.show()
print("Figure created")
