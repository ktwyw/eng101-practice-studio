# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 26
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 10, 100)
y = -0.5 * (x - 5)**2 + 25

plt.plot(x, y)
plt.xlabel("Design variable")
plt.ylabel("Performance")
plt.title("Performance versus Design Variable")
plt.grid(True)

plt.annotate("maximum performance", xy=(5, 25), xytext=(6, 22),
             arrowprops={"arrowstyle": "->"})

plt.show()
print("Figure created")
