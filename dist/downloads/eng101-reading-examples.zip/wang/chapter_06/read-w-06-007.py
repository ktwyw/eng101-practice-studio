# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 7
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import matplotlib.pyplot as plt

time = [0, 1, 2, 3, 4, 5]
velocity = [0.0, 1.8, 3.9, 5.7, 7.8, 9.6]

plt.plot(time, velocity, marker="o")
plt.xlabel("Time (s)")
plt.ylabel("Velocity (m/s)")
plt.title("Measured Velocity Data")
plt.grid(True)
plt.show()
print("Figure created")
