# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 10
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

g = 9.81

time = np.linspace(0, 10, 100)
velocity = g * time

plt.plot(time, velocity)
plt.xlabel("Time (s)")
plt.ylabel("Velocity (m/s)")
plt.title("Velocity for Constant Acceleration")
plt.grid(True)
plt.show()
print("Figure created")
