# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 15
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import matplotlib.pyplot as plt

strain = [0.0000, 0.0005, 0.0010, 0.0015, 0.0020, 0.0025]
stress = [0, 100, 200, 300, 390, 460]  # MPa

plt.plot(strain, stress, marker="o")
plt.xlabel("Strain (-)")
plt.ylabel("Stress (MPa)")
plt.title("Stress-Strain Curve")
plt.grid(True)
plt.show()
print("Figure created")
