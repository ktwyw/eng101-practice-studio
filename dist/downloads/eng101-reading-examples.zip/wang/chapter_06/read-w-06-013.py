# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 13
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

time = np.linspace(0, 10, 100)

a1 = 2.0
a2 = 4.0
a3 = 6.0

v1 = a1 * time
v2 = a2 * time
v3 = a3 * time

plt.plot(time, v1, label="a = 2.0 m/s^2")
plt.plot(time, v2, label="a = 4.0 m/s^2")
plt.plot(time, v3, label="a = 6.0 m/s^2")

plt.xlabel("Time (s)")
plt.ylabel("Velocity (m/s)")
plt.title("Velocity for Different Accelerations")
plt.grid(True)
plt.legend()
plt.show()
print("Figure created")
