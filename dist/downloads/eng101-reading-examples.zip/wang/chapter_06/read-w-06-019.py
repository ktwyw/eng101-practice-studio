# Instructor: Prof. Yanwei Wang
# Wang · Ch. 6 · Example 19
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np
import matplotlib.pyplot as plt

time = np.linspace(0, 10, 100)
velocity = 9.81 * time

plt.plot(time, velocity)
plt.xlabel("Time (s)")
plt.ylabel("Velocity (m/s)")
plt.title("Velocity-Time Graph")
plt.xlim(0, 10)
plt.ylim(0, 100)
plt.grid(True)
plt.show()
print("Figure created")
