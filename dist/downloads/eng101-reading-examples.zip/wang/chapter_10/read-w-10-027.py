# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 27
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

densities = [7850, 2700, 8960, 4500]
densities.sort()
print(densities)
