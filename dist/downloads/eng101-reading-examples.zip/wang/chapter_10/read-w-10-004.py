# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 4
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperatures = [42.1, 45.3, 49.8, 53.2, 58.7, 62.4, 66.1]
limit = 60.0

for index, temperature in enumerate(temperatures):
    if temperature > limit:
        print(f"First unsafe reading at index {index}")
        print(f"Temperature = {temperature:.1f} C")
        break
