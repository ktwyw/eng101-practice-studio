# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 15
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltages = [4.98, 5.01, 5.03, 4.99, 5.00]
target = 5.0
tolerance = 0.02

for index, voltage in enumerate(voltages):
    if abs(voltage - target) <= tolerance:
        print(f"Voltage near target found at index {index}")
        print(f"Voltage = {voltage:.2f} V")
        break
