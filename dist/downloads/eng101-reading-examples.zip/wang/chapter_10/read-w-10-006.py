# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 6
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 12000             # N
allowable_stress = 80e6   # Pa
areas = [50e-6, 75e-6, 100e-6, 125e-6, 150e-6]  # m^2

for area in areas:
    stress = force / area

    if stress <= allowable_stress:
        print(f"Selected area = {area:.6f} m^2")
        print(f"Stress = {stress / 1e6:.2f} MPa")
        break
