# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 8
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

materials = ["steel", "aluminum", "copper", "titanium"]
query = "Steel"

if query in materials:
    print("Found")
else:
    print("Not found")
