# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 44
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

designs = [
    {"name": "A", "mass_kg": 3.5, "cost_USD": 180, "stress_MPa": 140, "yield_MPa": 250},
    {"name": "B", "mass_kg": 4.2, "cost_USD": 160, "stress_MPa": 100, "yield_MPa": 250},
    {"name": "C", "mass_kg": 3.8, "cost_USD": 210, "stress_MPa": 90,  "yield_MPa": 250},
    {"name": "D", "mass_kg": 3.9, "cost_USD": 190, "stress_MPa": 80,  "yield_MPa": 200},
    {"name": "E", "mass_kg": 2.9, "cost_USD": 195, "stress_MPa": 110, "yield_MPa": 300},
]

required_fos = 2.0
max_mass = 4.0
max_cost = 200

feasible = []

for design in designs:
    fos = design["yield_MPa"] / design["stress_MPa"]
    design["fos"] = fos

    passes_strength = fos >= required_fos
    passes_mass = design["mass_kg"] <= max_mass
    passes_cost = design["cost_USD"] <= max_cost

    if passes_strength and passes_mass and passes_cost:
        feasible.append(design)

if len(feasible) == 0:
    print("No feasible design found.")
else:
    ranked = sorted(feasible, key=lambda d: (d["cost_USD"], d["mass_kg"]))
    best = ranked[0]

    print("FEASIBLE DESIGNS")
    print("----------------")

    for design in ranked:
        print(
            f"{design['name']}: "
            f"cost=${design['cost_USD']}, "
            f"mass={design['mass_kg']:.1f} kg, "
            f"FoS={design['fos']:.2f}"
        )

    print()
    print(f"Recommended design: {best['name']}")
