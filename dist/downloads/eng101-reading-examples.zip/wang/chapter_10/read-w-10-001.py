# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperatures = [42.1, 45.3, 49.8, 53.2, 58.7, 62.4, 66.1]
limit = 60.0

# Teaching observation: expose the computed result.
print(limit)
