# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 14
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

designs = [
    {"name": "A", "mass_kg": 3.2, "cost_USD": 120, "fos": 1.7},
    {"name": "B", "mass_kg": 3.8, "cost_USD": 150, "fos": 2.3},
    {"name": "C", "mass_kg": 2.9, "cost_USD": 180, "fos": 2.1},
    {"name": "D", "mass_kg": 4.4, "cost_USD": 130, "fos": 2.6},
]

best_design = None

for design in designs:
    if design["fos"] >= 2.0:
        if best_design is None or design["cost_USD"] < best_design["cost_USD"]:
            best_design = design

if best_design is None:
    print("No feasible design found.")
else:
    print(f"Best feasible design: {best_design['name']}")
    print(f"Cost = ${best_design['cost_USD']}")
    print(f"FoS = {best_design['fos']:.2f}")
