# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 29
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

strengths = [250e6, 150e6, 70e6, 900e6]
strengths_high_to_low = sorted(strengths, reverse=True)

for strength in strengths_high_to_low:
    print(f"{strength / 1e6:.0f} MPa")
