# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 17
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def binary_search(sorted_values, target):
    """Return the index of target in sorted_values.

    Return None if target is not found.
    The input list must be sorted in increasing order.
    """
    low = 0
    high = len(sorted_values) - 1

    while low <= high:
        mid = (low + high) // 2
        mid_value = sorted_values[mid]

        if mid_value == target:
            return mid
        elif mid_value < target:
            low = mid + 1
        else:
            high = mid - 1

    return None


values = [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0]
index = binary_search(values, 2.5)
print(index)
