# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 31
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

materials = [
    {"name": "steel", "density": 7850, "yield_strength": 250e6},
    {"name": "aluminum", "density": 2700, "yield_strength": 150e6},
    {"name": "copper", "density": 8960, "yield_strength": 70e6},
    {"name": "titanium", "density": 4500, "yield_strength": 900e6},
]

by_density = sorted(materials, key=lambda material: material["density"])

for material in by_density:
    print(f"{material['name']:10s} {material['density']:6.0f} kg/m^3")
