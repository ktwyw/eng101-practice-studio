# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 35
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def selection_sort(values):
    values = values.copy()

    for i in range(len(values)):
        min_index = i

        for j in range(i + 1, len(values)):
            if values[j] < values[min_index]:
                min_index = j

        values[i], values[min_index] = values[min_index], values[i]

    return values


readings = [4.2, 3.1, 5.0, 2.8, 3.7]
print(selection_sort(readings))
