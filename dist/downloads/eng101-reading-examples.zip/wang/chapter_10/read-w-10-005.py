# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 5
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def find_first_above(readings, limit):
    """Return the index of the first reading above limit.

    Return None if no reading is above the limit.
    """
    for index, reading in enumerate(readings):
        if reading > limit:
            return index

    return None


temperatures = [42.1, 45.3, 49.8, 53.2, 58.7, 62.4, 66.1]
index = find_first_above(temperatures, 60.0)

if index is None:
    print("No unsafe reading found.")
else:
    print(f"First unsafe reading at index {index}")
