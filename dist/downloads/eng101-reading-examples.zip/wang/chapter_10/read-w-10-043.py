# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 43
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

materials = {
    "steel": {"density": 7850, "yield_strength": 250e6},
    "aluminum": {"density": 2700, "yield_strength": 150e6},
    "copper": {"density": 8960, "yield_strength": 70e6},
}

name = "steel"

if name in materials:
    print(materials[name]["density"])
else:
    print("Material not found.")
