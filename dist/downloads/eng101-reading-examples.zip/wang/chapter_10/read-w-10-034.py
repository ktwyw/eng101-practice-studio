# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 34
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

designs = [
    {"name": "A", "cost_USD": 100, "priority": 2},
    {"name": "B", "cost_USD": 100, "priority": 1},
    {"name": "C", "cost_USD": 120, "priority": 1},
]

ranked = sorted(designs, key=lambda d: d["cost_USD"])

for design in ranked:
    print(design["name"], design["cost_USD"])
