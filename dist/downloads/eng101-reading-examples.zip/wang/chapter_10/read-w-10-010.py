# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 10
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

designs = [
    {"name": "A", "mass_kg": 3.2, "cost_USD": 120, "fos": 1.7},
    {"name": "B", "mass_kg": 3.8, "cost_USD": 150, "fos": 2.3},
    {"name": "C", "mass_kg": 2.9, "cost_USD": 180, "fos": 2.1},
    {"name": "D", "mass_kg": 4.4, "cost_USD": 130, "fos": 2.6},
]

# Teaching observation: expose the computed result.
print(designs)
