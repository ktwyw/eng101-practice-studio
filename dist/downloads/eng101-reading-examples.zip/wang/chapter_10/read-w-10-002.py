# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 2
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperatures = [42.1, 45.3, 49.8, 53.2, 58.7, 62.4, 66.1]
limit = 60.0

for i in range(len(temperatures)):
    if temperatures[i] > limit:
        print(f"First unsafe reading at index {i}")
        print(f"Temperature = {temperatures[i]:.1f} C")
        break
