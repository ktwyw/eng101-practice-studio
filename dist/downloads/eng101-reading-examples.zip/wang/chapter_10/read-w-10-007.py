# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 7
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

materials = ["steel", "aluminum", "copper", "titanium"]
query = "copper"

if query in materials:
    print("Material is available.")
else:
    print("Material is not available.")
