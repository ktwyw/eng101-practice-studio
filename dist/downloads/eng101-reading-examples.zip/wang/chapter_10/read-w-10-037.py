# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 37
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def insertion_sort(values):
    values = values.copy()

    for i in range(1, len(values)):
        current = values[i]
        j = i - 1

        while j >= 0 and values[j] > current:
            values[j + 1] = values[j]
            j = j - 1

        values[j + 1] = current

    return values


readings = [4.2, 3.1, 5.0, 2.8, 3.7]
print(insertion_sort(readings))
