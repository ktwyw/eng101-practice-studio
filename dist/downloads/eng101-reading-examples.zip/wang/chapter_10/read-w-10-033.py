# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 33
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

designs = [
    {"name": "A", "cost_USD": 120, "fos": 1.7},
    {"name": "B", "cost_USD": 150, "fos": 2.3},
    {"name": "C", "cost_USD": 180, "fos": 2.1},
    {"name": "D", "cost_USD": 130, "fos": 2.6},
]

ranked = sorted(designs, key=lambda d: d["cost_USD"] / d["fos"])

for design in ranked:
    score = design["cost_USD"] / design["fos"]
    print(f"Design {design['name']}: score = {score:.2f}")
