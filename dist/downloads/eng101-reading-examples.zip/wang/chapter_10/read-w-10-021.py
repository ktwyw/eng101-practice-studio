# Instructor: Prof. Yanwei Wang
# Wang · Ch. 10 · Example 21
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def find_interval(sorted_values, x):
    """Return index i such that sorted_values[i] <= x <= sorted_values[i + 1].

    Return None if x is outside the table range.
    """
    if x < sorted_values[0] or x > sorted_values[-1]:
        return None

    for i in range(len(sorted_values) - 1):
        if sorted_values[i] <= x <= sorted_values[i + 1]:
            return i

    return None


voltages = [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0]
index = find_interval(voltages, 1.7)

if index is not None:
    print(f"Value lies between indices {index} and {index + 1}")
    print(f"Voltage interval: {voltages[index]} V to {voltages[index + 1]} V")
