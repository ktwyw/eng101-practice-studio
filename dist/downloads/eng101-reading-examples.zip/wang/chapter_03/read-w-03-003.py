# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 3
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltage_v = 12.0
current_a = 2.5
power_w = voltage_v * current_a

print(power_w > 20)
print(power_w <= 30)
print(voltage_v == 12)
print(current_a != 0)
