# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 13
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

stress_mpa = 140.0
allowable_mpa = 125.0

if stress_mpa <= allowable_mpa:
    print("Stress check passed.")
    print("The stress is within the allowable limit.")

print("End of report.")
