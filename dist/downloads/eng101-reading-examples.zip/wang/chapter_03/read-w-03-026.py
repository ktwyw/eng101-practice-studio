# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 26
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature_c = 75.0
pressure_kpa = 180.0
voltage_v = 11.8

within_temperature_limit = temperature_c <= 80.0
within_pressure_limit = pressure_kpa <= 200.0
within_voltage_limit = 11.0 <= voltage_v <= 13.0

if within_temperature_limit and within_pressure_limit and within_voltage_limit:
    print("System is within all operating limits.")
else:
    print("System is outside at least one operating limit.")
