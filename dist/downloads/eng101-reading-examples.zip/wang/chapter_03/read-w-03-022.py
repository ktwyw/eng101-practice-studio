# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 22
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature_c = 65.0
pressure_kpa = 180.0

if temperature_c <= 80.0 and pressure_kpa <= 200.0:
    print("Operating point is within limits.")
else:
    print("Operating point is outside limits.")
