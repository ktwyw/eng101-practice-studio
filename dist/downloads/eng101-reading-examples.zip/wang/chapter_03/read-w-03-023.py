# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 23
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature_c = 85.0
pressure_kpa = 180.0

if temperature_c > 80.0 or pressure_kpa > 200.0:
    print("WARNING: at least one operating limit is exceeded.")
else:
    print("All operating limits are satisfied.")
