# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 53
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

is_safe = True
alarm_required = False

# Teaching observation: expose the computed result.
print(alarm_required)
