# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 6
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

mode = "automatic"

if mode == "automatic":
    print("Automatic control is enabled.")
