# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 9
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

factor_of_safety = 2.3

if factor_of_safety >= 2.0:
    print("Design is acceptable.")
