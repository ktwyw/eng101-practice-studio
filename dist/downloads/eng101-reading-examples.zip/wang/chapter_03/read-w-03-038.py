# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 38
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force_n = 8000.0
area_mm2 = 400.0
yield_strength_mpa = 250.0
required_fos = 2.0

if area_mm2 <= 0:
    print("ERROR: area must be positive.")
else:
    area_m2 = area_mm2 / 1_000_000
    stress_pa = force_n / area_m2
    stress_mpa = stress_pa / 1_000_000
    factor_of_safety = yield_strength_mpa / stress_mpa

    if factor_of_safety >= required_fos:
        print("Design is acceptable.")
    else:
        print("Design is not acceptable.")

    print(f"Stress = {stress_mpa:.2f} MPa")
    print(f"Factor of safety = {factor_of_safety:.2f}")
