# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 36
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

result = 0.1 + 0.2
print(result)
print(result == 0.3)
