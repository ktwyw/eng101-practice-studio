# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 29
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force_n = 10000.0
area_mm2 = 80.0
yield_strength_mpa = 250.0

area_m2 = area_mm2 / 1_000_000
stress_pa = force_n / area_m2
stress_mpa = stress_pa / 1_000_000
factor_of_safety = yield_strength_mpa / stress_mpa

if factor_of_safety < 1.0:
    classification = "failure expected"
elif factor_of_safety < 2.0:
    classification = "unsafe"
elif factor_of_safety < 4.0:
    classification = "acceptable"
else:
    classification = "conservative"

print("FACTOR OF SAFETY REPORT")
print("-----------------------")
print(f"Applied force:     {force_n:.2f} N")
print(f"Area:              {area_mm2:.2f} mm^2")
print(f"Stress:            {stress_mpa:.2f} MPa")
print(f"Yield strength:    {yield_strength_mpa:.2f} MPa")
print(f"Factor of safety:  {factor_of_safety:.2f}")
print(f"Classification:    {classification}")
