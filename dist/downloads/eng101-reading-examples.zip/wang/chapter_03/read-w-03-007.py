# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 7
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature_c = 65.0

if 20 <= temperature_c <= 80:
    print("Temperature is within the operating range.")
