# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 10
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

factor_of_safety = 1.6

if factor_of_safety >= 2.0:
    print("Design is acceptable.")

print("Calculation complete.")
