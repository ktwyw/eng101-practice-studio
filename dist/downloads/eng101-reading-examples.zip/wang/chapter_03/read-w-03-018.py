# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 18
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

yield_strength_mpa = 250.0
required_fos = 2.0
stress_mpa = 120.0

allowable_stress_mpa = yield_strength_mpa / required_fos

print("STRESS CHECK")
print("------------")
print(f"Stress:           {stress_mpa:.2f} MPa")
print(f"Allowable stress: {allowable_stress_mpa:.2f} MPa")

if stress_mpa <= allowable_stress_mpa:
    print("Decision: PASS")
else:
    print("Decision: FAIL")
