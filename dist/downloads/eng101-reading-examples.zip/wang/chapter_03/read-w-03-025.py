# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 25
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature_c = 75.0
pressure_kpa = 250.0
emergency_stop_pressed = False

if (temperature_c > 80.0 or pressure_kpa > 200.0) and not emergency_stop_pressed:
    print("Warning: limit exceeded. Continue monitoring.")
else:
    print("No automatic warning required.")
