# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 24
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

sensor_connected = False

if not sensor_connected:
    print("ERROR: sensor is not connected.")
else:
    print("Sensor is connected.")
