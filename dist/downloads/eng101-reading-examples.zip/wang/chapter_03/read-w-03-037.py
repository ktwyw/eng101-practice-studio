# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 37
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

result = 0.1 + 0.2
target = 0.3
tolerance = 1e-9

if abs(result - target) < tolerance:
    print("Values are close enough.")
else:
    print("Values are different beyond the tolerance.")
