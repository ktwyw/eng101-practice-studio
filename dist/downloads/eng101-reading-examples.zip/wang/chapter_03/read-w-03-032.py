# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 32
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

rho = 1000.0       # kg/m^3
velocity = 0.20    # m/s
diameter = 0.025   # m
mu = 0.001         # Pa*s

reynolds_number = rho * velocity * diameter / mu

if reynolds_number < 2300:
    flow_type = "laminar"
elif reynolds_number <= 4000:
    flow_type = "transitional"
else:
    flow_type = "turbulent"

print(f"Reynolds number = {reynolds_number:.0f}")
print(f"Flow type = {flow_type}")
