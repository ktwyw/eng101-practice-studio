# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 14
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature_c = 95.0

if temperature_c > 80.0:
    print("WARNING: temperature exceeds limit.")
    print("Reduce load or improve cooling.")

print("Temperature check complete.")
