# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 19
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

factor_of_safety = 2.8

if factor_of_safety < 1.5:
    category = "unsafe"
elif factor_of_safety < 2.0:
    category = "marginal"
elif factor_of_safety < 4.0:
    category = "acceptable"
else:
    category = "conservative"

print(f"Design category: {category}")
