# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

stress_mpa = 120.0
allowable_stress_mpa = 125.0

print(stress_mpa <= allowable_stress_mpa)
