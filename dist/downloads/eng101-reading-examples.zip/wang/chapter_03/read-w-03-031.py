# Instructor: Prof. Yanwei Wang
# Wang · Ch. 3 · Example 31
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

stress_mpa = 118.0
mass_kg = 1.7
cost = 42.0

stress_limit_mpa = 125.0
mass_limit_kg = 2.0
cost_limit = 50.0

stress_ok = stress_mpa <= stress_limit_mpa
mass_ok = mass_kg <= mass_limit_kg
cost_ok = cost <= cost_limit

if stress_ok and mass_ok and cost_ok:
    print("Design status: ACCEPT")
else:
    print("Design status: REJECT")

print(f"Stress check: {stress_ok}")
print(f"Mass check:   {mass_ok}")
print(f"Cost check:   {cost_ok}")
