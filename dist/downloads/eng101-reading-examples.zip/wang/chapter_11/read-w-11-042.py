# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 42
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

n = 4
A = np.zeros((n, n))

for i in range(n):
    A[i, i] = 2

    if i > 0:
        A[i, i - 1] = -1

    if i < n - 1:
        A[i, i + 1] = -1

print(A)
