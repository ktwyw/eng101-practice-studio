# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 54
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

v = np.array([1, 2, 3])

A = np.array([[1, 2],
              [3, 4]])

# Teaching observation: expose the computed result.
print(A)
