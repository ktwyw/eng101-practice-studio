# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 36
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

load = 1000.0  # N

theta1 = np.radians(30.0)
theta2 = np.radians(60.0)

A = np.array([[np.cos(theta1), -np.cos(theta2)],
              [np.sin(theta1),  np.sin(theta2)]])

b = np.array([0.0, load])

tensions = np.linalg.solve(A, b)

T1 = tensions[0]
T2 = tensions[1]

print(f"T1 = {T1:.2f} N")
print(f"T2 = {T2:.2f} N")
