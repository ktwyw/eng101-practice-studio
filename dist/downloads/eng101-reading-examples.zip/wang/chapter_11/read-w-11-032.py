# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 32
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

Vs = 10.0     # V
R1 = 100.0    # ohm
R2 = 150.0    # ohm
R3 = 220.0    # ohm

A = np.array([[1/R1 + 1/R3, -1/R3],
              [-1/R3, 1/R3 + 1/R2]])

b = np.array([Vs/R1, 0.0])

voltages = np.linalg.solve(A, b)

V1 = voltages[0]
V2 = voltages[1]

print(f"V1 = {V1:.3f} V")
print(f"V2 = {V2:.3f} V")
