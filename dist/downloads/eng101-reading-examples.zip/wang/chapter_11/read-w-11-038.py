# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 38
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

T_left = 100.0   # deg C
T_right = 20.0   # deg C

G_left = 2.0     # W/deg C
G_12 = 1.5       # W/deg C
G_right = 1.0    # W/deg C

q1 = 10.0        # W
q2 = 0.0         # W

A = np.array([[G_left + G_12, -G_12],
              [-G_12, G_12 + G_right]])

b = np.array([G_left * T_left + q1,
              G_right * T_right + q2])

temperatures = np.linalg.solve(A, b)

T1 = temperatures[0]
T2 = temperatures[1]

print(f"T1 = {T1:.2f} deg C")
print(f"T2 = {T2:.2f} deg C")
