# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 23
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

A = np.array([[5, -2, 1],
              [-1, 4, 2],
              [2, 1, 3]])

b = np.array([13, 7, 18])

x = np.linalg.solve(A, b)

print(x)
