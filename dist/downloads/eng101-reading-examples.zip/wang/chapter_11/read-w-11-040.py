# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 40
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

k1 = 100000.0  # N/m
k2 = 150000.0  # N/m
k3 = 120000.0  # N/m
k4 = 80000.0   # N/m

K = np.array([[k1 + k2, -k2, 0.0],
              [-k2, k2 + k3, -k3],
              [0.0, -k3, k3 + k4]])

F = np.array([100.0, 50.0, 75.0])

x = np.linalg.solve(K, F)

print(f"x1 = {x[0]:.6f} m")
print(f"x2 = {x[1]:.6f} m")
print(f"x3 = {x[2]:.6f} m")
