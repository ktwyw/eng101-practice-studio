# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

A = np.array([[3, 2],
              [1, 4]])

b = np.array([12, 10])

x = np.linalg.solve(A, b)

print(x)
