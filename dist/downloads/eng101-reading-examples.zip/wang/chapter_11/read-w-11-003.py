# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 3
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

b = np.array([12, 10])

print(b)
print(b.shape)
