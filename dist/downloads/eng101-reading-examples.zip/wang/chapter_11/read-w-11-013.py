# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 13
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

u = np.array([2, 3, 4])
v = np.array([10, 20, 30])

print(u * v)
