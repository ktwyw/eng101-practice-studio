# Instructor: Prof. Yanwei Wang
# Wang · Ch. 11 · Example 51
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

# Spring stiffnesses in N/m
k1 = 100000.0
k2 = 150000.0
k3 = 120000.0
k4 = 80000.0

# Applied forces in N
F = np.array([100.0, 50.0, 75.0])

# Stiffness matrix
K = np.array([[k1 + k2, -k2, 0.0],
              [-k2, k2 + k3, -k3],
              [0.0, -k3, k3 + k4]])

# Solve for displacements
x = np.linalg.solve(K, F)

# Residual check
residual = K @ x - F

print("SPRING SYSTEM REPORT")
print("--------------------")
print(f"x1 = {x[0]:.6e} m")
print(f"x2 = {x[1]:.6e} m")
print(f"x3 = {x[2]:.6e} m")
print()
print("Residual:")
print(residual)
print()

if np.allclose(K @ x, F):
    print("Solution check: PASSED")
else:
    print("Solution check: FAILED")
