# Instructor: Prof. Yanwei Wang
# Wang · Ch. 8 · Example 50
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def mm2_to_m2(area_mm2):
    """Convert area from square millimeters to square meters."""
    if area_mm2 <= 0:
        raise ValueError("Area must be positive.")
    return area_mm2 / 1_000_000


def mpa_to_pa(stress_mpa):
    """Convert stress or strength from MPa to Pa."""
    if stress_mpa <= 0:
        raise ValueError("Strength must be positive.")
    return stress_mpa * 1_000_000


def calculate_stress(force, area):
    """Return axial stress in Pa for force in N and area in m^2."""
    if area <= 0:
        raise ValueError("Area must be positive.")
    return force / area


def calculate_factor_of_safety(strength, stress):
    """Return factor of safety for positive strength and stress."""
    if strength <= 0:
        raise ValueError("Strength must be positive.")
    if stress <= 0:
        raise ValueError("Stress must be positive.")
    return strength / stress


def classify_design(factor_of_safety, required_fos=2.0):
    """Return design classification based on required factor of safety."""
    if factor_of_safety >= required_fos:
        return "acceptable"
    else:
        return "not acceptable"



def run_tests():
    assert mm2_to_m2(1_000_000) == 1.0
    assert mpa_to_pa(1) == 1_000_000
    assert calculate_stress(10, 2) == 5
    assert calculate_factor_of_safety(250, 125) == 2
    assert classify_design(2.0) == "acceptable"
    assert classify_design(1.5) == "not acceptable"


def main():
    force = 10000                  # N
    area_mm2 = 500                 # mm^2
    yield_strength_mpa = 250       # MPa
    required_fos = 2.0

    area_m2 = mm2_to_m2(area_mm2)
    yield_strength_pa = mpa_to_pa(yield_strength_mpa)
    stress_pa = calculate_stress(force, area_m2)
    stress_mpa = stress_pa / 1_000_000
    factor_of_safety = calculate_factor_of_safety(
        yield_strength_pa, stress_pa
    )
    status = classify_design(factor_of_safety, required_fos)

    print("BAR DESIGN CHECK")
    print("----------------")
    print(f"Force: {force:.2f} N")
    print(f"Area: {area_mm2:.2f} mm^2")
    print(f"Yield strength: {yield_strength_mpa:.2f} MPa")
    print(f"Stress: {stress_mpa:.2f} MPa")
    print(f"Factor of safety: {factor_of_safety:.2f}")
    print(f"Required factor of safety: {required_fos:.2f}")
    print(f"Design status: {status}")


run_tests()
main()
