# Instructor: Prof. Yanwei Wang
# Wang · Ch. 8 · Example 30
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

def calculate_stress(force, area):
    if area <= 0:
        raise ValueError("Area must be positive.")
    return force / area


def test_calculate_stress():
    assert calculate_stress(10, 2) == 5
    assert calculate_stress(100, 4) == 25
    assert calculate_stress(0, 2) == 0


test_calculate_stress()
print("All tests passed.")
