# Instructor: Prof. Yanwei Wang
# Wang · Ch. 9 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

time = [0, 1, 2, 3, 4]
temperature = [95.2, 92.7, 90.5, 88.1, 86.0]

# Teaching observation: expose the computed result.
print(temperature)
