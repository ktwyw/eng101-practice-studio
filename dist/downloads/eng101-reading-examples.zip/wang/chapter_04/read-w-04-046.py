# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 46
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

time = 0.0

while time <= 1.0:
    print(time)
    time += 0.1
