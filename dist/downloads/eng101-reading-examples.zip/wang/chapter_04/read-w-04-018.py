# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 18
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material_code = "AL6061"

for character in material_code:
    print(character)
