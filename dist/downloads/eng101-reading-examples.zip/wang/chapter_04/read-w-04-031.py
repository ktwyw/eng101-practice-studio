# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 31
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 5000.0

for area_mm2 in range(0, 501, 100):
    if area_mm2 == 0:
        print("Skipping zero area")
        continue

    area_m2 = area_mm2 / 1_000_000
    stress = force / area_m2
    print(f"Area = {area_mm2:4d} mm^2, stress = {stress/1e6:7.2f} MPa")
