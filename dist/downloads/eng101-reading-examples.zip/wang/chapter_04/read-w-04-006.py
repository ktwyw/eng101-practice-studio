# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 6
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

for time in range(0, 3):
    print("Inside the loop")
    print(time)

print("After the loop")
