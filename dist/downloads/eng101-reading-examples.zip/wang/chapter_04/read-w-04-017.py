# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 17
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

maximum_force = None
maximum_time = None

for time in range(0, 21):
    force = 100 + 20 * time - time**2

    if maximum_force is None or force > maximum_force:
        maximum_force = force
        maximum_time = time

print(f"Maximum tested force = {maximum_force:.2f} N")
print(f"It occurred at t = {maximum_time} s")
