# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 33
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 8000.0                 # N
allowable_stress = 50e6        # Pa

found = False

for area_mm2 in range(25, 1001, 25):
    area_m2 = area_mm2 / 1_000_000
    stress = force / area_m2

    if stress <= allowable_stress:
        print(f"Smallest tested area = {area_mm2} mm^2")
        print(f"Stress = {stress/1e6:.2f} MPa")
        found = True
        break

if not found:
    print("No area in the tested range satisfies the limit")
