# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

height0 = 100 - 0.5 * 9.81 * 0**2
height1 = 100 - 0.5 * 9.81 * 1**2
height2 = 100 - 0.5 * 9.81 * 2**2
height3 = 100 - 0.5 * 9.81 * 3**2
height4 = 100 - 0.5 * 9.81 * 4**2

# Teaching observation: expose the computed result.
print(height4)
