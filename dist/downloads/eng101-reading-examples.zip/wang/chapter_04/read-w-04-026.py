# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 26
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

capacity = 100.0      # L
flow_rate = 8.0       # L/min
volume = 0.0          # L
time = 0              # min

print("Time (min)   Volume (L)")
print("-----------------------")

while volume < capacity:
    print(f"{time:10d}   {volume:10.2f}")
    time += 1
    volume += flow_rate

print(f"Tank reaches or exceeds capacity after {time} min")
print(f"Calculated volume at that time = {volume:.2f} L")
