# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 8
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

for i in range(2, 7):
    print(i)
