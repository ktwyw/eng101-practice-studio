# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 43
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

total = 0

for value in range(1, 6):
    square = value**2

total += square

print(total)
