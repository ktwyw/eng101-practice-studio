# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 4
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

for time in range(0, 5):
    print(time)
