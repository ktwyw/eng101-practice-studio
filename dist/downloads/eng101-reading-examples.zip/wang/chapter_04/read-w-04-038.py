# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 38
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 10000.0             # N
allowable_stress = 80e6     # Pa

best_area = None
best_width = None
best_height = None

for width_mm in range(10, 101, 10):
    for height_mm in range(10, 101, 10):
        area_mm2 = width_mm * height_mm
        area_m2 = area_mm2 / 1_000_000
        stress = force / area_m2

        if stress <= allowable_stress:
            if best_area is None or area_mm2 < best_area:
                best_area = area_mm2
                best_width = width_mm
                best_height = height_mm

if best_area is None:
    print("No safe design found in the tested range")
else:
    print("Best tested design")
    print(f"Width  = {best_width} mm")
    print(f"Height = {best_height} mm")
    print(f"Area   = {best_area} mm^2")
