# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 23
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

h0 = 100.0
g = 9.81

time = 0
height = h0

print("Time (s)   Height (m)")
print("---------------------")

while height > 0:
    print(f"{time:8d}   {height:10.2f}")

    time = time + 1
    height = h0 - 0.5 * g * time**2

print(f"Ground reached between t = {time - 1} s and t = {time} s")
