# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 29
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

population = 1000.0
rate = 0.04

year = 0

print("Year   Population")
print("-----------------")

while population < 1500:
    print(f"{year:4d}   {population:10.1f}")
    population = population * (1 + rate)
    year += 1

print(f"Population exceeds 1500 after {year} years")
