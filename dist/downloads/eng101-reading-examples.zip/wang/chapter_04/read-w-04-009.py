# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 9
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

for i in range(0, 11, 2):
    print(i)
