# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 30
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 8000.0              # N
allowable_stress = 50e6     # Pa
required_area = None

for area_mm2 in range(100, 1001, 50):
    area_m2 = area_mm2 / 1_000_000
    stress = force / area_m2

    if stress <= allowable_stress:
        required_area = area_mm2
        break

if required_area is None:
    print("No tested area satisfied the stress limit")
else:
    print(f"Minimum tested area = {required_area} mm^2")
