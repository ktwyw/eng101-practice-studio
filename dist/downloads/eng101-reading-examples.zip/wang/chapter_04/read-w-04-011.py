# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 11
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

h0 = 100.0  # m
g = 9.81    # m/s^2

print("Time (s)   Height (m)")
print("---------------------")

for time in range(0, 6):
    height = h0 - 0.5 * g * time**2
    print(f"{time:8d}   {height:10.2f}")
