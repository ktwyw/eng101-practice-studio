# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 55
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

for value in range(5):
    if value == 0:
        continue
    print(1 / value)
