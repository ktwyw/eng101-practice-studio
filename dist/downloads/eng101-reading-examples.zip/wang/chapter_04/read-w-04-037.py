# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 37
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

for width_mm in range(20, 61, 20):
    for height_mm in range(40, 121, 40):
        area_mm2 = width_mm * height_mm
        print(f"width = {width_mm:3d} mm, height = {height_mm:3d} mm, area = {area_mm2:5d} mm^2")
