# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 35
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

target = 2.0
tolerance = 0.001
step = 0.0001

guess = 0.0
iteration = 0
maximum_iterations = 100000

while abs(guess**2 - target) > tolerance and iteration < maximum_iterations:
    guess += step
    iteration += 1

if iteration == maximum_iterations:
    print("Warning: maximum number of iterations reached")
else:
    print(f"Approximate square root = {guess:.4f}")
    print(f"Number of iterations = {iteration}")
