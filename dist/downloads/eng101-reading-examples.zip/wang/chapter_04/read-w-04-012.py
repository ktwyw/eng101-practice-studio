# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 12
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

h0 = 100.0
g = 9.81

print("Time (s)   Height (m)   Status")
print("--------------------------------")

for time in range(0, 6):
    height = h0 - 0.5 * g * time**2

    if height > 0:
        status = "above ground"
    else:
        status = "ground reached"

    print(f"{time:8d}   {height:10.2f}   {status}")
