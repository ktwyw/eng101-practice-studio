# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 27
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

capacity = 100.0
flow_rate = 8.0
volume = 0.0
time = 0.0
dt = 0.1

while volume < capacity:
    time += dt
    volume += flow_rate * dt

print(f"Tank reaches capacity at approximately {time:.1f} min")
