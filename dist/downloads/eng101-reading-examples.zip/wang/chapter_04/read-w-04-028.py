# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 28
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

temperature = 100.0          # degrees Celsius
ambient_temperature = 25.0   # degrees Celsius
k = 0.08                     # 1/min
dt = 1.0                     # min
time = 0.0

print("Time (min)   Temperature (C)")
print("----------------------------")

while temperature > 40.0:
    print(f"{time:10.1f}   {temperature:15.2f}")

    cooling_rate = -k * (temperature - ambient_temperature)
    temperature = temperature + cooling_rate * dt
    time = time + dt

print(f"Temperature drops below 40 C after about {time:.1f} min")
