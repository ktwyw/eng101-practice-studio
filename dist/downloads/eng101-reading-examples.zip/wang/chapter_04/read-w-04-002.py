# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 2
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

for time in range(0, 5):
    height = 100 - 0.5 * 9.81 * time**2
    print(time, height)
