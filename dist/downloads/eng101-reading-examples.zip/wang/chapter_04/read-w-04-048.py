# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 48
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

h0 = 100.0       # m
g = 9.81         # m/s^2
dt = 0.5         # s

time = 0.0
height = h0

print("FALLING OBJECT REPORT")
print("---------------------")
print(f"Initial height: {h0:.2f} m")
print(f"Time step:      {dt:.2f} s")
print()
print("Time (s)   Height (m)   Speed (m/s)")
print("------------------------------------")

while height > 0:
    speed = g * time
    print(f"{time:8.2f}   {height:10.2f}   {speed:11.2f}")

    time += dt
    height = h0 - 0.5 * g * time**2

impact_speed = g * time

print()
print(f"Ground reached between {time - dt:.2f} s and {time:.2f} s")
print(f"Approximate impact speed at upper estimate: {impact_speed:.2f} m/s")
