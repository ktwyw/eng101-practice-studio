# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 10
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

acceleration = 2.0  # m/s^2

print("Time (s)   Velocity (m/s)")
print("--------------------------")

for time in range(0, 11):
    velocity = acceleration * time
    print(f"{time:8d}   {velocity:14.2f}")
