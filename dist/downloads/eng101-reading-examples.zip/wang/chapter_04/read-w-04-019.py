# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 19
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

sample_code = "SAMPLE-2026-A7"
digit_count = 0

for character in sample_code:
    if character.isdigit():
        digit_count += 1

print(f"Number of digits = {digit_count}")
