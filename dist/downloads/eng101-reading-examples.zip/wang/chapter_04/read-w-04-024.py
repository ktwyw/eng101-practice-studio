# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 24
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

time = 0        # initial value

while time <= 10:     # condition
    print(time)
    time = time + 1   # update
