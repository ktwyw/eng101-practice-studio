# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 47
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

dt = 0.1

for step in range(0, 11):
    time = step * dt
    print(time)
