# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 36
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

lower = 1.0
upper = 2.0
tolerance = 0.0001
iteration = 0

while upper - lower > tolerance:
    midpoint = (lower + upper) / 2
    value = midpoint**2 - 2

    if value > 0:
        upper = midpoint
    else:
        lower = midpoint

    iteration += 1

estimate = (lower + upper) / 2

print(f"Estimated square root of 2 = {estimate:.5f}")
print(f"Iterations = {iteration}")
