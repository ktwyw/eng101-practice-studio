# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 13
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

total_distance = 0.0  # km

for hour in range(1, 5):
    speed = 50 + 5 * hour      # km/h
    time_interval = 1.0        # h
    distance = speed * time_interval
    total_distance = total_distance + distance

    print(f"Hour {hour}: speed = {speed:.1f} km/h, distance = {distance:.1f} km")

print(f"Total distance = {total_distance:.1f} km")
