# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 34
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

target = 2.0
tolerance = 0.001
step = 0.0001

guess = 0.0

while abs(guess**2 - target) > tolerance:
    guess += step

print(f"Approximate square root = {guess:.4f}")
print(f"Squared value = {guess**2:.4f}")
