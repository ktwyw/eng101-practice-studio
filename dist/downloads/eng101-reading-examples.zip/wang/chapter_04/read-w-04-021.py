# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 21
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

equipment_id = "PUMP-07A"
valid = True

for character in equipment_id:
    if not (character.isalnum() or character == "-"):
        valid = False

if valid:
    print("Equipment ID is valid")
else:
    print("Equipment ID contains an invalid character")
