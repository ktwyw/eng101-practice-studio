# Instructor: Prof. Yanwei Wang
# Wang · Ch. 4 · Example 16
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 12000.0             # N
allowable_stress = 80e6     # Pa
safe_count = 0

for area_mm2 in range(100, 501, 100):
    area_m2 = area_mm2 / 1_000_000
    stress = force / area_m2

    if stress <= allowable_stress:
        safe_count += 1
        status = "safe"
    else:
        status = "unsafe"

    print(f"Area = {area_mm2:4d} mm^2, stress = {stress/1e6:7.2f} MPa, {status}")

print(f"Number of safe areas tested = {safe_count}")
