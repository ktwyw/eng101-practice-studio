# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 25
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

raw_readings = [22.1, 22.5, -999, 23.0, 23.4, -999, 22.9]
valid_readings = []

for temperature in raw_readings:
    if temperature != -999:
        valid_readings.append(temperature)

print(valid_readings)
