# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 22
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

raw_readings = [22.1, 22.5, 23.0, 23.4, 22.9]
correction = -0.3
corrected_readings = []

for temperature in raw_readings:
    corrected_readings.append(temperature + correction)

print(raw_readings)
print(corrected_readings)
