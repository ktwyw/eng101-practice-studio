# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 28
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

materials = ["steel", "aluminum", "copper"]

if "steel" in materials:
    print("Steel is available")
