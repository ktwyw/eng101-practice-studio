# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 63
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

sensor = {
    "id": "T-101",
    "quantity": "temperature",
    "unit": "C",
    "location": "heat exchanger outlet",
    "warning_limit": 23.5
}

readings = np.array([22.1, 22.5, 23.0, 23.4, 22.9, 23.7, 24.2, 24.0])

average = np.mean(readings)
maximum = np.max(readings)
minimum = np.min(readings)
reading_range = maximum - minimum
rms = np.sqrt(np.mean(readings**2))

warning_limit = sensor["warning_limit"]
warning_flags = readings > warning_limit
warning_count = np.sum(warning_flags)

print("SENSOR DATA REPORT")
print("------------------")
print(f"Sensor ID: {sensor['id']}")
print(f"Quantity: {sensor['quantity']}")
print(f"Location: {sensor['location']}")
print(f"Number of readings: {len(readings)}")
print()
print(f"Average: {average:.2f} {sensor['unit']}")
print(f"Maximum: {maximum:.2f} {sensor['unit']}")
print(f"Minimum: {minimum:.2f} {sensor['unit']}")
print(f"Range:   {reading_range:.2f} {sensor['unit']}")
print(f"RMS:     {rms:.2f} {sensor['unit']}")
print(f"Readings above warning limit: {warning_count}")
