# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 13
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9]

total = 0.0

for temperature in readings:
    total += temperature

average = total / len(readings)

print(f"Average = {average:.2f} C")
