# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 62
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

force = 12000.0
areas_mm2 = np.array([100, 200, 300, 400, 500])
areas_m2 = areas_mm2 / 1_000_000
stresses_mpa = force / areas_m2 / 1e6
allowable_stress = 80.0

print("Area (mm^2)   Stress (MPa)   Status")
print("------------------------------------")

for area, stress in zip(areas_mm2, stresses_mpa):
    if stress <= allowable_stress:
        status = "safe"
    else:
        status = "unsafe"

    print(f"{area:11.0f}   {stress:12.2f}   {status}")
