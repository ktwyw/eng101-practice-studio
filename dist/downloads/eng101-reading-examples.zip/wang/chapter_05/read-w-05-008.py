# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 8
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9]

last_reading = readings[-1]
second_last = readings[-2]

print(last_reading)
print(second_last)
