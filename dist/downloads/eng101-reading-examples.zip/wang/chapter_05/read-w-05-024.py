# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 24
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9, 23.7, 24.2, 24.0]
limit = 23.5

safe_readings = []

for temperature in readings:
    if temperature <= limit:
        safe_readings.append(temperature)

print(safe_readings)
