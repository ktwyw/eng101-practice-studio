# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 5
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9]
number_of_readings = len(readings)

print(number_of_readings)
