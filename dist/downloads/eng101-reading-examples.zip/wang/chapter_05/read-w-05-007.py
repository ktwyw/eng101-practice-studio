# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 7
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9]

first_reading = readings[0]
third_reading = readings[2]

print(first_reading)
print(third_reading)
