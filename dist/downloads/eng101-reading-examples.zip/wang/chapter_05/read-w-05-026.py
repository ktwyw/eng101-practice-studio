# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 26
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

raw_readings = [22.1, 22.5, -999, 23.0, 23.4, -999, 22.9]
valid_readings = []
invalid_count = 0

for temperature in raw_readings:
    if temperature == -999:
        invalid_count += 1
    else:
        valid_readings.append(temperature)

print(f"Valid readings: {valid_readings}")
print(f"Invalid readings removed: {invalid_count}")
