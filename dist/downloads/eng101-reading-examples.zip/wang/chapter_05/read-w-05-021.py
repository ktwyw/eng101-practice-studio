# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 21
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9]
correction = -0.3

for index in range(len(readings)):
    readings[index] = readings[index] + correction

print(readings)
