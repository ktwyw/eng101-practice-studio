# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 27
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

areas = [100, 200, 300]

areas.append(400)
areas.insert(0, 50)

print(areas)
