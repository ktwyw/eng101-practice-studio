# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 33
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

measurements = [
    [0.0, 22.1],
    [1.0, 22.5],
    [2.0, 23.0],
    [3.0, 23.4]
]

# Teaching observation: expose the computed result.
print(measurements)
