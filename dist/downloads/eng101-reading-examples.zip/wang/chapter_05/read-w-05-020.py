# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 20
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0]

readings[1] = 22.6

print(readings)
