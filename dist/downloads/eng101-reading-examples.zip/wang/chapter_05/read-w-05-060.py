# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 60
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

force = 12000.0  # N
areas_mm2 = np.array([100, 200, 300, 400, 500])
areas_m2 = areas_mm2 / 1_000_000

stresses = force / areas_m2
stresses_mpa = stresses / 1e6

print(stresses_mpa)
