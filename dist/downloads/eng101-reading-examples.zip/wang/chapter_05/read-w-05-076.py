# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 76
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

values = np.array([1.0, 2.0, 3.0])
average = np.mean(values)
rms = np.sqrt(np.mean(values**2))

# Teaching observation: expose the computed result.
print(rms)
