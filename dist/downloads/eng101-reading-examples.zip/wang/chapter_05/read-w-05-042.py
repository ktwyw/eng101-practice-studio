# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 42
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material_density = {
    "steel": 7850,
    "aluminum": 2700
}

material_density["copper"] = 8960
material_density["aluminum"] = 2710

print(material_density)
