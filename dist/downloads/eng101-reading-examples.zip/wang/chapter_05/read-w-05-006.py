# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 6
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9]

average = sum(readings) / len(readings)
maximum = max(readings)
minimum = min(readings)
reading_range = maximum - minimum

print(f"Average = {average:.2f} C")
print(f"Maximum = {maximum:.2f} C")
print(f"Minimum = {minimum:.2f} C")
print(f"Range   = {reading_range:.2f} C")
