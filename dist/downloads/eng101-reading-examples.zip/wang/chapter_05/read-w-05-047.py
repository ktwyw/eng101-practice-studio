# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 47
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

materials = {
    "steel": {
        "density": 7850,
        "yield_strength": 250e6,
        "elastic_modulus": 200e9
    },
    "aluminum": {
        "density": 2700,
        "yield_strength": 150e6,
        "elastic_modulus": 69e9
    },
    "copper": {
        "density": 8960,
        "yield_strength": 210e6,
        "elastic_modulus": 110e9
    }
}

# Teaching observation: expose the computed result.
print(materials)
