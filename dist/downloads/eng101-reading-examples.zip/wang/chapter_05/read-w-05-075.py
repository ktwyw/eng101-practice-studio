# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 75
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

properties = {"density": 7850, "strength": 250e6}
density = properties["density"]

# Teaching observation: expose the computed result.
print(density)
