# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 15
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9]

for index in range(len(readings)):
    temperature = readings[index]
    print(f"Reading {index}: {temperature:.1f} C")
