# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 32
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

original = [1, 2, 3]
independent_copy = original[:]

independent_copy[0] = 99

print(original)
print(independent_copy)
