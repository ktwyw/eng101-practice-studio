# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 37
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

sensor_location = (3.0, 1.5, 0.8)

x, y, z = sensor_location

print(f"x = {x} m")
print(f"y = {y} m")
print(f"z = {z} m")
