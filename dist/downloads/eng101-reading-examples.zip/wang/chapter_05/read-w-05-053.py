# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 53
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

designs = [
    {"name": "A", "area_mm2": 300, "cost": 12.5},
    {"name": "B", "area_mm2": 450, "cost": 16.0},
    {"name": "C", "area_mm2": 600, "cost": 20.0}
]

force = 12000.0          # N
allowable_stress = 80e6  # Pa

for design in designs:
    area_m2 = design["area_mm2"] / 1_000_000
    stress = force / area_m2

    if stress <= allowable_stress:
        status = "safe"
    else:
        status = "unsafe"

    print(f"Design {design['name']}: stress = {stress/1e6:.1f} MPa, {status}")
