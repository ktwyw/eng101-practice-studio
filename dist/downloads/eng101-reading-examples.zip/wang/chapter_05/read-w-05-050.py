# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 50
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

sensor = {
    "id": "T-101",
    "quantity": "temperature",
    "unit": "C",
    "location": "heat exchanger outlet",
    "calibrated": True,
    "warning_limit": 80.0

}

# Teaching observation: expose the computed result.
print(sensor)
