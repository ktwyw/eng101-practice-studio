# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 29
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

loads = [1200, 800, 1500, 1000]

sorted_loads = sorted(loads)

print(loads)
print(sorted_loads)
