# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 59
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

readings = np.array([2.1, 2.3, 2.2, 2.5, 2.4])

rms = np.sqrt(np.mean(readings**2))

print(f"RMS = {rms:.3f}")
