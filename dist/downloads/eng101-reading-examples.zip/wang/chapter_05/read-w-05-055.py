# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 55
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

readings = np.array([22.1, 22.5, 23.0, 23.4, 22.9])

print(readings)
