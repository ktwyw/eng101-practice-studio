# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 46
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material_density = {
    "steel": 7850,
    "aluminum": 2700,
    "copper": 8960
}

print("Materials:")
for material in material_density.keys():
    print(material)

print("Densities:")
for density in material_density.values():
    print(density)

print("Material density table:")
for material, density in material_density.items():
    print(f"{material}: {density} kg/m^3")
