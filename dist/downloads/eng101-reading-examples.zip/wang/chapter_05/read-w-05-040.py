# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 40
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

material_density = {
    "steel": 7850,
    "aluminum": 2700,
    "copper": 8960
}

# Teaching observation: expose the computed result.
print(material_density)
