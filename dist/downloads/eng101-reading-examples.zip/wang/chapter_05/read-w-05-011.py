# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 11
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9]

first_three = readings[0:3]
middle = readings[1:4]
from_second_to_end = readings[1:]
up_to_third = readings[:3]

print(first_three)
print(middle)
print(from_second_to_end)
print(up_to_third)
