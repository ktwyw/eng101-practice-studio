# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 4
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

voltages = [1.0, 1.5, 2.0, 2.5]
sample_ids = ["S1", "S2", "S3", "S4"]
status_values = [True, True, False, True]

# Teaching observation: expose the computed result.
print(status_values)
