# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 39
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

calibration_data = [
    (0.0, 0.02),
    (1.0, 1.01),
    (2.0, 2.03),
    (3.0, 3.02)
]

for input_voltage, output_voltage in calibration_data:
    print(f"Input = {input_voltage:.1f} V, Output = {output_voltage:.2f} V")
