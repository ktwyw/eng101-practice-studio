# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 58
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

import numpy as np

readings = np.array([22.1, 22.5, 23.0, 23.4, 22.9])

average = np.mean(readings)
maximum = np.max(readings)
minimum = np.min(readings)
standard_deviation = np.std(readings)

print(f"Average = {average:.2f} C")
print(f"Maximum = {maximum:.2f} C")
print(f"Minimum = {minimum:.2f} C")
print(f"Standard deviation = {standard_deviation:.3f} C")
