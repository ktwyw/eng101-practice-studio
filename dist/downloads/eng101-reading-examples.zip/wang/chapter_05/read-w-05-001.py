# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 1
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

force = 5000.0
area = 0.002
stress = force / area

# Teaching observation: expose the computed result.
print(stress)
