# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 23
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = []

readings.append(22.1)
readings.append(22.5)
readings.append(23.0)

print(readings)
