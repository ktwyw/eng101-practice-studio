# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 30
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

original = [1, 2, 3]
copy_attempt = original

copy_attempt[0] = 99

print(original)
print(copy_attempt)
