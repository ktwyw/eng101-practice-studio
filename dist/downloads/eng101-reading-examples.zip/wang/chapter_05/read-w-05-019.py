# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 19
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [2.1, 2.3, 2.2, 2.5, 2.4]

sum_of_squares = 0.0

for value in readings:
    sum_of_squares += value**2

rms = (sum_of_squares / len(readings))**0.5

print(f"RMS = {rms:.3f}")
