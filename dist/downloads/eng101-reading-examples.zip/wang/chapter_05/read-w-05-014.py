# Instructor: Prof. Yanwei Wang
# Wang · Ch. 5 · Example 14
# Adapted from the instructor’s chapter source; teaching observations and reproducibility setup are labeled.

readings = [22.1, 22.5, 23.0, 23.4, 22.9, 23.7, 24.2, 24.0]
warning_limit = 23.0

warning_count = 0

for temperature in readings:
    if temperature > warning_limit:
        warning_count += 1

print(f"Number of readings above limit = {warning_count}")
