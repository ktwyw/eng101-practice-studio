ENG 101 Reading Examples
Instructor: Prof. Yanwei Wang

400 standalone Python programs: 320 in the Wang collection and 80 Guttag-aligned
companions. The Wang collection includes 272 chapter-source adaptations and
48 original companions. The 80 Guttag companions are newly written programs
aligned with concepts in the cited second-edition book. Chapter references do
not imply that Guttag authored the companion code. Origins are identified in
each file and in catalog.csv.

Run one program at a time using Python 3.10 or later. Some examples require the
packages named in catalog.csv (NumPy, Pandas, Matplotlib or SciPy). Programs use
embedded data fixtures and local seeded generators where appropriate. Generated
files are written into the current working directory. Plots display in your
Python environment. Reference outputs are included in the outputs folder.

Predict, run, explain, modify one input, then predict again. Keep the supplied
assertions and add independent known-result and boundary checks. Seeded random
examples are repeatable illustrations, not statistical guarantees. Classroom
models and limits are illustrative, not certified engineering design rules.

Readings:
Yanwei Wang, Programming for Engineers with Python, working course manuscript.
John V. Guttag, Introduction to Computation and Programming Using Python:
With Application to Understanding Data, second edition, MIT Press.
