# Instructor: Prof. Yanwei Wang
# Accumulate a recursive list sum
def recursive_sum(values):
    if len(values) == 0:
        return 0
    return values[0] + recursive_sum(values[1:])

print(recursive_sum([2.0, 3.5, 4.0]))  # 9.5
