# Instructor: Prof. Yanwei Wang
# Take an independent flat-list copy
raw = [2, 4, 6]
work = raw.copy()
work[0] = 99
print(raw)

# Selected regression checks
assert work == [99,4,6] and raw == [2,4,6]
assert work is not raw
