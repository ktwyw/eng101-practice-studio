# Instructor: Prof. Yanwei Wang
# Normalize an instrument label
raw = "  Pump-B  "
key = raw.strip().lower()
print(key)

# Selected regression checks
assert key == "pump-b"
assert raw == "  Pump-B  "
