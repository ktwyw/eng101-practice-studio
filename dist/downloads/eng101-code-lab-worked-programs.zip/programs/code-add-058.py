# Instructor: Prof. Yanwei Wang
# Raise to a nonnegative integer power
def power(x, n):
    if n == 0:
        return 1
    return x * power(x, n - 1)
print(power(2, 5))

# Selected regression checks
assert power(7,0) == 1
assert power(-2,3) == -8
