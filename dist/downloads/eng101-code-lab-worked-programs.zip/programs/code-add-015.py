# Instructor: Prof. Yanwei Wang
# Split a delimited record
raw = "A;21.5;good"
fields = raw.split(";")
print(fields)

# Selected regression checks
assert fields == ["A","21.5","good"]
