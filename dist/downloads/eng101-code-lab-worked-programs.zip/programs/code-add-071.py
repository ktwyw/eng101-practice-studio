# Instructor: Prof. Yanwei Wang
# Initialize independent object history
class Log:
    def __init__(self):
        self.history = []
    def add(self, value):
        self.history.append(value)
a, b = Log(), Log()
a.add(3)
print(a.history, b.history)

# Selected regression checks
assert a.history == [3]
assert b.history == []
assert a.history is not b.history
