# Instructor: Prof. Yanwei Wang
# Count list entries recursively
def length(values):
    if not values:
        return 0
    return 1 + length(values[1:])
print(length([3, 5, 7, 9]))

# Selected regression checks
assert length([]) == 0
assert length([8]) == 1
