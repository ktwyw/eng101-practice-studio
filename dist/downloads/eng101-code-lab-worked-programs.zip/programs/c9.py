# Instructor: Prof. Yanwei Wang
# Read the last measurement
readings = [11, 14, 19, 22]
latest = readings[-1]
print(latest)  # 22
