# Instructor: Prof. Yanwei Wang
# Check an inclusive limit
temperature = 75
if temperature >= 75:
    print("Check cooling")
else:
    print("Normal")
