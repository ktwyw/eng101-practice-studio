# Instructor: Prof. Yanwei Wang
# Report whether a capped loop converged
error = 1.0
tolerance = 0.01
for _ in range(3):
    error /= 2
converged = error <= tolerance
print(converged)

# Selected regression checks
assert error == 0.125 and converged is False
