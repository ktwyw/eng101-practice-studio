# Instructor: Prof. Yanwei Wang
# Build calibrated readings
raw = [18, 20, 22]
offset = 2
calibrated = [x + offset for x in raw]
print(calibrated)

# Selected regression checks
assert calibrated == [20,22,24] and raw == [18,20,22]
