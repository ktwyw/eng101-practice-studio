# Instructor: Prof. Yanwei Wang
# Count selected pair operations
n = 5
comparisons = 0
for i in range(n):
    for j in range(i+1, n):
        comparisons += 1
print(comparisons)

# Selected regression checks
assert comparisons == 10
