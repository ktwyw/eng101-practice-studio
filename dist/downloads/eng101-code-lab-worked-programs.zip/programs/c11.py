# Instructor: Prof. Yanwei Wang
# Count five iterations
# Five measurements
for i in range(5):
    print(i)
