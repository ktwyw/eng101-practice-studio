# Instructor: Prof. Yanwei Wang
# Group values by their label
records = [("A", 2), ("B", 5), ("A", 4)]
groups = {}
for label, value in records:
    groups.setdefault(label, []).append(value)
print(groups)

# Selected regression checks
assert groups == {"A":[2,4],"B":[5]}
