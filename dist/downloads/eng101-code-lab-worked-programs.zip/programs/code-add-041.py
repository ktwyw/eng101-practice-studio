# Instructor: Prof. Yanwei Wang
# Unpack a measurement tuple
record = ("A", 24, "C")
sensor, value, unit = record
print(sensor, value, unit)

# Selected regression checks
assert (sensor,value,unit) == record
