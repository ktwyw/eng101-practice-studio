# Instructor: Prof. Yanwei Wang
# Calculate a temperature rise
inlet_c = 16
outlet_c = 28
rise_c = outlet_c - inlet_c
print(rise_c)  # 12
