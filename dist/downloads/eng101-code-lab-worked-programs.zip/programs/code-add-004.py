# Instructor: Prof. Yanwei Wang
# Create a Boolean state flag
pressure = 105
active = pressure > 100
print(active)

# Selected regression checks
assert active is True
