# Instructor: Prof. Yanwei Wang
# Separate full groups and leftovers
count = 29
capacity = 6
groups, leftover = divmod(count, capacity)
print(groups, leftover)

# Selected regression checks
assert (groups,leftover) == (4,5)
assert groups*capacity+leftover == count
