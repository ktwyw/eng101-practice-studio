# Instructor: Prof. Yanwei Wang
# Create independent matrix rows
rows, cols = 2, 3
grid = [[0] * cols for _ in range(rows)]
grid[0][1] = 7
print(grid)

# Selected regression checks
assert grid[1] == [0,0,0] and grid[0] is not grid[1]
