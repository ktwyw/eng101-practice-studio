# Instructor: Prof. Yanwei Wang
# Count warnings with recursion
def count_above_recursive(readings, limit):
    if len(readings) == 0:
        return 0
    if readings[0] > limit:
        first_count = 1
    else:
        first_count = 0
    return first_count + count_above_recursive(readings[1:], limit)

print(count_above_recursive([79.0, 80.0, 81.0], 80.0))  # 1
