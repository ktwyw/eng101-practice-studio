# Instructor: Prof. Yanwei Wang
# Continue the recursive countdown
def countdown(n):
    if n <= 0:
        print("Launch")
        return
    print(n)
    countdown(n - 1)

countdown(3)
