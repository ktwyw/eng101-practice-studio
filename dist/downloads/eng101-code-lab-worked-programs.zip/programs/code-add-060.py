# Instructor: Prof. Yanwei Wang
# Reverse a string recursively
def reverse(text):
    if len(text) <= 1:
        return text
    return reverse(text[1:]) + text[0]
print(reverse("pump"))

# Selected regression checks
assert reverse("") == ""
assert reverse("A") == "A"
assert reverse("ab") == "ba"
