# Instructor: Prof. Yanwei Wang
# Accumulate measurements
readings = [3, 5, 7]
total = 0
for value in readings:
    total += value
print(total)  # 15
