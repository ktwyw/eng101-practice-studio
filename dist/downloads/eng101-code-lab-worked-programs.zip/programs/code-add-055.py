# Instructor: Prof. Yanwei Wang
# Pass an operation to a general helper
def apply(function, value):
    return function(value)
def cube(x):
    return x**3
print(apply(cube, 3))

# Selected regression checks
assert apply(abs,-4) == 4
