# Instructor: Prof. Yanwei Wang
# Require two operating constraints
temperature = 75
pressure = 180
if temperature <= 80 and pressure <= 200:
    print("Allowed")
else:
    print("Reject")

# Selected regression checks
assert temperature <= 80 and pressure <= 200
