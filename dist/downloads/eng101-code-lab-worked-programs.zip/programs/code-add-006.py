# Instructor: Prof. Yanwei Wang
# Find rectangular area
width_m = 0.3
height_m = 0.2
area_m2 = width_m * height_m
print(f"{area_m2:.3f}")

# Selected regression checks
assert abs(area_m2 - 0.06) < 1e-12
