# Instructor: Prof. Yanwei Wang
# Keep a value in range
pressure = 120
if 90 <= pressure <= 140:
    print("Safe interval")
