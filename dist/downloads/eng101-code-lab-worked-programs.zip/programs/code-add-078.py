# Instructor: Prof. Yanwei Wang
# Sort whole records by a numeric field
rows = [("A", 8), ("B", 3), ("C", 5)]
ordered = sorted(rows, key=lambda row: row[1])
print(ordered)

# Selected regression checks
assert [r[0] for r in ordered] == ["B","C","A"]
assert rows == [("A",8),("B",3),("C",5)]
