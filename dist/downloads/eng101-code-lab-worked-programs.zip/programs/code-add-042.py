# Instructor: Prof. Yanwei Wang
# Keep complete moving pairs
values = [2, 4, 8, 10]
means = [(values[i] + values[i+1]) / 2 for i in range(len(values)-1)]
print(means)

# Selected regression checks
assert means == [3.0,6.0,9.0]
