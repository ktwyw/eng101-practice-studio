# Instructor: Prof. Yanwei Wang
# Read both keys and values
readings = {"A": 2, "B": 5}
rows = []
for key, value in readings.items():
    rows.append((key, value))
print(rows)

# Selected regression checks
assert rows == [("A",2),("B",5)]
