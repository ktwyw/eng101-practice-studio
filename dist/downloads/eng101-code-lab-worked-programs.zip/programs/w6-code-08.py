# Instructor: Prof. Yanwei Wang
# Count each material sample
samples = ["Cu", "Al", "Cu"]
counts = {}
for material in samples:
    counts[material] = counts.get(material, 0) + 1
print(counts)  # {'Cu': 2, 'Al': 1}
