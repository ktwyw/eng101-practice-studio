# Instructor: Prof. Yanwei Wang
# Return a fresh transformed sequence
def shifted(values):
    return [x + 1 for x in values]
raw = [2, 4]
print(shifted(raw), raw)

# Selected regression checks
assert shifted([]) == []
assert raw == [2,4]
