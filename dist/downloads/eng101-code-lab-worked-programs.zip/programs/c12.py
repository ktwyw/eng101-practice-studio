# Instructor: Prof. Yanwei Wang
# Write a stopping rule
error = 1.0
tolerance = 0.01
while error > tolerance:
    error = error / 2
print(error)
