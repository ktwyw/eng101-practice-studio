# Instructor: Prof. Yanwei Wang
# Keep a snapshot before rebinding
speed = 12
previous = speed
speed = 20
print(previous, speed)

# Selected regression checks
assert previous == 12 and speed == 20
