# Instructor: Prof. Yanwei Wang
# Accumulate energy from power intervals
powers_w = [20, 30, 10]
dt = 2
energy_j = 0
for power in powers_w:
    energy_j += power * dt
print(energy_j)

# Selected regression checks
assert energy_j == 120
