# Instructor: Prof. Yanwei Wang
# Convert a sensor reading
raw = "23.5"
temperature = float(raw)
print(temperature)  # 23.5
