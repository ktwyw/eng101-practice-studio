# Instructor: Prof. Yanwei Wang
# Consume a remaining budget
remaining = 10
cost = 3
steps = 0
while remaining >= cost:
    remaining -= cost
    steps += 1
print(remaining, steps)

# Selected regression checks
assert remaining == 1 and steps == 3
