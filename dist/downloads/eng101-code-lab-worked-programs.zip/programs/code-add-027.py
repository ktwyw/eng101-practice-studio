# Instructor: Prof. Yanwei Wang
# Stop at a sentinel
values = [4, 6, -1, 100]
total = 0
for x in values:
    if x == -1:
        break
    total += x
print(total)

# Selected regression checks
assert total == 10
