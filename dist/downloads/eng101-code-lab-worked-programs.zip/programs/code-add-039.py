# Instructor: Prof. Yanwei Wang
# Filter missing readings
readings = [2, None, 0, 5]
valid = [x for x in readings if x is not None]
print(valid)

# Selected regression checks
assert valid == [2,0,5]
