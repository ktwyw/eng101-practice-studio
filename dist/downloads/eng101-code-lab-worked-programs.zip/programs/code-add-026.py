# Instructor: Prof. Yanwei Wang
# Count strict exceedances
values = [9, 10, 11, 15]
count = 0
for x in values:
    if x > 10:
        count += 1
print(count)

# Selected regression checks
assert count == 2
