# Instructor: Prof. Yanwei Wang
# Advance an index into a sequence
values = [3, 4, 5]
index = 0
total = 0
while index < len(values):
    total += values[index]
    index += 1
print(total)

# Selected regression checks
assert total == 12 and index == 3
