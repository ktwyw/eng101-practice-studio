# Instructor: Prof. Yanwei Wang
# Use a diameter in circular area
import math
diameter = 0.4
area = math.pi * (diameter / 2)**2
print(f"{area:.4f}")

# Selected regression checks
assert math.isclose(area, 0.12566370614359174, abs_tol=1e-12)
