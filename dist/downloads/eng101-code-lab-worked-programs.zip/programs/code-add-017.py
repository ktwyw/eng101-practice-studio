# Instructor: Prof. Yanwei Wang
# Count a pattern in a label
text = "AABAA"
count = text.count("AA")
print(count)

# Selected regression checks
assert count == 2
