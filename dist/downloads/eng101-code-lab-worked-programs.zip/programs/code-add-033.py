# Instructor: Prof. Yanwei Wang
# Halve a search interval
low, high = 0.0, 8.0
while high-low > 1:
    midpoint = (low+high)/2
    high = midpoint
print(low, high)

# Selected regression checks
assert (low,high) == (0.0,1.0)
