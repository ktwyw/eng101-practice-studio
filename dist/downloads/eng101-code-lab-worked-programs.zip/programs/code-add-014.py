# Instructor: Prof. Yanwei Wang
# Read an identifier suffix
label = "SEN-204"
suffix = label[-3:]
print(suffix)

# Selected regression checks
assert suffix == "204"
