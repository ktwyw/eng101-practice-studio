# Instructor: Prof. Yanwei Wang
# Compute kinetic energy
mass_kg = 4
speed_m_s = 3
energy_j = 0.5 * mass_kg * speed_m_s**2
print(energy_j)

# Selected regression checks
assert energy_j == 18
