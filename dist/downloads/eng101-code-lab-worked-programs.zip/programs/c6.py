# Instructor: Prof. Yanwei Wang
# Find the mean temperature
readings = [18, 21, 24]
mean_c = sum(readings) / len(readings)
print(mean_c)  # 21.0
