# Instructor: Prof. Yanwei Wang
# Preserve a fractional reading
raw = "3.75"
flow = float(raw)
print(flow * 2)

# Selected regression checks
assert flow == 3.75 and type(flow) is float
