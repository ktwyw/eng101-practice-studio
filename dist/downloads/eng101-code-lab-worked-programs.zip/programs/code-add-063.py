# Instructor: Prof. Yanwei Wang
# Compute ideal heating energy
mass_kg = 2
heat_capacity = 4200
rise_k = 5
energy_j = mass_kg * heat_capacity * rise_k
print(energy_j)

# Selected regression checks
assert energy_j == 42000
