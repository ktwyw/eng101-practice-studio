# Instructor: Prof. Yanwei Wang
# Initialize the base part of a subclass
class Base:
    def __init__(self, value):
        self.value = value
class Child(Base):
    def __init__(self, value, gain):
        super().__init__(value)
        self.gain = gain
c = Child(7, 2)
print(c.value, c.gain)

# Selected regression checks
assert isinstance(c,Base) and c.value == 7 and c.gain == 2
