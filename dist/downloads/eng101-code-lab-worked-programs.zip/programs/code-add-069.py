# Instructor: Prof. Yanwei Wang
# Catch an expected conversion failure
try:
    value = int("oops")
except ValueError:
    value = None
print(value)

# Selected regression checks
assert value is None
