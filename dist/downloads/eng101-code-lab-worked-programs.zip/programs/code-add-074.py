# Instructor: Prof. Yanwei Wang
# Protect an internal flat list
class History:
    def __init__(self):
        self._values = [2, 4]
    def values(self):
        return self._values.copy()
h = History()
external = h.values()
external.append(9)
print(h.values())

# Selected regression checks
assert h.values() == [2,4]
assert external == [2,4,9]
