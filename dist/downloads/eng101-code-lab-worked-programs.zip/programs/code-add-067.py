# Instructor: Prof. Yanwei Wang
# Reject nonfinite parsed values
import math
def parse(raw):
    value = float(raw)
    if not math.isfinite(value):
        raise ValueError("nonfinite")
    return value
try:
    parse("nan")
except ValueError:
    print("Rejected")

# Selected regression checks
assert parse("2.5") == 2.5
for raw in ["nan","inf","-inf"]:
    try:
        parse(raw)
    except ValueError:
        pass
    else:
        raise AssertionError("nonfinite accepted")
