# Instructor: Prof. Yanwei Wang
# Iterate over matching columns
times = [0, 1]
readings = [20, 23]
paired = []
for time, reading in zip(times, readings):
    paired.append((time, reading))
print(paired)

# Selected regression checks
assert paired == [(0,20),(1,23)]
