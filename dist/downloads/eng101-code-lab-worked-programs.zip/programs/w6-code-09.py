# Instructor: Prof. Yanwei Wang
# Convert a nested material property
record = {"yield_strength_pa": 250e6}
strength_mpa = record["yield_strength_pa"] / 1e6
print(strength_mpa)  # 250.0
