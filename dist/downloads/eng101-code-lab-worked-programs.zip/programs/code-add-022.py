# Instructor: Prof. Yanwei Wang
# Include a threshold in the upper band
score = 60
if score >= 80:
    print("high")
elif score >= 60:
    print("pass")
else:
    print("retry")

# Selected regression checks
assert score == 60
