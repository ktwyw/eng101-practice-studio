# Instructor: Prof. Yanwei Wang
# Use an explicit default reading
record = {"temperature": 22}
value = record.get("pressure", -1)
print(value)

# Selected regression checks
assert value == -1 and "pressure" not in record
