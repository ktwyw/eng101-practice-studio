# Instructor: Prof. Yanwei Wang
# Define a default scale factor

def scale(value, factor=2):
    return value*factor
print(scale(4), scale(4, 3))

# Selected regression checks
assert scale(0) == 0
assert scale(-2,3) == -6
