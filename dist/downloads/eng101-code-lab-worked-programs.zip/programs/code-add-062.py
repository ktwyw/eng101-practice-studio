# Instructor: Prof. Yanwei Wang
# Convert a pressure report to kilopascals
pressure_pa = 245000
pressure_kpa = pressure_pa / 1000
print(pressure_kpa)

# Selected regression checks
assert pressure_kpa == 245
