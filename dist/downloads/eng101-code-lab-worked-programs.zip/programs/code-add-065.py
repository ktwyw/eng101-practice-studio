# Instructor: Prof. Yanwei Wang
# Measure a square-root residual
target = 10
guess = 3.2
residual = abs(guess**2 - target)
print(f"{residual:.2f}")

# Selected regression checks
assert abs(residual-0.24) < 1e-12
