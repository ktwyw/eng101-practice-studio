# Instructor: Prof. Yanwei Wang
# Return a geometric calculation
def perimeter(width, height):
    return 2 * (width + height)
print(perimeter(3, 5))

# Selected regression checks
assert perimeter(0,5) == 10
assert perimeter(2,2) == 8
