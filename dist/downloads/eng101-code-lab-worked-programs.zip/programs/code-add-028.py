# Instructor: Prof. Yanwei Wang
# Retain indexed measurement pairs
values = [8, 12]
indexed = []
for i, value in enumerate(values):
    indexed.append((i, value))
print(indexed)

# Selected regression checks
assert indexed == [(0,8),(1,12)]
