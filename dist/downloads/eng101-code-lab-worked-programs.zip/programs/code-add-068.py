# Instructor: Prof. Yanwei Wang
# Check a floating-point known result
import math
result = 0.1 + 0.2
assert math.isclose(result, 0.3, abs_tol=1e-12)
print("Check passed")

# Selected regression checks
assert abs(result-0.3) < 1e-12
