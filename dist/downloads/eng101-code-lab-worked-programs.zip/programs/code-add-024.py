# Instructor: Prof. Yanwei Wang
# Traverse odd positions
positions = []
for i in range(1, 6, 2):
    positions.append(i)
print(positions)

# Selected regression checks
assert positions == [1,3,5]
