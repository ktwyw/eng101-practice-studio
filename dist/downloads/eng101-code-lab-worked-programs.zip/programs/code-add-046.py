# Instructor: Prof. Yanwei Wang
# Give each sensor a separate history
sensors = ["A", "B"]
histories = {key: [] for key in sensors}
histories["A"].append(3)
print(histories)

# Selected regression checks
assert histories["B"] == [] and histories["A"] is not histories["B"]
