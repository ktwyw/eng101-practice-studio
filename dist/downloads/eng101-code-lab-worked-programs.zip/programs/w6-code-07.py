# Instructor: Prof. Yanwei Wang
# Save a snapshot of dictionary keys
working = {"steel": 7850, "aluminum": 2700}
saved_keys = list(working.keys())
working["copper"] = 8960
print(saved_keys)  # ['steel', 'aluminum']
