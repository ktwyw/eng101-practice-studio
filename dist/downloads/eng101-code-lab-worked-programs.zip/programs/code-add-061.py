# Instructor: Prof. Yanwei Wang
# Apply Euclid’s recursive step
def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)
print(gcd(48, 18))

# Selected regression checks
assert gcd(9,0) == 9
assert gcd(7,5) == 1
