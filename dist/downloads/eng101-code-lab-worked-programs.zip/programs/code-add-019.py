# Instructor: Prof. Yanwei Wang
# Reject an out-of-range reading
value = 120
if value < 0 or value > 100:
    print("Outside")
else:
    print("Inside")

# Selected regression checks
assert not 0 <= value <= 100
