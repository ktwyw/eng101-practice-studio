# Instructor: Prof. Yanwei Wang
# Join report headings
names = ["time", "pressure", "flow"]
header = ", ".join(names)
print(header)

# Selected regression checks
assert header == "time, pressure, flow"
