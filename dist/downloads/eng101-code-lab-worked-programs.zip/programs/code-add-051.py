# Instructor: Prof. Yanwei Wang
# Return an empty-input policy
def mean(values):
    if not values:
        return None
    return sum(values)/len(values)
print(mean([]), mean([2, 6]))

# Selected regression checks
assert mean([5]) == 5
assert mean([]) is None
