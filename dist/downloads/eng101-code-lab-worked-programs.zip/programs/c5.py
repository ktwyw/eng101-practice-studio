# Instructor: Prof. Yanwei Wang
# Advance a while loop
step = 0
while step < 4:
    step += 1
print(step)  # 4
