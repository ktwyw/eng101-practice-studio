# Instructor: Prof. Yanwei Wang
# Parse an integer count
raw = "18"
count = int(raw)
print(count + 2)

# Selected regression checks
assert count == 18 and type(count) is int
