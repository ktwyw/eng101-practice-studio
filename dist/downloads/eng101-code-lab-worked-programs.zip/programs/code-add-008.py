# Instructor: Prof. Yanwei Wang
# Convert cubic millimetres
volume_mm3 = 5000
volume_m3 = volume_mm3 / 1000**3
print(f"{volume_m3:.9f}")

# Selected regression checks
assert abs(volume_m3 - 5e-6) < 1e-15
