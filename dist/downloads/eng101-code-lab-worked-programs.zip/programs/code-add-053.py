# Instructor: Prof. Yanwei Wang
# Call with named arguments
def ratio(numerator, denominator):
    return numerator/denominator
result = ratio(numerator=10, denominator=4)
print(result)

# Selected regression checks
assert result == 2.5
