# Instructor: Prof. Yanwei Wang
# Use a bounded convergence condition
error = 1.0
tolerance = 0.1
steps = 0
max_steps = 8
while error > tolerance and steps < max_steps:
    error /= 2
    steps += 1
print(error, steps)

# Selected regression checks
assert error <= tolerance and steps == 4
