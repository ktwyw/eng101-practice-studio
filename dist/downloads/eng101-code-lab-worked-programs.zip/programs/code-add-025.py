# Instructor: Prof. Yanwei Wang
# Accumulate squared readings
values = [2, 3, 4]
total = 0
for x in values:
    total += x**2
print(total)

# Selected regression checks
assert total == 29
