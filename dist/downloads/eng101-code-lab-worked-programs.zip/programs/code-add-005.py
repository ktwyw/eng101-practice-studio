# Instructor: Prof. Yanwei Wang
# Report a numeric type name
value = 4.5
kind = type(value).__name__
print(kind)

# Selected regression checks
assert kind == "float"
