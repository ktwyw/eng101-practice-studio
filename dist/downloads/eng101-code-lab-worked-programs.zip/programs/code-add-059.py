# Instructor: Prof. Yanwei Wang
# Sum the digits of a nonnegative integer
def digit_sum(n):
    if n < 10:
        return n
    return n % 10 + digit_sum(n // 10)
print(digit_sum(407))

# Selected regression checks
assert digit_sum(0) == 0
assert digit_sum(123) == 6
