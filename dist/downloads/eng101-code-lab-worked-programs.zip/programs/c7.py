# Instructor: Prof. Yanwei Wang
# Read a named measurement
sensor = {"pressure": 116, "temperature": 22}
pressure_kpa = sensor["pressure"]
print(pressure_kpa)  # 116
