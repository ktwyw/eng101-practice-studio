# Instructor: Prof. Yanwei Wang
# Sum mapping values
counts = {"Cu": 3, "Al": 2}
total = sum(counts.values())
print(total)

# Selected regression checks
assert total == 5
