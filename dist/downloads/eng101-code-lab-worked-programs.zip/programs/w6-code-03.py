# Instructor: Prof. Yanwei Wang
# Find the bisection midpoint
left = 0.0
right = 3.0
midpoint = (left + right) / 2
print(midpoint)  # 1.5
