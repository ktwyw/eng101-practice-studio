# Instructor: Prof. Yanwei Wang
# Update a mapped measurement
record = {"flow": 3, "head": 8}
record["flow"] = 7
print(record)

# Selected regression checks
assert record == {"flow":7,"head":8} and len(record) == 2
