# Instructor: Prof. Yanwei Wang
# Reuse an invariant total
values = [2, 3, 5]
total = sum(values)
fractions = []
for value in values:
    fractions.append(value/total)
print(fractions)

# Selected regression checks
assert total == 10
assert abs(sum(fractions)-1) < 1e-12
