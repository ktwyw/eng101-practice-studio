# Instructor: Prof. Yanwei Wang
# Exclude a known-small midpoint
def search(values, target):
    lo, hi = 0, len(values)-1
    while lo <= hi:
        mid = (lo+hi)//2
        if values[mid] == target:
            return mid
        if values[mid] < target:
            lo = mid + 1
        else:
            hi = mid-1
    return -1
print(search([2, 5, 9], 9))

# Selected regression checks
assert search([2,9],9) == 1
assert search([],4) == -1
assert search([2,5,9],7) == -1
