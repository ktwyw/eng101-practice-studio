# Instructor: Prof. Yanwei Wang
# Calculate a flow rate
volume_l = 96
time_s = 12
flow_l_s = volume_l / time_s
print(flow_l_s)  # 8.0
