# Instructor: Prof. Yanwei Wang
# Handle an empty mean input
values = []
if values:
    print(sum(values)/len(values))
else:
    print("No data")

# Selected regression checks
assert values == []
