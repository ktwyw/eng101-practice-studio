# Instructor: Prof. Yanwei Wang
# Calculate a percentage change
initial = 80
final = 100
percent = 100 * (final - initial) / initial
print(percent)

# Selected regression checks
assert percent == 25
