# Instructor: Prof. Yanwei Wang
# Extract a sensor prefix
label = "SEN-204"
prefix = label[:3]
print(prefix)

# Selected regression checks
assert prefix == "SEN"
