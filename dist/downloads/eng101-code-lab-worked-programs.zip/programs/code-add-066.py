# Instructor: Prof. Yanwei Wang
# Find the largest absolute deviation
reference = 20
readings = [17, 21, 25]
worst = max(abs(x - reference) for x in readings)
print(worst)

# Selected regression checks
assert worst == 5
