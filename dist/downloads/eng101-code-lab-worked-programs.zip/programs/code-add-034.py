# Instructor: Prof. Yanwei Wang
# Track a growing trial value
trial = 1
while trial < 20:
    trial *= 2
print(trial)

# Selected regression checks
assert trial == 32
