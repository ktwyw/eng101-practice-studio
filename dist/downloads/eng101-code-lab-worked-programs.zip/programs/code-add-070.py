# Instructor: Prof. Yanwei Wang
# Preserve state in an empty-input check
def first(values):
    if not values:
        raise ValueError("empty")
    return values[0]
try:
    first([])
except ValueError:
    print("Empty rejected")

# Selected regression checks
assert first([7]) == 7
assert first([0,1]) == 0
