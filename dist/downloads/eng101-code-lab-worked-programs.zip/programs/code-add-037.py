# Instructor: Prof. Yanwei Wang
# Keep a middle slice
values = [10, 20, 30, 40, 50]
middle = values[1:4]
print(middle)

# Selected regression checks
assert middle == [20,30,40]
