# Instructor: Prof. Yanwei Wang
# Read a nested sensor field
sensors = {"A": {"temperature": 20}, "B": {"temperature": 25}}
temperature = sensors["B"]["temperature"]
print(temperature)

# Selected regression checks
assert temperature == 25
