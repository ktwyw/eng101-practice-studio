# Instructor: Prof. Yanwei Wang
# Check evenness with a remainder
n = 18
even = n % 2 == 0
print(even)

# Selected regression checks
assert even is True
