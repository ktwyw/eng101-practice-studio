# Instructor: Prof. Yanwei Wang
# Return a computed object query
class Sensor:
    def __init__(self, value, gain):
        self.value, self.gain = value, gain
    def read(self):
        return self.value * self.gain
s = Sensor(4, 3)
print(s.read())

# Selected regression checks
assert Sensor(0,3).read() == 0
assert Sensor(-2,5).read() == -10
