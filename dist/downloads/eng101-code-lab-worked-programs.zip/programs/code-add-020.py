# Instructor: Prof. Yanwei Wang
# Choose a compact sign label
x = -4
label = "negative" if x < 0 else "nonnegative"
print(label)

# Selected regression checks
assert label == "negative"
