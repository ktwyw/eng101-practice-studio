ENG 101 Code lab: 100 worked programs
Instructor: Prof. Yanwei Wang

Try the missing line on the website before consulting a worked solution.
Each programs/*.py file is a complete program using the first accepted answer.
The new examples include selected regression assertions at the end. Run one
file at a time with Python 3.10 or later. No third-party packages are required.

catalog.csv identifies the topic, week, level, task, hint, and explanation.
expected-output.json records the expected printed output for all 100 programs.
The website compares Python-like tokens for its guided one-line checks; it does
not execute your code. Other valid approaches may differ from the guided answer.
These are formative practice activities. Engineering limits are illustrative.
