# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# A recursive table with two boundary cases
# Source: Mock C · C17

def choose(n, k):
    if k == 0 or k == n:
        return 1
    return choose(n - 1, k - 1) + choose(n - 1, k)

print(choose(4, 2))
print(choose(4, 0), choose(4, 4))
