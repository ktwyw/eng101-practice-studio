# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Exact model counts before interpreting doubling ratios
# Source: Week 10 · Original program study

def models(size):
    return size, size * size, size * (size.bit_length() - 1)

small, large = models(4), models(8)
print(small)
print(large)
print(tuple(new / old for old, new in zip(small, large)))

# Selected regression checks; keep assertions enabled.
assert models(16) == (16, 256, 64)
