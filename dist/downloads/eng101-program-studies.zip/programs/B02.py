# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Assignment order and saved values
# Source: Mock B · B02

x = 8
y = 3
saved = x
x = x - y
y = saved + y
power = x ** 2 - y
ratio = power / 2
print(x, y, saved)
print(power, ratio)
