# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Replacing and inserting list slices
# Source: Mock C · C14

values = [0, 1, 2, 3, 4]
values[1:4] = [8, 9]
values[2:2] = [6, 7]
last = values.pop()
print(values)
print(last, len(values))
print(values[::-1])
