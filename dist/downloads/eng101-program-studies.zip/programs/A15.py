# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# List aliases and copies
# Source: Mock A · A15

original = [2, 4, 6]
alias = original
copied = original[:]
alias[0] = 9
copied.append(8)
print(original)
print(copied)
print(alias is original)
print(copied == original)
