# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Reading records stored in tuples
# Source: Mock D · D13

pair = ("Cu", 3)
samples = (pair, ("Al", 5), ("Cu", 2))
print(samples[1][0])
print(samples[-1][1] + samples[0][1])
print("Cu" in samples, pair in samples)
print(pair * 2)
