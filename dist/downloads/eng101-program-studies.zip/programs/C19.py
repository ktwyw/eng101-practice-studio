# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Renaming a dictionary key
# Source: Mock C · C19

stock = {"A": 4, "B": 2}
stock["C"] = stock.pop("A")
stock["B"] += stock.get("D", 0)
stock["D"] = stock.get("D", 0) + 1
print(list(stock.keys()))
print(list(stock.values()))
print("A" in stock, "C" in stock)
print(stock.get("E", 5), len(stock))
