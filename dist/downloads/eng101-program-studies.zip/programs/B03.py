# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Text and numeric values
# Source: Mock B · B03

left = "6"
right = "2"
joined = left + right
repeated = right * 3
number = int(joined)
half = number / 2
is_equal = joined == number
print(joined, repeated)
print(number + int(right), half)
print(is_equal)
