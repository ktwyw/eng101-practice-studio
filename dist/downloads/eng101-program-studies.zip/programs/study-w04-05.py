# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# A default captures a value at definition time
# Source: Week 4 · Original program study

scale = 2

def convert(value, factor=scale):
    return value * factor

scale = 5
print(convert(3))
print(convert(3, scale))
print(scale)

# Selected regression checks; keep assertions enabled.
assert convert(0) == 0
assert convert(3, factor=4) == 12
