# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# Name mangling separates two internal counters
# Source: Week 9 · Original program study

class Base:
    def __init__(self):
        self.__count = 1

    def base_count(self):
        return self.__count

class Child(Base):
    def __init__(self):
        super().__init__()
        self.__count = 9

    def child_count(self):
        return self.__count

object_ = Child()
print(object_.base_count(), object_.child_count())
print(sorted(object_.__dict__))

# Selected regression checks; keep assertions enabled.
assert object_.base_count() == 1
assert object_.child_count() == 9
