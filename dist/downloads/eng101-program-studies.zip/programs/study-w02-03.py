# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# A sentinel that is read but not accumulated
# Source: Week 2 · Original program study

measurements = [4, 7, -1, 12]
position = 0
total = 0
while position < len(measurements):
    value = measurements[position]
    position += 1
    if value == -1:
        break
    total += value
print('Consumed:', position)
print('Total:', total)
print('Unread:', measurements[position:])
