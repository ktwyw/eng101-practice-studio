# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# Guarding a division with a condition
# Source: Mock D · D04

flow = 12
area = 0
if area != 0 and flow / area > 2:
    label = "fast"
elif area == 0:
    label = "no area"
else:
    label = "slow"
print(label)
print(area != 0)
