# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursive bisection
# Source: Week 6 · Example 03

# ENG 101 - Programming for Engineers | Week 6 | Example 03
# Recursive bisection: an impact-time calculation
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 27-29; Notes Sections 1.14-1.15 (pp. 18-20).
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

def bisection_recursive(function, left, right, tolerance):
    # Teaching version from the slides: a valid bracket is assumed.
    midpoint = (left + right) / 2
    if abs(function(midpoint)) < tolerance:
        return midpoint            # Base case: small residual only.
    if function(left) * function(midpoint) < 0:
        return bisection_recursive(
            function, left, midpoint, tolerance)
    return bisection_recursive(
        function, midpoint, right, tolerance)


def residual_time(t_s):
    # Height in m: release from rest, constant gravity, no air resistance.
    g = 9.81                       # m/s^2
    return 20.0 - 0.5 * g * t_s**2


left_s = 0.0
right_s = 3.0
height_tolerance_m = 1e-6
impact_time_s = bisection_recursive(
    residual_time, left_s, right_s, height_tolerance_m)
height_residual_m = residual_time(impact_time_s)

# Independent algebraic calculation within the SAME physical model.
analytical_time_s = (2 * 20.0 / 9.81)**0.5
print(f"Height at left endpoint: {residual_time(left_s):.3f} m")
print(f"Height at right endpoint: {residual_time(right_s):.3f} m")
print(f"Recursive estimate: {impact_time_s:.9f} s")
print(f"Analytical value: {analytical_time_s:.9f} s")
print(f"Height residual: {height_residual_m:.3e} m")
print("Residual test passed:",
      abs(height_residual_m) < height_tolerance_m)
print(f"Difference from analytical time: "
      f"{abs(impact_time_s - analytical_time_s):.3e} s")
