# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# A small design report converts mass before ranking cost
# Source: Week 14 · Original program study

volume_cm3 = 100
required_capacity = 10
candidates = [
    {'name': 'A', 'density_g_cm3': 2, 'capacity': 8, 'cost_per_kg': 30},
    {'name': 'B', 'density_g_cm3': 3, 'capacity': 12, 'cost_per_kg': 10},
    {'name': 'C', 'density_g_cm3': 4, 'capacity': 20, 'cost_per_kg': 15},
]
feasible = []
for row in candidates:
    mass_kg = row['density_g_cm3'] * volume_cm3 / 1000
    if row['capacity'] >= required_capacity:
        cost = mass_kg * row['cost_per_kg']
        feasible.append((cost, row['name'], mass_kg))
for cost, name, mass in sorted(feasible):
    print(f'{name}: {mass:.3f} kg, cost {cost:.2f}')
print('Selected:', min(feasible)[1] if feasible else None)

# Selected regression checks; keep assertions enabled.
assert len(feasible) == 2
assert min(feasible) == (3.0, 'B', 0.3)
