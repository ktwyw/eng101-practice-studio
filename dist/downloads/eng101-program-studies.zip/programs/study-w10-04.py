# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Triangular work from unique index pairs
# Source: Week 10 · Original program study

def pair_count(size):
    count = 0
    for left in range(size):
        for right in range(left + 1, size):
            count += 1
    return count

for size in [2, 4, 5]:
    print(size, pair_count(size), size * (size - 1) // 2)

# Selected regression checks; keep assertions enabled.
assert pair_count(0) == 0
assert pair_count(1) == 0
assert pair_count(6) == 15
