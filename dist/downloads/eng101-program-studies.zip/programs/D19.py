# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Reversing dictionary keys and values
# Source: Mock D · D19

readings = {"P1": 18, "P2": 20, "P3": 18}
by_temp = {}
for sensor, value in readings.items():
    by_temp[value] = sensor
print(by_temp)
print(list(by_temp.keys()))
print(18 in by_temp, "P1" in by_temp.values())
print(readings["P1"])
