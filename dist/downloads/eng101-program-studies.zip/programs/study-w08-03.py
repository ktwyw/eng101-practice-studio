# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# A running mean with a clear empty policy
# Source: Week 8 · Original program study

class RunningMean:
    def __init__(self):
        self.total = 0
        self.count = 0

    def add(self, value):
        self.total += value
        self.count += 1

    def mean(self):
        if self.count == 0:
            raise ValueError('no readings')
        return self.total / self.count

log = RunningMean()
for value in [2, 4, 9]:
    log.add(value)
print(log.count, log.total)
print(log.mean())

# Selected regression checks; keep assertions enabled.
assert log.count == 3
single = RunningMean()
single.add(7)
assert single.mean() == 7
