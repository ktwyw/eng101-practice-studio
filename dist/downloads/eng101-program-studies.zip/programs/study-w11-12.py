# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Index-based recursion avoids repeated tail slices
# Source: Week 11 · Original program study

calls = 0

def sum_from(values, index=0):
    global calls
    calls += 1
    if index == len(values):
        return 0
    return values[index] + sum_from(values, index + 1)

data = [1, 2, 3, 4]
print('Total:', sum_from(data))
print('Calls:', calls)
print('Tail entries a slicing version would copy:', len(data) * (len(data) - 1) // 2)

# Selected regression checks; keep assertions enabled.
assert calls == len(data) + 1
assert data == [1, 2, 3, 4]
