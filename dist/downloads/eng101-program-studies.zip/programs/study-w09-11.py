# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# An inherited class method constructs the receiving type
# Source: Week 9 · Original program study

class Record:
    def __init__(self, value):
        self.value = value

    @classmethod
    def from_text(cls, text):
        return cls(int(text))

class SpecialRecord(Record):
    pass

record = SpecialRecord.from_text('007')
print(record.value)
print(type(record).__name__)
print(isinstance(record, Record))

# Selected regression checks; keep assertions enabled.
assert type(SpecialRecord.from_text('2')) is SpecialRecord
assert Record.from_text('-3').value == -3
