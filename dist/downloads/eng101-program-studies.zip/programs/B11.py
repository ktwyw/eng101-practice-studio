# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Decomposing a sensor calculation
# Source: Mock B · B11

def normalise(raw, zero, span):
    return (raw - zero) / span

def classify(fraction):
    if fraction < 0.25:
        return "LOW"
    if fraction <= 0.75:
        return "MID"
    return "HIGH"

raw = 18
fraction = normalise(raw, 10, 16)
print(fraction, classify(fraction))
print(classify(normalise(22, 10, 16)))
