# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# A loop with two changing quantities
# Source: Mock D · D06

remaining = 23
step = 4
rounds = 0
while remaining >= step:
    remaining -= step
    step += 2
    rounds += 1
print(remaining, step, rounds)
