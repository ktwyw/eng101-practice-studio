# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Total recursive calls differ from live depth
# Source: Week 10 · Original program study

calls = 0
maximum_depth = 0

def visit(levels, depth=1):
    global calls, maximum_depth
    calls += 1
    maximum_depth = max(maximum_depth, depth)
    if levels > 0:
        visit(levels - 1, depth + 1)
        visit(levels - 1, depth + 1)

visit(3)
print('Calls:', calls)
print('Maximum depth:', maximum_depth)

# Selected regression checks; keep assertions enabled.
assert calls == 2 ** 4 - 1
assert maximum_depth == 4
