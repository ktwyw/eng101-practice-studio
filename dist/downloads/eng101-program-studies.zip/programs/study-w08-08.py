# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# Composition gives a device its own event log
# Source: Week 8 · Original program study

class EventLog:
    def __init__(self):
        self.events = []

    def write(self, text):
        self.events.append(text)

class Device:
    def __init__(self, name):
        self.name = name
        self.log = EventLog()

    def start(self):
        self.log.write(self.name + ': start')

first, second = Device('A'), Device('B')
first.start()
first.start()
second.start()
print(first.log.events)
print(second.log.events)

# Selected regression checks; keep assertions enabled.
assert first.log is not second.log
assert len(first.log.events) == 2
