# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# Container methods expose a history consistently
# Source: Week 8 · Original program study

class History:
    def __init__(self, values):
        self._values = list(values)

    def __len__(self):
        return len(self._values)

    def __iter__(self):
        return iter(self._values)

history = History([2, 5, 8])
print(len(history))
print(list(history))
print(sum(history))

# Selected regression checks; keep assertions enabled.
assert len(History([])) == 0
assert sum(history) == 15
