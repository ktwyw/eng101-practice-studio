# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Current and power from a resistor model
# Source: Week 1 · Original program study

voltage_v = 12.0
resistance_ohm = 6.0
current_a = voltage_v / resistance_ohm
power_w = voltage_v * current_a
alternative_w = current_a ** 2 * resistance_ohm
print(f'Current: {current_a:.1f} A')
print(f'Power: {power_w:.1f} W')
print(power_w == alternative_w)
