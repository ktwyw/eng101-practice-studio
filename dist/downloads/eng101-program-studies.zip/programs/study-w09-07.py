# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# A device delegates calibration to a contained policy
# Source: Week 9 · Original program study

class Affine:
    def __init__(self, gain, offset):
        self.gain, self.offset = gain, offset

    def apply(self, value):
        return self.gain * value + self.offset

class Device:
    def __init__(self, calibration):
        self.calibration = calibration

    def read(self, raw):
        return self.calibration.apply(raw)

device = Device(Affine(2, 1))
print(device.read(3))
device.calibration = Affine(1, -2)
print(device.read(3))

# Selected regression checks; keep assertions enabled.
assert Device(Affine(1, 0)).read(5) == 5
