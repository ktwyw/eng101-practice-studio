# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# Short-circuit evaluation preserves the division guard
# Source: Week 13 · Original program study

events = []

def positive_ratio(flow, area):
    events.append('division')
    return flow / area > 2

area = 0
result = area != 0 and positive_ratio(12, area)
print(result, events)
area = 4
result = area != 0 and positive_ratio(12, area)
print(result, events)

# Selected regression checks; keep assertions enabled.
assert events == ['division']
assert result is True
