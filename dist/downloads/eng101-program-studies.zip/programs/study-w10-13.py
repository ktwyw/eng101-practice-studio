# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Separating prefix preparation from range queries
# Source: Week 10 · Original program study

values = [2, 3, 5, 7]
prefix = [0]
for value in values:
    prefix.append(prefix[-1] + value)
queries = [(0, 2), (1, 4)]
answers = [prefix[stop] - prefix[start] for start, stop in queries]
print(prefix)
print(answers)
print('Preparation additions:', len(values))
print('Query subtractions:', len(queries))

# Selected regression checks; keep assertions enabled.
assert prefix[4] - prefix[0] == 17
assert prefix[2] - prefix[2] == 0
