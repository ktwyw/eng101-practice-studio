# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# Nested decisions and indentation
# Source: Mock B · B04

level = 4
override = False
status = "Idle"
if level > 3:
    if override:
        status = "Manual"
    else:
        status = "Auto"
else:
    status = "Standby"
print(status)
print(level > 3 and not override)
