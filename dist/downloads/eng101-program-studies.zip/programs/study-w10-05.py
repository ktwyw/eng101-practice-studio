# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Sequential loops add while nested loops multiply
# Source: Week 10 · Original program study

size = 4
sequential = 0
for index in range(size):
    sequential += 1
for index in range(size):
    sequential += 1
nested = 0
for row in range(size):
    for column in range(size):
        nested += 1
print('Sequential:', sequential)
print('Nested:', nested)

# Selected regression checks; keep assertions enabled.
assert sequential == 2 * size
assert nested == size * size
