# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Integer halving does not require a power of two
# Source: Week 10 · Original program study

remaining = 13
visited = [remaining]
steps = 0
while remaining > 1:
    remaining //= 2
    visited.append(remaining)
    steps += 1
print(visited)
print('Halvings:', steps)

# Selected regression checks; keep assertions enabled.
assert remaining == 1
assert len(visited) == steps + 1
