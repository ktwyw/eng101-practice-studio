# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# FIFO results with different front-removal work
# Source: Week 11 · Original program study

from collections import deque

items = list(range(5))
queue = deque(items)
shifted_references = 0
left, right = [], []
for _ in range(3):
    shifted_references += len(items) - 1
    left.append(items.pop(0))
    right.append(queue.popleft())
print(left, right)
print(items, list(queue))
print('List reference shifts:', shifted_references)

# Selected regression checks; keep assertions enabled.
assert left == right
assert items == list(queue)
