# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Checking a two-component mass balance
# Source: Week 1 · Original program study

mass_a_g = 12
mass_b_g = 8
total_g = mass_a_g + mass_b_g
fraction_a = mass_a_g / total_g
fraction_b = mass_b_g / total_g
print(f'A: {100 * fraction_a:.1f}%')
print(f'B: {100 * fraction_b:.1f}%')
print(f'Total: {total_g} g')
print(f'Fraction sum: {fraction_a + fraction_b:.1f}')
