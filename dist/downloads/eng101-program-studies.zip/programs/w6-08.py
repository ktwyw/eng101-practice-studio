# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Counting and grouping samples
# Source: Week 6 · Example 08

# ENG 101 - Programming for Engineers | Week 6 | Example 08
# Count and group material samples
# Instructor: Prof. Yanwei Wang
# Source: Mock A20 and D20; supporting slides PDF pp. 69, 72-75, 82 and 85; Notes Sections 3.3, 3.6-3.8 and 3.13-3.15.
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

# The pairs come from Mock D20. For THIS adaptation, mass is in grams.
# The original mock code does not specify a mass unit.
samples = [("Cu", 2), ("Al", 3), ("Cu", 5), ("Fe", 1), ("Al", 4)]
counts = {}
grouped_masses_g = {}

for material, mass_g in samples:
    # No earlier occurrence contributes a count of zero.
    counts[material] = counts.get(material, 0) + 1
    if material not in grouped_masses_g:
        # Each new key receives its OWN new list.
        grouped_masses_g[material] = []
    grouped_masses_g[material].append(mass_g)

print("Counts:", counts)
print("Grouped masses (g):", grouped_masses_g)
print("Number of material categories:", len(counts))
print("Number of individual samples:", len(samples))
print("All samples counted:", sum(counts.values()) == len(samples))

print("MATERIAL | COUNT | TOTAL MASS (g)")
for material, masses_g in grouped_masses_g.items():
    print(material, counts[material], sum(masses_g), sep=" | ")
print("Original samples:", samples)
