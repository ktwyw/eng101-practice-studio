# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# Equal records can have different identities
# Source: Week 8 · Original program study

class Tag:
    def __init__(self, text):
        self.text = text

    def __eq__(self, other):
        if not isinstance(other, Tag):
            return NotImplemented
        return self.text == other.text

first, second = Tag('S1'), Tag('S1')
alias = first
print(first == second)
print(first is second)
print(alias is first)
second.text = 'S2'
print(first == second)

# Selected regression checks; keep assertions enabled.
assert first.text == 'S1'
assert second.text == 'S2'
