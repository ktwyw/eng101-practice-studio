# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# Bisection reports an estimate, bound and status
# Source: Week 14 · Original program study

def bisect(function, low, high, tolerance, cap=100):
    if not low < high or tolerance <= 0:
        raise ValueError('ordered bounds and positive tolerance required')
    f_low, f_high = function(low), function(high)
    if f_low == 0:
        return low, 0.0, 0, True
    if f_high == 0:
        return high, 0.0, 0, True
    if f_low * f_high > 0:
        raise ValueError('sign bracket required')
    steps = 0
    while high - low > tolerance and steps < cap:
        middle = (low + high) / 2
        f_middle = function(middle)
        if f_middle == 0:
            return middle, 0.0, steps + 1, True
        if f_low * f_middle < 0:
            high = middle
        else:
            low, f_low = middle, f_middle
        steps += 1
    return (low + high) / 2, (high - low) / 2, steps, high - low <= tolerance

estimate, bound, steps, converged = bisect(lambda x: x * x - 2, 1.0, 2.0, 0.01)
print(f'Estimate: {estimate:.4f}')
print(f'Midpoint error bound: {bound:.6f}')
print('Steps:', steps, 'Converged:', converged)

# Selected regression checks; keep assertions enabled.
import math
assert abs(estimate - math.sqrt(2)) <= bound
assert bisect(lambda x: x, 0, 1, 0.01) == (0, 0.0, 0, True)
assert bisect(lambda x: x * x - 2, 1.0, 2.0, 0.01, cap=2)[-1] is False
