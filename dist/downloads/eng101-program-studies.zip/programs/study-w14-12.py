# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# A refinement table compares with an analytical integral
# Source: Week 14 · Original program study

def trapezoid_square(panels):
    step = 1 / panels
    total = 0.5 * (0 ** 2 + 1 ** 2)
    for index in range(1, panels):
        total += (index * step) ** 2
    return step * total

exact = 1 / 3
errors = []
for panels in [1, 2, 4]:
    estimate = trapezoid_square(panels)
    error = abs(estimate - exact)
    errors.append(error)
    print(f'n={panels} estimate={estimate:.6f} error={error:.6f}')
print(f'First error ratio: {errors[0] / errors[1]:.1f}')

# Selected regression checks; keep assertions enabled.
import math
assert trapezoid_square(1) == 0.5
assert math.isclose(errors[0] / errors[1], 4.0, abs_tol=1e-12)
assert errors[2] < errors[1] < errors[0]
