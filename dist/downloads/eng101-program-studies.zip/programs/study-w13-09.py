# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# Repeated rows and independently created rows
# Source: Week 13 · Original program study

shared_rows = [[0] * 3] * 2
separate_rows = [[0] * 3 for _ in range(2)]
shared_rows[0][1] = 7
separate_rows[0][1] = 7
print(shared_rows)
print(separate_rows)
print(shared_rows[0] is shared_rows[1])
print(separate_rows[0] is separate_rows[1])

# Selected regression checks; keep assertions enabled.
assert separate_rows[1] == [0, 0, 0]
assert shared_rows[1][1] == 7
