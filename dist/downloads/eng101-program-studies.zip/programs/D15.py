# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# One pass of adjacent list swaps
# Source: Mock D · D15

values = [5, 1, 4, 2]
swaps = 0
for i in range(len(values) - 1):
    if values[i] > values[i + 1]:
        values[i], values[i + 1] = values[i + 1], values[i]
        swaps += 1
print(values)
print(swaps)
print(values[-1])
