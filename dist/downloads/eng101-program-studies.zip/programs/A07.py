# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# String cleaning and slicing
# Source: Mock A · A07

raw = "  pump-A7  "
code = raw.strip().lower()
part = code[:4]
tail = code[-2:]
changed = code.replace("pump", "valve")
print(code)
print(part, tail)
print(changed)
print(code[::2])
