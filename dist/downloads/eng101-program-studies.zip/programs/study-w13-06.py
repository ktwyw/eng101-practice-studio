# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# Simultaneous and sequential state updates differ
# Source: Week 13 · Original program study

x, y, step = 1.0, 2.0, 0.1
new_x, new_y = x + step * y, y - step * x
sequential_x = x + step * y
sequential_y = y - step * sequential_x
print(f'Old-state updates: {new_x:.2f} {new_y:.2f}')
print(f'Sequential updates: {sequential_x:.2f} {sequential_y:.2f}')

# Selected regression checks; keep assertions enabled.
assert new_y != sequential_y
assert (x, y) == (1.0, 2.0)
