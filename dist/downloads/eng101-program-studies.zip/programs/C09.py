# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Bisection for a fractional cube root
# Source: Mock C · C09

target = 0.125
low = 0.0
high = 1.0
tolerance = 0.125
steps = 0
while high - low > tolerance:
    mid = (low + high) / 2
    if mid ** 3 < target:
        low = mid
    else:
        high = mid
    steps += 1
estimate = (low + high) / 2
print(steps)
print(low, high)
print(estimate)
