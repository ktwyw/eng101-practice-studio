# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# Inclusive integer sequences versus exclusive range stops
# Source: Week 13 · Original program study

start, stop, step = 1, 5, 2
python_values = list(range(start, stop, step))
inclusive_values = list(range(start, stop + 1, step))
print('Exclusive stop:', python_values)
print('Inclusive reached endpoint:', inclusive_values)
print('Endpoint not reached:', list(range(1, 6 + 1, 2)))

# Selected regression checks; keep assertions enabled.
assert inclusive_values[-1] == 5
assert stop not in python_values
