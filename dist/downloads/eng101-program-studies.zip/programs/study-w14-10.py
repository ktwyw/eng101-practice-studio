# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# Histogram boundaries preserve every observation
# Source: Week 14 · Original program study

times_s = [0, 59, 60, 119, 120]
counts = {}
for time_s in times_s:
    minute = time_s // 60
    counts[minute] = counts.get(minute, 0) + 1
for minute in sorted(counts):
    print(f'[{minute * 60}, {(minute + 1) * 60}): {counts[minute]}')
print('Observations:', sum(counts.values()))

# Selected regression checks; keep assertions enabled.
assert counts == {0: 2, 1: 2, 2: 1}
assert sum(counts.values()) == len(times_s)
