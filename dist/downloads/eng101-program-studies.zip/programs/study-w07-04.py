# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# A regression for the final adjacent pair
# Source: Week 7 · Original program study

def strictly_increasing(values):
    return all(values[i] < values[i + 1] for i in range(len(values) - 1))

cases = [[1, 2, 3], [1, 2, 2], [5], []]
for case in cases:
    print(case, strictly_increasing(case))

# Selected regression checks; keep assertions enabled.
assert strictly_increasing([1, 2])
assert not strictly_increasing([2, 1])
assert not strictly_increasing([1, 1])
