# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# A schedule separates energy, peak power and cost
# Source: Week 14 · Original program study

def energy_kwh(power_w, duration_h):
    return power_w * duration_h / 1000

schedule = [('idle', 0, 2), ('pump', 500, 3), ('heater', 1500, 1)]
energy = sum(energy_kwh(power, duration) for name, power, duration in schedule)
peak = max(power for name, power, duration in schedule)
tariff = 0.20
print(f'Energy: {energy:.2f} kWh')
print(f'Peak power: {peak} W')
print(f'Cost: {energy * tariff:.2f} currency units')
print('Scheduled hours:', sum(duration for name, power, duration in schedule))

# Selected regression checks; keep assertions enabled.
assert energy_kwh(1000, 1) == 1
assert energy == 3.0
assert peak == 1500
