# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Hoisting a normalization total out of a loop
# Source: Week 11 · Original program study

weights = [2, 3, 5]
denominator = sum(weights)
fractions = []
for weight in weights:
    fractions.append(weight / denominator)
print(fractions)
print(f'Sum: {sum(fractions):.1f}')
print('Full sums computed:', 1)

# Selected regression checks; keep assertions enabled.
assert denominator == 10
assert len(fractions) == len(weights)
