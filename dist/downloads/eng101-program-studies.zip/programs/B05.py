# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# Nested loops and running totals
# Source: Mock B · B05

total = 0
for row in range(1, 4):
    subtotal = 0
    for column in range(row):
        subtotal += row + column
    print(row, subtotal)
    total += subtotal
print("Total", total)
