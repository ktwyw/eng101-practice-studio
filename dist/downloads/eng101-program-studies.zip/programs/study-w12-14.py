# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Looking up the latest timestamp at or before a query
# Source: Week 12 · Original program study

from bisect import bisect_right

times = [0, 5, 10]
values = [18, 21, 20]

def latest_at(query):
    index = bisect_right(times, query) - 1
    return None if index < 0 else (times[index], values[index])

for query in [-1, 0, 7, 12]:
    print(query, latest_at(query))

# Selected regression checks; keep assertions enabled.
assert latest_at(5) == (5, 21)
assert latest_at(-2) is None
