# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Invalidating a cached mean after an update
# Source: Week 11 · Original program study

class MeanLog:
    def __init__(self):
        self.values = []
        self._cached = None
        self.computations = 0

    def add(self, value):
        self.values.append(value)
        self._cached = None

    def mean(self):
        if self._cached is None:
            self._cached = sum(self.values) / len(self.values)
            self.computations += 1
        return self._cached

log = MeanLog()
log.add(2)
log.add(4)
print(log.mean(), log.mean(), log.computations)
log.add(6)
print(log.mean(), log.computations)

# Selected regression checks; keep assertions enabled.
assert log.mean() == 4.0
assert log.computations == 2
