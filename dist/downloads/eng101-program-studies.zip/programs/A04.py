# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# Conditional equipment status
# Source: Mock A · A04

temperature = 80
pressure = 4
status = "Normal"
if temperature >= 80 and pressure > 5:
    status = "Shutdown"
elif temperature >= 80 or pressure > 5:
    status = "Warning"
else:
    status = "Normal"
print(status)
print(temperature >= 80, pressure > 5)
