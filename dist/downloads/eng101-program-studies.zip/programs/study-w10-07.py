# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# An outer scan with an inner halving loop
# Source: Week 10 · Original program study

size = 8
operations = 0
for row in range(size):
    remaining = size
    while remaining > 1:
        remaining //= 2
        operations += 1
print('Rows:', size)
print('Selected operations:', operations)

# Selected regression checks; keep assertions enabled.
assert operations == 8 * 3
