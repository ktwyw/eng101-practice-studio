# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Enumerating a small feasible design grid
# Source: Week 3 · Original program study

best = None
for width in range(1, 5):
    for height in range(1, 5):
        area = width * height
        cost = 3 * width + 2 * height
        if area >= 8 and (best is None or cost < best[0]):
            best = (cost, width, height)
print('Cost, width, height:', best)
