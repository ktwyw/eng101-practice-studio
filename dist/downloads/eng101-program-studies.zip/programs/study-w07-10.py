# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# Decimal inputs and an exact monetary expectation
# Source: Week 7 · Original program study

from decimal import Decimal

binary_total = 0.1 + 0.2
decimal_total = Decimal('0.1') + Decimal('0.2')
print(binary_total == 0.3)
print(decimal_total == Decimal('0.3'))
print(f'{decimal_total:.2f}')

# Selected regression checks; keep assertions enabled.
assert Decimal('0.10') + Decimal('0.20') == Decimal('0.30')
