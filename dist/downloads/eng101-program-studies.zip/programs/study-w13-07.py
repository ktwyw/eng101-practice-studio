# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# A similar-looking operator can mean something else
# Source: Week 13 · Original program study

base, exponent = 2, 3
print('Power:', base ** exponent)
print('Integer XOR:', base ^ exponent)
print('Built-in power:', pow(base, exponent))

# Selected regression checks; keep assertions enabled.
assert pow(3, 2) == 9
assert (3 ^ 2) == 1
