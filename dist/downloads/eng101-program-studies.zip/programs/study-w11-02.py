# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Prefix means without repeated prefix scans
# Source: Week 11 · Original program study

values = [2, 4, 9]
running = 0
means = []
for count, value in enumerate(values, start=1):
    running += value
    means.append(running / count)
print([f'{value:.2f}' for value in means])
print('Running additions:', len(values))
print('Repeated-prefix entries:', sum(range(1, len(values) + 1)))

# Selected regression checks; keep assertions enabled.
assert means[-1] == sum(values) / len(values)
assert len(means) == len(values)
