# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Interpolation handles the final calibration knot
# Source: Week 12 · Original program study

from bisect import bisect_right

knots = [0, 10, 20]
readings = [0, 100, 300]

def interpolate(value):
    if not knots[0] <= value <= knots[-1]:
        raise ValueError('outside calibration range')
    index = min(bisect_right(knots, value) - 1, len(knots) - 2)
    fraction = (value - knots[index]) / (knots[index + 1] - knots[index])
    return readings[index] + fraction * (readings[index + 1] - readings[index])

for value in [0, 15, 20]:
    print(value, interpolate(value))

# Selected regression checks; keep assertions enabled.
assert interpolate(10) == 100.0
assert interpolate(5) == 50.0
