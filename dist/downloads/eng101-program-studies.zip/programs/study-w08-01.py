# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# Independent counters and a reset command
# Source: Week 8 · Original program study

class Counter:
    def __init__(self, start=0):
        self.value = start

    def advance(self, step=1):
        self.value += step

    def reset(self):
        self.value = 0

first, second = Counter(), Counter(10)
first.advance(3)
second.advance()
print(first.value, second.value)
print(first.reset())
print(first.value, second.value)

# Selected regression checks; keep assertions enabled.
assert first is not second
assert first.value == 0 and second.value == 11
