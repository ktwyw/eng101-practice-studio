# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Guess and check for an integer factor
# Source: Mock B · B08

number = 91
divisor = 2
checks = 0
while divisor * divisor <= number:
    checks += 1
    if number % divisor == 0:
        break
    divisor += 1
if divisor * divisor <= number:
    print("Factor", divisor)
else:
    print("No small factor")
print(checks)
