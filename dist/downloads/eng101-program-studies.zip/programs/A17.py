# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursion with two base cases
# Source: Mock A · A17

def fibonacci(n):
    if n == 0:
        return 0
    if n == 1:
        return 1
    return fibonacci(n - 1) + fibonacci(n - 2)

print(fibonacci(5))
print(fibonacci(0), fibonacci(1))
