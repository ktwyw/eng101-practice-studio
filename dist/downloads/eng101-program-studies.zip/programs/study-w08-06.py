# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# Shadowing an immutable class setting
# Source: Week 8 · Original program study

class Sensor:
    unit = 'C'

first, second = Sensor(), Sensor()
first.unit = 'K'
print(first.unit, second.unit, Sensor.unit)
Sensor.unit = 'degC'
print(first.unit, second.unit, Sensor.unit)

# Selected regression checks; keep assertions enabled.
assert 'unit' in first.__dict__
assert 'unit' not in second.__dict__
