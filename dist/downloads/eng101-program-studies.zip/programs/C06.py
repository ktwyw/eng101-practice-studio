# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# Repeated halving and a stopping boundary
# Source: Mock C · C06

n = 45
steps = 0
odd_steps = 0
while n > 1:
    if n % 2 == 1:
        odd_steps += 1
    n //= 2
    steps += 1
print(n, steps)
print(odd_steps)
