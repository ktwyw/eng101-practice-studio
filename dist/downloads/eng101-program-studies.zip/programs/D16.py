# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursive and iterative integer powers
# Source: Mock D · D16

def power_rec(base, n):
    if n == 0:
        return 1
    return base * power_rec(base, n - 1)

def power_iter(base, n):
    result = 1
    for i in range(n):
        result *= base
    return result

print(power_rec(3, 4), power_iter(3, 4))
print(power_rec(7, 0), power_iter(7, 0))
