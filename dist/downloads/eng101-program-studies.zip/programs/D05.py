# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# Checking a running-total limit
# Source: Mock D · D05

text = "24312"
limit = 8
total = 0
used = 0
for ch in text:
    value = int(ch)
    if total + value > limit:
        break
    total += value
    used += 1
print(total, used)
print(ch)
