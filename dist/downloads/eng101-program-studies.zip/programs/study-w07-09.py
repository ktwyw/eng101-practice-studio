# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# Testing printed output separately from a return value
# Source: Week 7 · Original program study

import contextlib
import io

def report(value):
    print(f'Reading: {value:.1f}')
    return value * 2

buffer = io.StringIO()
with contextlib.redirect_stdout(buffer):
    result = report(3)
print('Captured:', repr(buffer.getvalue()))
print('Returned:', result)

# Selected regression checks; keep assertions enabled.
assert result == 6
assert buffer.getvalue() == 'Reading: 3.0\n'
