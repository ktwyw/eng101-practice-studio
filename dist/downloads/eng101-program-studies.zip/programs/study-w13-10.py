# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# Transposing rectangular real-valued data
# Source: Week 13 · Original program study

matrix = [[1, 2, 3], [4, 5, 6]]
transposed = [list(column) for column in zip(*matrix, strict=True)]
print(transposed)
print('Original shape:', len(matrix), len(matrix[0]))
print('Transposed shape:', len(transposed), len(transposed[0]))
print(matrix)

# Selected regression checks; keep assertions enabled.
assert transposed[0] == [1, 4]
assert matrix == [[1, 2, 3], [4, 5, 6]]
