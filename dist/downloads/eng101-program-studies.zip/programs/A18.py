# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursion on strings
# Source: Mock A · A18

def is_palindrome(text):
    if len(text) <= 1:
        return True
    if text[0] != text[-1]:
        return False
    return is_palindrome(text[1:-1])

word = "Level".lower()
print(is_palindrome(word))
print(is_palindrome("lever"))
print(is_palindrome(""))
