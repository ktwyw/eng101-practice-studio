# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Sorting complete records with two keys
# Source: Week 5 · Original program study

records = [('B', 2), ('A', 2), ('C', 1), ('D', 2)]
ordered = sorted(records, key=lambda row: (row[1], row[0]))
print(ordered)
print(records)

# Selected regression checks; keep assertions enabled.
assert ordered[0] == ('C', 1)
assert records[0] == ('B', 2)
