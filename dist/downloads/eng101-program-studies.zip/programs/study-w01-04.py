# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# A numeric value and its formatted label
# Source: Week 1 · Original program study

raw_voltage = ' 12.50 '
voltage_v = float(raw_voltage)
label = f'Voltage: {voltage_v:.2f} V'
print(voltage_v, type(voltage_v).__name__)
print(label)
print(type(label).__name__)
