# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Memoization separates a cold query from a warm query
# Source: Week 11 · Original program study

cache = {}

def choose(n, k):
    key = (n, k)
    if key not in cache:
        if k == 0 or k == n:
            cache[key] = 1
        else:
            cache[key] = choose(n - 1, k - 1) + choose(n - 1, k)
    return cache[key]

print(choose(4, 2))
prepared = len(cache)
print('Cached subproblems:', prepared)
print(choose(4, 2))
print('New subproblems:', len(cache) - prepared)

# Selected regression checks; keep assertions enabled.
assert cache[(4, 2)] == 6
assert choose(4, 0) == 1
