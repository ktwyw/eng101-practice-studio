# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# Translating one-based positions into Python indices
# Source: Week 13 · Original program study

def from_one_based(values, position):
    if not 1 <= position <= len(values):
        raise IndexError('position outside range')
    return values[position - 1]

data = [10, 20, 30]
print(from_one_based(data, 1))
print(from_one_based(data, 3))
try:
    from_one_based(data, 0)
except IndexError:
    print('Position zero rejected')

# Selected regression checks; keep assertions enabled.
assert from_one_based([8], 1) == 8
