# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursive search in an ordered list
# Source: Mock D · D17

def locate(values, target, low, high):
    if low > high:
        return -1
    mid = (low + high) // 2
    if values[mid] == target:
        return mid
    if values[mid] < target:
        return locate(values, target, mid + 1, high)
    return locate(values, target, low, mid - 1)

data = [2, 5, 8, 11, 14]
print(locate(data, 11, 0, len(data) - 1))
print(locate(data, 7, 0, len(data) - 1))
