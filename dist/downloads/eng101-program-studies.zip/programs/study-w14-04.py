# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# Fitting and checking a straight-line calibration
# Source: Week 14 · Original program study

def fit_line(xs, ys):
    if len(xs) != len(ys) or len(xs) < 2:
        raise ValueError('paired data required')
    x_mean, y_mean = sum(xs) / len(xs), sum(ys) / len(ys)
    denominator = sum((x - x_mean) ** 2 for x in xs)
    if denominator == 0:
        raise ValueError('distinct x values required')
    slope = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, ys)) / denominator
    return slope, y_mean - slope * x_mean

xs, ys = [0, 1, 2], [1, 3, 5]
slope, intercept = fit_line(xs, ys)
residuals = [y - (slope * x + intercept) for x, y in zip(xs, ys)]
print(f'Slope: {slope:.3f}, intercept: {intercept:.3f}')
print(f'Prediction at 3: {slope * 3 + intercept:.3f}')
print(f'Maximum absolute residual: {max(map(abs, residuals)):.3f}')

# Selected regression checks; keep assertions enabled.
assert fit_line([0, 2], [3, 7]) == (2.0, 3.0)
assert residuals == [0.0, 0.0, 0.0]
