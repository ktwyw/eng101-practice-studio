# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Powers and grouping of arithmetic
# Source: Mock D · D02

a = 2
b = 3
p = a ** b ** 2
q = (a ** b) ** 2
print(p, q)
print(p // q, p % q)
print((p - q) / q)
