# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Celsius and kelvin with explicit units
# Source: Week 1 · Original program study

temperature_c = 25.0
temperature_k = temperature_c + 273.15
print(f'Temperature: {temperature_c:.1f} C')
print(f'Absolute temperature: {temperature_k:.2f} K')
print(f'Recovered temperature: {temperature_k - 273.15:.1f} C')
