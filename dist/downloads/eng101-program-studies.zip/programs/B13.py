# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Tuples containing a list
# Source: Mock B · B13

record = ("T3", [12, 14], "C")
label, readings, unit = record
readings.append(16)
snapshot = tuple(readings)
readings[0] = 10
print(record[0], record[1][-1])
print(snapshot)
print(record[1])
