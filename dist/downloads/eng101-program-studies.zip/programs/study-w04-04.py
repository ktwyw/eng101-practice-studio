# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Reusing a transformation procedure
# Source: Week 4 · Original program study

def transform(values, operation):
    return [operation(value) for value in values]

def to_millimetres(metres):
    return metres * 1000

lengths = [0.1, 0.25, 0.5]
print(transform(lengths, to_millimetres))
print(transform(lengths, lambda value: value ** 2))
print(lengths)

# Selected regression checks; keep assertions enabled.
assert transform([], to_millimetres) == []
assert transform([2, 3], lambda value: value + 1) == [3, 4]
