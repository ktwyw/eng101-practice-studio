# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Filtering and reversing digit characters
# Source: Mock C · C07

code = "R2D4R6"
digits = ""
total = 0
for char in code:
    if char in "0123456789":
        digits = char + digits
        total += int(char)
print(digits)
print(code[1::2])
print(total)
