# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Printing versus returning a value
# Source: Mock B · B10

def display_double(value):
    print(value * 2)

def return_double(value):
    return value * 2

first = display_double(4)
second = return_double(4)
print(first, second)
