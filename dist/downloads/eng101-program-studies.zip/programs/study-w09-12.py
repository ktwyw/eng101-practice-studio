# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# A domain exception is also a ValueError
# Source: Week 9 · Original program study

class InvalidReading(ValueError):
    pass

def nonnegative(value):
    if value < 0:
        raise InvalidReading('reading below zero')
    return value

try:
    nonnegative(-2)
except ValueError as error:
    print(type(error).__name__)
    print(str(error))
print(nonnegative(0))

# Selected regression checks; keep assertions enabled.
assert issubclass(InvalidReading, ValueError)
assert nonnegative(4) == 4
