# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Selection sort fixes one position per pass
# Source: Week 12 · Original program study

values = [3, 1, 4, 2]
comparisons = 0
for start in range(len(values) - 1):
    smallest = start
    for index in range(start + 1, len(values)):
        comparisons += 1
        if values[index] < values[smallest]:
            smallest = index
    values[start], values[smallest] = values[smallest], values[start]
    print('Pass', start + 1, values)
print('Comparisons:', comparisons)

# Selected regression checks; keep assertions enabled.
assert values == [1, 2, 3, 4]
assert comparisons == 4 * 3 // 2
