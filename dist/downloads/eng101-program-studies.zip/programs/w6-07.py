# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Dictionary operations
# Source: Week 6 · Example 07

# ENG 101 - Programming for Engineers | Week 6 | Example 07
# Dictionaries: keys, values, updates, and missing data
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 69-76; Notes Sections 3.3-3.9 and Appendix A.3-A.4.
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

# Classroom values, not certified material-property data.
material_density = {"steel": 7850, "aluminum": 2700}
working = material_density.copy()   # Preserve this flat source record.
keys_view = working.keys()         # Reflects later dictionary changes.
saved_keys = list(working.keys())  # A separate snapshot of current keys.

working["copper"] = 8960           # New key: add an entry.
working["aluminum"] = 2710         # Existing key: what-if replacement.
print("Working dictionary:", working)
print("Live keys:", list(keys_view))
print("Saved keys:", saved_keys)
print("Values:", list(working.values()))
print("Items:", list(working.items()))

print("'steel' is a key:", "steel" in working)
print("7850 is a key:", 7850 in working)
print("7850 is a value:", 7850 in working.values())
print("Missing titanium:", working.get("titanium"))
print("Did get insert titanium?", "titanium" in working)

print("DENSITY TABLE (kg/m^3)")
for material, density in working.items():
    print(material, "->", density)

removed = working.pop("copper")    # Remove the entry and return its value.
print("Removed copper value:", removed)
del working["aluminum"]           # Delete this known entry.
print("Remaining working record:", working)
print("Original source record:", material_density)
