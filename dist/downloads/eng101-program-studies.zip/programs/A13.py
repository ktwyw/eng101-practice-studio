# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Tuples and unpacking
# Source: Mock A · A13

record = ("Pump A", 4, 12.5)
name, units, rating = record
single = (units,)
extended = record + (True,)
print(name)
print(record[-1])
print(record[1:])
print(len(single), len(extended))
