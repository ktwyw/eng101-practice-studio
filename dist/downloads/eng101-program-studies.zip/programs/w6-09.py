# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Nested material lookup
# Source: Week 6 · Example 09

# ENG 101 - Programming for Engineers | Week 6 | Example 09
# Nested dictionaries: material-property lookup
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 77-80 and 86-88; Notes Sections 3.10-3.12 and 3.16-3.17.
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

# Exact illustrative property values from the lecture slides.
materials = {
    "steel": {
        "density_kg_m3": 7850,
        "yield_strength_pa": 250e6,
        "elastic_modulus_pa": 200e9
    },
    "aluminum": {
        "density_kg_m3": 2700,
        "yield_strength_pa": 150e6,
        "elastic_modulus_pa": 69e9
    }
}

# Fixed requests make every branch easy to reproduce.
requests = [" Steel ", "aluminum", "titanium", "Aluminium"]
for raw_name in requests:
    selected = raw_name.strip().lower()
    record = materials.get(selected)
    print("Request:", repr(raw_name), "-> key:", repr(selected))
    if record is None:
        print("  Unknown material; no properties invented.")
    else:
        # The given inner schema supplies these required fields.
        density = record["density_kg_m3"]
        strength_mpa = record["yield_strength_pa"] / 1e6
        modulus_gpa = record["elastic_modulus_pa"] / 1e9
        print(f"  Density: {density} kg/m^3")
        print(f"  Yield strength: {strength_mpa:.1f} MPa")
        print(f"  Elastic modulus: {modulus_gpa:.1f} GPa")

print("Stored steel strength is still:",
      materials["steel"]["yield_strength_pa"], "Pa")
