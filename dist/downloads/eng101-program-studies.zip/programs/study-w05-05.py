# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Recording consecutive state runs
# Source: Week 5 · Original program study

states = ['idle', 'idle', 'run', 'run', 'run', 'idle']
runs = []
for state in states:
    if runs and runs[-1][0] == state:
        label, count = runs[-1]
        runs[-1] = (label, count + 1)
    else:
        runs.append((state, 1))
print(runs)
print(sum(count for label, count in runs))

# Selected regression checks; keep assertions enabled.
assert runs[0] == ('idle', 2)
assert sum(count for _, count in runs) == len(states)
