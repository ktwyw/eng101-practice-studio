# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Summarizing CSV rows without retaining every record
# Source: Week 11 · Original program study

import csv
import io

text = """time,value
0,2
1,4
2,9
"""
total = 0.0
count = 0
for row in csv.DictReader(io.StringIO(text)):
    total += float(row['value'])
    count += 1
print('Rows:', count)
print('Mean:', total / count)

# Selected regression checks; keep assertions enabled.
assert count == 3
assert total == 15.0
