# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Counting comparisons in a minimum scan
# Source: Week 10 · Original program study

def minimum_with_count(values):
    smallest = values[0]
    comparisons = 0
    for value in values[1:]:
        comparisons += 1
        if value < smallest:
            smallest = value
    return smallest, comparisons

print(minimum_with_count([5, 2, 7, 1]))
print(minimum_with_count([9]))

# Selected regression checks; keep assertions enabled.
assert minimum_with_count([-2, -5, -1]) == (-5, 2)
