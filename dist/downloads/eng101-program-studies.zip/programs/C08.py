# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# A bounded guess-and-check search
# Source: Mock C · C08

target = 30
guess = 0
checks = 0
while guess <= 8:
    checks += 1
    if guess * (guess + 1) == target:
        break
    guess += 1
print(guess, checks)
print(guess <= 8)
