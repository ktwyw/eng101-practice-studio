# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Finding overlapping text patterns
# Source: Mock B · B07

text = "ABABA"
pattern = "ABA"
count = 0
positions = ""
for i in range(len(text) - len(pattern) + 1):
    if text[i:i + len(pattern)] == pattern:
        count += 1
        positions += str(i)
print(count, positions)
print(text[::-1])
print(text[1:4])
