# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Removing, extending, and sorting lists
# Source: Mock B · B14

values = [5, 2, 5, 1]
ordered = sorted(values)
values.remove(5)
values.extend([3, 2])
returned = values.sort()
print(values)
print(ordered)
print(returned)
print(values.count(2), values.index(3))
