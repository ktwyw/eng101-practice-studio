# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# A calibrated-reading query derives its value
# Source: Week 8 · Original program study

class Reading:
    def __init__(self, raw, gain, offset):
        self.raw = raw
        self.gain = gain
        self.offset = offset

    def value(self):
        return self.gain * self.raw + self.offset

sensor = Reading(4, 2, 1)
print(sensor.value())
sensor.raw = 6
print(sensor.value())
print(sensor.raw)

# Selected regression checks; keep assertions enabled.
assert Reading(0, 2, 1).value() == 1
assert sensor.value() == 13
