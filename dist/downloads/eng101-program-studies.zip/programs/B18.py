# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursively removing a character
# Source: Mock B · B18

def remove_char(text, unwanted):
    if text == "":
        return ""
    rest = remove_char(text[1:], unwanted)
    if text[0] == unwanted:
        return rest
    return text[0] + rest

word = "banana"
cleaned = remove_char(word, "a")
print(cleaned)
print(word)
