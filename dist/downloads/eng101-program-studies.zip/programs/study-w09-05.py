# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# A frozen record rejects ordinary reassignment
# Source: Week 9 · Original program study

from dataclasses import dataclass, FrozenInstanceError

@dataclass(frozen=True)
class Calibration:
    gain: float
    offset: float

calibration = Calibration(2.0, 1.0)
try:
    calibration.gain = 3.0
except FrozenInstanceError:
    print('Reassignment rejected')
print(calibration)

# Selected regression checks; keep assertions enabled.
assert calibration.gain == 2.0
assert calibration == Calibration(2.0, 1.0)
