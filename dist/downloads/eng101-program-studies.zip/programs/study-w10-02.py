# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Linear search reports its examined entries
# Source: Week 10 · Original program study

def find(values, target):
    checks = 0
    for index, value in enumerate(values):
        checks += 1
        if value == target:
            return index, checks
    return -1, checks

data = [4, 8, 12, 16]
print(find(data, 12))
print(find(data, 5))
print(find([], 5))

# Selected regression checks; keep assertions enabled.
assert find([8, 8], 8) == (0, 1)
