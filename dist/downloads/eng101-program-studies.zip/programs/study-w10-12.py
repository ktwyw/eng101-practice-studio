# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Required output can itself have product size
# Source: Week 10 · Original program study

labels = ['A', 'B', 'C']
loads = [1, 2]
cases = []
for label in labels:
    for load in loads:
        cases.append((label, load))
print(cases)
print('Output records:', len(cases))

# Selected regression checks; keep assertions enabled.
assert len(cases) == len(labels) * len(loads)
