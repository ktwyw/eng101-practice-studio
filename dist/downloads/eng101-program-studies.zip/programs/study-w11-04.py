# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# A bottom-up minimum-coin table
# Source: Week 11 · Original program study

coins = [1, 3, 4]
limit = 6
cost = [0] + [limit + 1] * limit
last = [None] * (limit + 1)
for amount in range(1, limit + 1):
    for coin in coins:
        if coin <= amount and cost[amount - coin] + 1 < cost[amount]:
            cost[amount] = cost[amount - coin] + 1
            last[amount] = coin
answer, remaining = [], limit
while remaining:
    answer.append(last[remaining])
    remaining -= last[remaining]
print(cost)
print('Minimum coins:', cost[limit])
print('One solution:', answer)

# Selected regression checks; keep assertions enabled.
assert cost[6] == 2
assert sum(answer) == limit
assert len(answer) == cost[limit]
