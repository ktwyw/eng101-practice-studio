# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursive and iterative common divisors
# Source: Mock B · B16

def gcd_recursive(a, b):
    if b == 0:
        return a
    return gcd_recursive(b, a % b)

def gcd_iterative(a, b):
    while b != 0:
        a, b = b, a % b
    return a

print(gcd_recursive(30, 18))
print(gcd_iterative(30, 18))
