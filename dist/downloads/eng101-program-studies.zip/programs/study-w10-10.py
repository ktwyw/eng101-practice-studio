# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Input order changes an early-exit scan
# Source: Week 10 · Original program study

def checks_until(values, target):
    checks = 0
    for value in values:
        checks += 1
        if value == target:
            break
    return checks

data = [8, 1, 2, 3]
print(checks_until(data, 8))
print(checks_until(list(reversed(data)), 8))
print(checks_until(data, 9))

# Selected regression checks; keep assertions enabled.
assert checks_until([], 1) == 0
assert checks_until([1], 1) == 1
