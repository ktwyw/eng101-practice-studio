# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Ordered queries share a forward-only search position
# Source: Week 11 · Original program study

values = [1, 2, 4, 6, 8]
queries = [2, 4, 8, 10]
position = 0
advances = 0
answers = []
for target in queries:
    while position < len(values) and values[position] < target:
        position += 1
        advances += 1
    found = position < len(values) and values[position] == target
    answers.append(position if found else -1)
print(answers)
print('Pointer advances:', advances)

# Selected regression checks; keep assertions enabled.
assert answers == [1, 2, 4, -1]
assert advances <= len(values)
