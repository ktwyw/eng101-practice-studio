# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# An accumulator function and return placement
# Source: Mock C · C10

def sum_multiples(limit):
    total = 0
    for n in range(1, limit + 1):
        if n % 3 == 0:
            total += n
    return total

first = sum_multiples(7)
second = sum_multiples(2)
print(first, second)
print(sum_multiples(0))
