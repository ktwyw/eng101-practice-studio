# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Updating values and building text
# Source: Mock C · C03

value = 5
saved = value
value += 3
value /= 2
text = str(saved)
label = text + "0"
print(value, saved)
print(label)
print(value == saved)
