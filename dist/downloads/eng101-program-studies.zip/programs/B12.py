# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Local names and default parameters
# Source: Mock B · B12

gain = 3

def scale(value, gain=2):
    value = value * gain
    return value

def combine(value):
    return scale(value) + scale(value, gain=1)

reading = 5
result = combine(reading)
print(reading, result)
print(gain)
