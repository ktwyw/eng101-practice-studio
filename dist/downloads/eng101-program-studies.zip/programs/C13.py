# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Tuple unpacking and simultaneous swapping
# Source: Mock C · C13

point = (2, 5)
x, y = point
x, y = y, x
moved = (x + 1, y - 1)
route = point + moved
print(point)
print(moved)
print(route[::2])
print(route[-1])
