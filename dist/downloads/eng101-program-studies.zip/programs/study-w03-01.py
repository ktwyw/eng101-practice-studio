# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Separating a sensor label from its reading
# Source: Week 3 · Original program study

record = '  pump-07 : 12.5  '
label, separator, raw_value = record.partition(':')
print(label.strip().upper())
print(separator == ':')
print(float(raw_value))
print(record.count(':'))
