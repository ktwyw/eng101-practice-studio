# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Finding a character with recursion
# Source: Mock C · C18

def first_index(text, target):
    if text == "":
        return -1
    if text[0] == target:
        return 0
    rest = first_index(text[1:], target)
    if rest == -1:
        return -1
    return rest + 1

print(first_index("banana", "n"))
print(first_index("banana", "z"))
print(first_index("", "b"))
