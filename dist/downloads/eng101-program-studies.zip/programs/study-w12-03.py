# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Stable insertion sort keeps equal-key records in order
# Source: Week 12 · Original program study

records = [('A', 2), ('B', 1), ('C', 2), ('D', 1)]
ordered = records.copy()
for index in range(1, len(ordered)):
    item = ordered[index]
    position = index
    while position > 0 and ordered[position - 1][1] > item[1]:
        ordered[position] = ordered[position - 1]
        position -= 1
    ordered[position] = item
print(ordered)
print(records)

# Selected regression checks; keep assertions enabled.
assert ordered == sorted(records, key=lambda row: row[1])
assert records[0] == ('A', 2)
