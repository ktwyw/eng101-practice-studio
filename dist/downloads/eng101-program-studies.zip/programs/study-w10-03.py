# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Counting midpoint probes in binary search
# Source: Week 10 · Original program study

def binary_find(values, target):
    low, high, probes = 0, len(values) - 1, 0
    while low <= high:
        middle = (low + high) // 2
        probes += 1
        if values[middle] == target:
            return middle, probes
        if values[middle] < target:
            low = middle + 1
        else:
            high = middle - 1
    return -1, probes

data = [2, 4, 6, 8, 10, 12, 14]
print(binary_find(data, 12))
print(binary_find(data, 13))

# Selected regression checks; keep assertions enabled.
assert binary_find([], 3) == (-1, 0)
assert binary_find([3], 3) == (0, 1)
