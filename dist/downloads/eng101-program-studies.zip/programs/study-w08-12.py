# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# A named constructor makes conversion explicit
# Source: Week 8 · Original program study

class Temperature:
    def __init__(self, celsius):
        self.celsius = celsius

    @classmethod
    def from_kelvin(cls, kelvin):
        return cls(kelvin - 273.15)

    def text(self):
        return f'{self.celsius:.2f} C'

first = Temperature(25)
second = Temperature.from_kelvin(298.15)
print(first.text())
print(second.text())
print(isinstance(second, Temperature))

# Selected regression checks; keep assertions enabled.
assert Temperature.from_kelvin(273.15).celsius == 0.0
