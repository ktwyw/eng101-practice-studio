# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Composing geometry and mass calculations
# Source: Week 4 · Original program study

import math

def cylinder_volume(radius_m, length_m):
    return math.pi * radius_m ** 2 * length_m

def mass_kg(volume_m3, density_kg_m3):
    return volume_m3 * density_kg_m3

volume = cylinder_volume(0.01, 0.5)
mass = mass_kg(volume, 2700)
print(f'Volume: {volume:.6f} m^3')
print(f'Mass: {mass:.3f} kg')

# Selected regression checks; keep assertions enabled.
assert cylinder_volume(0, 1) == 0
assert mass_kg(0.002, 1000) == 2
