# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursive output order
# Source: Week 6 · Example 01

# ENG 101 - Programming for Engineers | Week 6 | Example 01
# Recursive calls: descent and unwinding
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 8-10; Notes Sections 1.3-1.4 (pp. 8-10).
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

def countdown(n):
    # Base case: finish this call without making another call.
    if n <= 0:
        print("Launch")
        return
    print(n)                       # Runs during descent.
    countdown(n - 1)               # Give the next call a smaller n.


def countdown_after(n):
    if n <= 0:
        print("Launch")
        return
    countdown_after(n - 1)         # Wait for the smaller call.
    print(n)                       # Runs during unwinding.


print("PRINT BEFORE THE RECURSIVE CALL")
returned_value = countdown(3)
print("Returned value:", returned_value)

print("PRINT AFTER THE RECURSIVE CALL")
returned_value = countdown_after(3)
print("Returned value:", returned_value)

print("BASE-CASE TEST")
countdown(0)
