# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# Testing an empty-input contract
# Source: Week 7 · Original program study

def mean(values):
    if not values:
        raise ValueError('at least one value required')
    return sum(values) / len(values)

print(mean([2, 4, 6]))
try:
    mean([])
except ValueError as error:
    print(type(error).__name__, str(error))

# Selected regression checks; keep assertions enabled.
assert mean([5]) == 5.0
assert mean([-2, 2]) == 0.0
