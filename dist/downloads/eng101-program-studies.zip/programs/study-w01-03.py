# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Splitting elapsed seconds into a clock display
# Source: Week 1 · Original program study

elapsed_s = 3671
hours, remainder = divmod(elapsed_s, 3600)
minutes, seconds = divmod(remainder, 60)
print(hours, minutes, seconds)
print(f'{hours:02}:{minutes:02}:{seconds:02}')
print(hours * 3600 + minutes * 60 + seconds == elapsed_s)
