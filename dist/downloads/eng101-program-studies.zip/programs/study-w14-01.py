# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# A measurement pipeline keeps times and rejection counts
# Source: Week 14 · Original program study

import csv
import io
import math

text = """time,value,unit
0,18,C
1,bad,C
3,22,C
4,300,K
"""
accepted = []
rejected = 0
for row in csv.DictReader(io.StringIO(text)):
    try:
        time_s = int(row['time'])
        value = float(row['value'])
        if row['unit'] == 'K':
            value -= 273.15
        elif row['unit'] != 'C':
            raise ValueError('unknown unit')
        if not math.isfinite(value):
            raise ValueError('nonfinite reading')
    except ValueError:
        rejected += 1
    else:
        accepted.append((time_s, value))
print('Accepted:', len(accepted), 'Rejected:', rejected)
print('Times:', [time for time, value in accepted])
print(f'Mean: {sum(value for time, value in accepted) / len(accepted):.2f} C')

# Selected regression checks; keep assertions enabled.
assert len(accepted) == 3 and rejected == 1
assert math.isclose(accepted[-1][1], 26.85, abs_tol=1e-12)
