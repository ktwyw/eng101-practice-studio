# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Positional arguments and keyword order
# Source: Mock C · C12

def blend(a, b, weight=1):
    return (weight * a + b) / (weight + 1)

first = blend(2, 8)
second = blend(2, 8, 3)
third = blend(b=2, a=8, weight=3)
print(first)
print(second)
print(third)
