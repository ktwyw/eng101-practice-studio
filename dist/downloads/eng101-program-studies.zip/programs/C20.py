# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Accumulating sample masses by category
# Source: Mock C · C20

batches = [("Cu", 2), ("Al", 3), ("Cu", 4), ("Al", 1), ("Fe", 5)]
totals = {}
for material, mass in batches:
    if material not in totals:
        totals[material] = 0
    totals[material] += mass
selected = []
for material in totals:
    if totals[material] >= 5:
        selected.append(material)
print(totals)
print(selected)
print(sum(totals.values()))
