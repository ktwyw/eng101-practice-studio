# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# An annulus calculation with a helper function
# Source: Week 4 · Original program study

import math

def annulus_area(outer, inner):
    return math.pi * (outer ** 2 - inner ** 2)

outer_m, inner_m = 3.0, 1.0
area_m2 = annulus_area(outer_m, inner_m)
print(f'Area: {area_m2:.3f} m^2')
print(annulus_area(2.0, 2.0) == 0.0)

# Selected regression checks; keep assertions enabled.
assert math.isclose(annulus_area(3, 1), 8 * math.pi)
assert annulus_area(0, 0) == 0
