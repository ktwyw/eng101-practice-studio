# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# Counting only complete pairs in a nested search
# Source: Week 2 · Original program study

pairs = 0
for left in range(4):
    for right in range(left + 1, 4):
        if left + right == 3:
            print(left, right)
            pairs += 1
print('Matches:', pairs)
