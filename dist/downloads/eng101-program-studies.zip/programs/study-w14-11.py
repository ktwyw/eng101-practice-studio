# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# A versioned report caches an immutable input snapshot
# Source: Week 14 · Original program study

class Report:
    def __init__(self, values):
        self._values = tuple(values)
        self.revision = 0
        self._cached = None
        self.computations = 0

    def replace(self, values):
        self._values = tuple(values)
        self.revision += 1
        self._cached = None

    def summary(self):
        if self._cached is None:
            values = self._values
            self._cached = (len(values), sum(values) / len(values), max(values) - min(values))
            self.computations += 1
        return self._cached

source = [2, 4]
report = Report(source)
source.append(100)
print('Revision', report.revision, report.summary())
report.summary()
print('Computations:', report.computations)
report.replace([1, 5, 9])
print('Revision', report.revision, report.summary())
print('Computations:', report.computations)

# Selected regression checks; keep assertions enabled.
assert report.summary() == (3, 5.0, 8)
assert report.computations == 2
assert source == [2, 4, 100]
