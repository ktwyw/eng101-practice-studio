# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# Separating conversion from a finite-value policy
# Source: Week 7 · Original program study

import math

def parse_length(raw):
    value = float(raw)
    if not math.isfinite(value) or value < 0:
        raise ValueError('finite nonnegative length required')
    return value

for raw in [' 2.5 ', '-1', 'nan', 'inf', 'bad']:
    try:
        print(raw.strip(), 'accepted', parse_length(raw))
    except ValueError:
        print(raw.strip(), 'rejected')

# Selected regression checks; keep assertions enabled.
assert parse_length('0') == 0.0
assert parse_length('1e2') == 100.0
