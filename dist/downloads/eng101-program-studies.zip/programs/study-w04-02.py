# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# A keyword argument that controls presentation
# Source: Week 4 · Original program study

def mean_text(values, *, decimals=1):
    average = sum(values) / len(values)
    return f'{average:.{decimals}f}'

readings = [2, 3, 6]
print(mean_text(readings))
print(mean_text(readings, decimals=3))
print(readings)

# Selected regression checks; keep assertions enabled.
assert mean_text([4], decimals=2) == '4.00'
assert readings == [2, 3, 6]
