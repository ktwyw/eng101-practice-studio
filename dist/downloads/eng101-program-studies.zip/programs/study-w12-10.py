# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Intersecting sorted lists with duplicate multiplicities
# Source: Week 12 · Original program study

left = [1, 2, 2, 5, 7]
right = [2, 2, 2, 5, 8]
i = j = 0
common = []
while i < len(left) and j < len(right):
    if left[i] == right[j]:
        common.append(left[i])
        i += 1
        j += 1
    elif left[i] < right[j]:
        i += 1
    else:
        j += 1
print(common)

# Selected regression checks; keep assertions enabled.
from collections import Counter
assert Counter(common) == Counter(left) & Counter(right)
