# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Dictionary updates, views, and totals
# Source: Mock B · B20

stock = {"bolt": 4, "nut": 6}
keys_view = stock.keys()
saved_keys = list(stock.keys())
stock.update({"nut": 8, "washer": 3})
total = 0
for item, amount in stock.items():
    total += amount
print(list(keys_view))
print(saved_keys)
print(total)
print("nut" in stock, 8 in stock.values())
