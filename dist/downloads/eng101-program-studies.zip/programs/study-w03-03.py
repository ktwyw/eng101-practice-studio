# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Preserving empty fields when splitting records
# Source: Week 3 · Original program study

record = 'S1,,23.5,'
fields = record.split(',')
print(fields)
print('Fields:', len(fields))
for position, field in enumerate(fields):
    if field == '':
        print('Missing field:', position)
