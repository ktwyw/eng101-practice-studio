# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# A small data class with a geometry method
# Source: Week 8 · Original program study

from dataclasses import dataclass
import math

@dataclass
class Point:
    x: float
    y: float

    def distance_from_origin(self):
        return math.hypot(self.x, self.y)

point = Point(3, 4)
print(point)
print(point.distance_from_origin())
print(point == Point(3, 4))

# Selected regression checks; keep assertions enabled.
assert Point(0, 0).distance_from_origin() == 0
assert point is not Point(3, 4)
