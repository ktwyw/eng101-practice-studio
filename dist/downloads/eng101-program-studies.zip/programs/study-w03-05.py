# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# An explicit decimal-comma input policy
# Source: Week 3 · Original program study

for raw in ['1,25', '2.50', '1,234.5']:
    if ',' in raw and '.' in raw:
        print(raw, 'ambiguous')
    elif raw.count(',') <= 1:
        print(raw, float(raw.replace(',', '.')))
