# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Pairing unequal columns with an explicit missing marker
# Source: Week 5 · Original program study

from itertools import zip_longest

times = [0, 1, 2]
values = [12, 15]
pairs = list(zip_longest(times, values, fillvalue=None))
print(pairs)
print([time for time, value in pairs if value is None])
print(list(zip(times, values)))

# Selected regression checks; keep assertions enabled.
assert pairs[-1] == (2, None)
assert list(zip_longest([], [], fillvalue=None)) == []
