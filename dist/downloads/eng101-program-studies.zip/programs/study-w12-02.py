# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Two insertion boundaries count duplicates
# Source: Week 12 · Original program study

from bisect import bisect_left, bisect_right

data = [1, 3, 3, 3, 8]
for target in [3, 4, 8]:
    first = bisect_left(data, target)
    after = bisect_right(data, target)
    print(target, first, after, after - first)

# Selected regression checks; keep assertions enabled.
assert bisect_right(data, 3) - bisect_left(data, 3) == 3
assert bisect_left([], 1) == 0
