# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Separating first occurrences from repeats
# Source: Mock C · C15

values = [3, 1, 3, 2, 1]
unique = []
repeats = []
for value in values:
    if value in unique:
        repeats.append(value)
    else:
        unique.append(value)
print(unique)
print(repeats)
print(values)
