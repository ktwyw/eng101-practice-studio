# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Searching for a cube that meets a threshold
# Source: Mock D · D08

target = 50
guess = 0
checks = 0
while True:
    checks += 1
    if guess ** 3 >= target:
        break
    guess += 1
print(guess, checks)
print((guess - 1) ** 3 < target <= guess ** 3)
print(guess ** 3 - target)
