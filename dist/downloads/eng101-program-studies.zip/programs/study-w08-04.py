# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# A bounded setting validates before updating
# Source: Week 8 · Original program study

class Setting:
    def __init__(self, value):
        self.value = 0
        self.set(value)

    def set(self, value):
        if not 0 <= value <= 100:
            raise ValueError('outside range')
        self.value = value

setting = Setting(40)
try:
    setting.set(120)
except ValueError:
    print('Rejected')
print(setting.value)
setting.set(100)
print(setting.value)

# Selected regression checks; keep assertions enabled.
assert setting.value == 100
setting.set(0)
assert setting.value == 0
