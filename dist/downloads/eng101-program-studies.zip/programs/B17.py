# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursion with three base inputs
# Source: Mock B · B17

def ways(n):
    if n == 0:
        return 1
    if n == 1 or n == 2:
        return 1
    return ways(n - 1) + ways(n - 3)

print(ways(4))
print(ways(0), ways(2))
