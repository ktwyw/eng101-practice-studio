# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Building an index with a first-occurrence policy
# Source: Week 11 · Original program study

materials = ['Cu', 'Al', 'Cu', 'Fe']
first_index = {}
for index, label in enumerate(materials):
    first_index.setdefault(label, index)
queries = ['Cu', 'Fe', 'X']
print(first_index)
print([first_index.get(label, -1) for label in queries])

# Selected regression checks; keep assertions enabled.
assert first_index['Cu'] == materials.index('Cu')
assert first_index.get('missing', -1) == -1
