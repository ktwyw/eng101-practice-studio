# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Bisection with a fixed iteration budget
# Source: Mock D · D09

target = 5.0
low = 2.0
high = 3.0
steps = 0
while steps < 3:
    mid = (low + high) / 2
    if mid ** 2 < target:
        low = mid
    else:
        high = mid
    steps += 1
print(low, high)
print(mid)
print((low + high) / 2)
