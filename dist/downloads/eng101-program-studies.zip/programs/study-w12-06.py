# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Binary search with descending order
# Source: Week 12 · Original program study

def descending_find(values, target):
    low, high = 0, len(values) - 1
    while low <= high:
        middle = (low + high) // 2
        if values[middle] == target:
            return middle
        if values[middle] > target:
            low = middle + 1
        else:
            high = middle - 1
    return -1

data = [12, 9, 6, 3]
print(descending_find(data, 9))
print(descending_find(data, 4))

# Selected regression checks; keep assertions enabled.
assert descending_find([], 2) == -1
assert descending_find([3], 3) == 0
