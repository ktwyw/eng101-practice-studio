# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# A fixed-size inner loop is a constant factor
# Source: Week 10 · Original program study

def work(rows):
    operations = 0
    for row in range(rows):
        for channel in range(3):
            operations += 1
    return operations

print(work(4))
print(work(8))
print(work(8) / work(4))

# Selected regression checks; keep assertions enabled.
assert work(0) == 0
assert work(1) == 3
