# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# A defensive snapshot copies nested rows
# Source: Week 9 · Original program study

import copy

class Table:
    def __init__(self, rows):
        self._rows = copy.deepcopy(rows)

    def snapshot(self):
        return copy.deepcopy(self._rows)

source = [[1, 2], [3, 4]]
table = Table(source)
source[0][0] = 8
snapshot = table.snapshot()
snapshot[1][1] = 9
print(source)
print(snapshot)
print(table.snapshot())

# Selected regression checks; keep assertions enabled.
assert table.snapshot() == [[1, 2], [3, 4]]
assert table.snapshot() is not table.snapshot()
