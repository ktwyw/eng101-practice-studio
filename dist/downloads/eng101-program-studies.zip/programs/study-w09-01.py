# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# One area client with two shape implementations
# Source: Week 9 · Original program study

import math

class Rectangle:
    def __init__(self, width, height):
        self.width, self.height = width, height

    def area(self):
        return self.width * self.height

class Circle:
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

for shape in [Rectangle(2, 3), Circle(1)]:
    print(f'{shape.area():.3f}')

# Selected regression checks; keep assertions enabled.
assert Rectangle(0, 5).area() == 0
assert math.isclose(Circle(2).area(), 4 * math.pi)
