# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Sensor report
# Source: Week 6 · Example 10

# ENG 101 - Programming for Engineers | Week 6 | Example 10
# Integrated example: a sensor record and recursive report
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 81-82 and 92-93; Notes Sections 3.13, 3.19 and worked solution 4.5(12) (pp. 62-64).
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

def count_above_recursive(readings, limit):
    if len(readings) == 0:
        return 0
    if readings[0] > limit:
        first_count = 1
    else:
        first_count = 0
    return first_count + count_above_recursive(readings[1:], limit)


def count_above_iterative(readings, limit):
    total = 0
    for reading in readings:
        if reading > limit:
            total += 1
    return total


# Retain the lecture's fields, values, and strict warning rule.
sensor = {
    "id": "T-101", "quantity": "temperature", "unit": "C",
    "location": "heat exchanger outlet", "calibrated": True,
    "warning_limit": 80.0,
    "readings_c": [72.1, 73.5, 75.0, 81.2, 79.8]
}
readings = sensor["readings_c"]
saved_readings = readings.copy()
limit = sensor["warning_limit"]
recursive_count = count_above_recursive(readings, limit)
iterative_count = count_above_iterative(readings, limit)

# Calculated results go in a NEW report, not into the raw sensor record.
report = {
    "sensor_id": sensor["id"],
    "number_of_readings": len(readings),
    "warning_count": recursive_count,
    "methods_agree": recursive_count == iterative_count
}
print("SENSOR REPORT")
for key, value in report.items():
    print(f"{key}: {value}")
print("Raw readings unchanged:", readings == saved_readings)

# Explicit expectations check empty, boundary, and above-limit inputs.
tests = [([], 0), ([80.0], 0), ([81.0], 1), ([79.0, 80.0, 81.0], 1)]
print("BOUNDARY TESTS: readings -> recursive | iterative | passed")
for test_readings, expected in tests:
    rec = count_above_recursive(test_readings, limit)
    itr = count_above_iterative(test_readings, limit)
    passed = rec == expected and itr == expected
    print(test_readings, "->", rec, "|", itr, "|", passed)
