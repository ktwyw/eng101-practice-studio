# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Dictionaries with coordinate keys
# Source: Mock B · B19

temperatures = {(0, 0): 18, (0, 1): 21}
point = (1, 0)
temperatures[point] = 19
temperatures[(0, 1)] += 2
old = temperatures.pop((0, 0))
print(temperatures.get((0, 0), -1))
print(temperatures[point], old)
print(list(temperatures.keys()))
