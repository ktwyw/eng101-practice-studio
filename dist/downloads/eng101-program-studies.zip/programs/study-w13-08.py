# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# A checked zero-based accessor rejects negative indices
# Source: Week 13 · Original program study

def checked_character(text, index):
    if not 0 <= index < len(text):
        raise IndexError('invalid zero-based index')
    return text[index]

text = 'ABC'
print('Python negative index:', text[-1])
print('Checked index two:', checked_character(text, 2))
try:
    checked_character(text, -1)
except IndexError:
    print('Negative index rejected by contract')

# Selected regression checks; keep assertions enabled.
assert checked_character('A', 0) == 'A'
