# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursive list operations
# Source: Week 6 · Example 06

# ENG 101 - Programming for Engineers | Week 6 | Example 06
# List recursion: accumulate all values or stop at a match
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 51-55; Notes Sections 2.10-2.11 (pp. 30-32).
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

def recursive_sum(values):
    if len(values) == 0:
        return 0                   # No remaining contribution.
    return values[0] + recursive_sum(values[1:])


def contains_recursive(values, target):
    if len(values) == 0:
        return False               # Base case 1: nothing remains.
    if values[0] == target:
        return True                # Base case 2: a match is enough.
    return contains_recursive(values[1:], target)


# Exact slide values; their physical unit is not specified in the source.
readings = [2.0, 3.5, 4.0]
saved_readings = readings.copy()
print("Input readings:", readings)
print("Recursive sum:", recursive_sum(readings))
print("Empty-list sum:", recursive_sum([]))
print("Contains 3.5:", contains_recursive(readings, 3.5))
print("Contains 9.0:", contains_recursive(readings, 9.0))
print("Empty list contains 3.5:", contains_recursive([], 3.5))
print("Original list unchanged:", readings == saved_readings)
