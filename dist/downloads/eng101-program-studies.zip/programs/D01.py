# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Calculating a mixture percentage
# Source: Mock D · D01

solute = 8
solvent = 32
total = solute + solvent
percent = 100 * solute / total
solvent = solvent + 8
print(total, solvent)
print(percent)
print(percent == 20)
