# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# An inventory transfer preserves state on rejection
# Source: Week 14 · Original program study

def transfer(stock, source, destination, amount):
    if source == destination or source not in stock or destination not in stock:
        raise ValueError('two known distinct locations required')
    if type(amount) is not int or amount <= 0 or amount > stock[source]:
        raise ValueError('invalid amount')
    stock[source] -= amount
    stock[destination] += amount

stock = {'A': 5, 'B': 1}
transfer(stock, 'A', 'B', 3)
print(stock)
before = stock.copy()
try:
    transfer(stock, 'A', 'B', 4)
except ValueError:
    print('Rejected update preserved state:', stock == before)
print('Total items:', sum(stock.values()))

# Selected regression checks; keep assertions enabled.
assert stock == before
assert sum(stock.values()) == 6
