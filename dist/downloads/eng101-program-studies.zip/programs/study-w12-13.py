# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Odd and even medians from a sorted copy
# Source: Week 12 · Original program study

def median(values):
    if not values:
        raise ValueError('empty data')
    ordered = sorted(values)
    middle = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[middle]
    return (ordered[middle - 1] + ordered[middle]) / 2

data = [9, 1, 5]
print(median(data))
print(median([8, 2, 4, 6]))
print(data)

# Selected regression checks; keep assertions enabled.
assert median([7]) == 7
assert median([-3, -1]) == -2.0
assert data == [9, 1, 5]
