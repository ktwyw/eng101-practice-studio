# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Decomposing a calculation into helpers
# Source: Mock D · D11

def square(x):
    return x * x

def spread(a, b):
    centre = (a + b) / 2
    return (square(a - centre) + square(b - centre)) / 2

result = spread(2, 6)
print(result)
print(square(3))
print(spread(5, 5))
