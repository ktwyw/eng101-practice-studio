# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Returning a compact measurement summary
# Source: Week 4 · Original program study

def describe(values):
    return min(values), max(values), max(values) - min(values)

low, high, span = describe([8, 3, 11, 5])
print('Low:', low)
print('High:', high)
print('Span:', span)

# Selected regression checks; keep assertions enabled.
assert describe([4]) == (4, 4, 0)
assert describe([-2, 3]) == (-2, 3, 5)
