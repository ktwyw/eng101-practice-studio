# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# A subclass preserves an inherited reporting contract
# Source: Week 9 · Original program study

class Instrument:
    def read(self):
        return 4

    def report(self):
        return f'Reading: {self.read()}'

class DoubledInstrument(Instrument):
    def read(self):
        return 2 * super().read()

for instrument in [Instrument(), DoubledInstrument()]:
    print(instrument.report())

# Selected regression checks; keep assertions enabled.
assert DoubledInstrument().read() == 8
assert Instrument().report() == 'Reading: 4'
