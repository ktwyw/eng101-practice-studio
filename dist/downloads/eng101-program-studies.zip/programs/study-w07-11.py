# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# Checking a numerical derivative against a known result
# Source: Week 7 · Original program study

import math

def derivative(function, x, step):
    return (function(x + step) - function(x - step)) / (2 * step)

estimate = derivative(lambda x: x * x, 3.0, 0.5)
print(f'Estimate: {estimate:.2f}')
print('Matches known derivative:', math.isclose(estimate, 6.0, abs_tol=1e-12))

# Selected regression checks; keep assertions enabled.
assert derivative(lambda x: 5 * x + 2, 1, 0.5) == 5
