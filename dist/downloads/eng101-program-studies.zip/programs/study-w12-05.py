# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# A stable merge chooses the left record on ties
# Source: Week 12 · Original program study

left = [('A', 1), ('B', 3)]
right = [('C', 1), ('D', 2)]
i = j = 0
merged = []
while i < len(left) and j < len(right):
    if left[i][1] <= right[j][1]:
        merged.append(left[i])
        i += 1
    else:
        merged.append(right[j])
        j += 1
merged.extend(left[i:])
merged.extend(right[j:])
print(merged)

# Selected regression checks; keep assertions enabled.
assert merged == sorted(left + right, key=lambda row: row[1])
assert len(merged) == len(left) + len(right)
