# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Dictionary counting keys and values
# Source: Mock A · A20

materials = ["steel", "glass", "steel", "wood", "glass", "steel"]
counts = {}
for material in materials:
    counts[material] = counts.get(material, 0) + 1
keys = list(counts.keys())
values = list(counts.values())
print(counts)
print(keys)
print(values)
print(sum(values))
