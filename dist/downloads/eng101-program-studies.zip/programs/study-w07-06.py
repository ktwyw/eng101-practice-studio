# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# A metamorphic check for a sum
# Source: Week 7 · Original program study

def total(values):
    answer = 0
    for value in values:
        answer += value
    return answer

data = [2, -1, 5]
scaled = [3 * value for value in data]
shifted = [value + 4 for value in data]
print(total(data))
print(total(scaled) == 3 * total(data))
print(total(shifted) == total(data) + 4 * len(data))

# Selected regression checks; keep assertions enabled.
assert total([]) == 0
assert total([7]) == 7
assert total(data) == 6
