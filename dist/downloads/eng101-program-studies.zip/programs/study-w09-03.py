# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# A property keeps a rectangle result current
# Source: Week 9 · Original program study

class Rectangle:
    def __init__(self, width, height):
        self.width, self.height = width, height

    @property
    def area(self):
        return self.width * self.height

shape = Rectangle(2, 5)
print(shape.area)
shape.width = 4
print(shape.area)
print('area' in shape.__dict__)

# Selected regression checks; keep assertions enabled.
assert shape.area == 20
assert Rectangle(0, 5).area == 0
