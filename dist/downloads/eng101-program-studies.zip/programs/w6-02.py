# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Factorial: recursion and iteration
# Source: Week 6 · Example 02

# ENG 101 - Programming for Engineers | Week 6 | Example 02
# Factorial: recursion, iteration, and input checks
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 14-25; Notes Sections 1.7-1.12 and worked solution 4.5(2).
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

def factorial_recursive(n):
    # Retain the slide's validation policy; see the bool note in the guide.
    if not isinstance(n, int) or n < 0:
        return None
    if n == 0:
        return 1                   # The neutral value for multiplication.
    return n * factorial_recursive(n - 1)


def factorial_iterative(n):
    # Use the same input policy when comparing the two methods.
    if not isinstance(n, int) or n < 0:
        return None
    result = 1
    for value in range(1, n + 1):
        result *= value
    return result                  # Return after the complete loop.


# Expected results are written independently of either implementation.
tests = [(0, 1), (1, 1), (2, 2), (3, 6), (4, 24), (5, 120),
         (-1, None), (2.5, None)]
print("n | recursive | iterative | expected | passed")
for n, expected in tests:
    recursive_value = factorial_recursive(n)
    iterative_value = factorial_iterative(n)
    passed = (recursive_value == expected
              and iterative_value == expected)
    print(n, recursive_value, iterative_value, expected, passed,
          sep=" | ")
