# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# A generator evaluates only the requested prefix
# Source: Week 11 · Original program study

visited = []

def squares(limit):
    for value in range(limit):
        visited.append(value)
        yield value * value

stream = squares(5)
print('Before:', visited)
print(next(stream))
print(next(stream))
print('Visited:', visited)

# Selected regression checks; keep assertions enabled.
assert visited == [0, 1]
