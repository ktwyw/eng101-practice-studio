# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Returning the first matching value
# Source: Mock D · D12

def first_multiple(start, stop, divisor=3):
    while start < stop:
        if start % divisor == 0:
            return start
        start += 1
    return None

print(first_multiple(4, 10))
print(first_multiple(4, 6))
print(first_multiple(5, 10, 4))
