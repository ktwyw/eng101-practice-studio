# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# Two sensor objects produce a common summary report
# Source: Week 14 · Original program study

class SensorLog:
    def __init__(self, name, gain=1, offset=0):
        self.name, self.gain, self.offset = name, gain, offset
        self._values = []

    def add(self, raw):
        self._values.append(self.gain * raw + self.offset)

    def summary(self):
        return len(self._values), sum(self._values) / len(self._values), max(self._values)

    def snapshot(self):
        return tuple(self._values)

first, second = SensorLog('A'), SensorLog('B', gain=2, offset=1)
for raw in [20, 22, 24]:
    first.add(raw)
for raw in [8, 10]:
    second.add(raw)
for log in [first, second]:
    count, mean, maximum = log.summary()
    print(f'{log.name}: n={count}, mean={mean:.1f}, max={maximum:.1f}')

# Selected regression checks; keep assertions enabled.
assert first.snapshot() == (20, 22, 24)
assert second.snapshot() == (17, 21)
assert first._values is not second._values
