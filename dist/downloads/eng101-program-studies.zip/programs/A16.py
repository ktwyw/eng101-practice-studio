# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursion compared with iteration
# Source: Mock A · A16

def factorial_recursive(n):
    if n == 0:
        return 1
    return n * factorial_recursive(n - 1)

def factorial_iterative(n):
    result = 1
    for k in range(1, n + 1):
        result *= k
    return result

print(factorial_recursive(4))
print(factorial_iterative(4))
print(factorial_recursive(0), factorial_iterative(0))
