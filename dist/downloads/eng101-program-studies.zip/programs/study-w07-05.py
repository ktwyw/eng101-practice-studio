# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# Ordered output is not enough for a sorting test
# Source: Week 7 · Original program study

from collections import Counter

original = [3, 1, 3, 2]
candidate = [1, 2, 3]
ordered = all(candidate[i] <= candidate[i + 1] for i in range(len(candidate) - 1))
same_entries = Counter(candidate) == Counter(original)
print('Ordered:', ordered)
print('Same entries:', same_entries)
print('Valid sort:', ordered and same_entries)

# Selected regression checks; keep assertions enabled.
assert Counter(sorted(original)) == Counter(original)
assert sum([0, 2, 3, 4]) == sum(original)
