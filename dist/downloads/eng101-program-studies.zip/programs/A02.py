# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Arithmetic and precedence
# Source: Mock A · A02

a = 17
b = 5
print(a + b * 2)
print((a + b) * 2)
print(a / b, a // b, a % b)
print(2 ** 3 ** 2)
print(-a // b)
