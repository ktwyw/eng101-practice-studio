# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Maintaining sorted order across insertions
# Source: Week 12 · Original program study

from bisect import bisect_left, bisect_right, insort

values = [2, 5, 5, 9]
print('Before equal values:', bisect_left(values, 5))
print('After equal values:', bisect_right(values, 5))
insort(values, 5)
insort(values, 1)
print(values)

# Selected regression checks; keep assertions enabled.
assert values == sorted(values)
assert values.count(5) == 3
