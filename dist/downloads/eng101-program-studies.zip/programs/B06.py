# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# While loops with skip and stop
# Source: Mock B · B06

n = 9
total = 0
while n > 0:
    n -= 1
    if n % 3 == 0:
        continue
    total += n
    if total >= 20:
        break
print(n, total)
