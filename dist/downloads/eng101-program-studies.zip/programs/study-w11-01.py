# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Reusing the subtotal of a moving window
# Source: Week 11 · Original program study

values = [1, 2, 3, 4, 5, 6, 7]
width = 3
totals = [sum(values[:width])]
updates = width
for index in range(width, len(values)):
    totals.append(totals[-1] - values[index - width] + values[index])
    updates += 2
print(totals)
print('Direct entries visited:', (len(values) - width + 1) * width)
print('Running arithmetic updates:', updates)

# Selected regression checks; keep assertions enabled.
assert totals == [sum(values[i:i + width]) for i in range(len(values) - width + 1)]
