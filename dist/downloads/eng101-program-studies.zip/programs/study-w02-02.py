# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# A small multiplication table with a row accumulator
# Source: Week 2 · Original program study

for row in range(1, 4):
    line = ''
    for column in range(1, 4):
        line += f'{row * column:3}'
    print(line)
