# ENG 101 Program study - Week 4
# Instructor: Prof. Yanwei Wang
# Boolean functions and early returns
# Source: Mock A · A12

def within_limit(value, lower, upper):
    return lower <= value <= upper

def classify(value):
    if within_limit(value, 10, 20):
        return "Accept"
    return "Reject"

accepted = 0
for reading in range(8, 25, 4):
    if classify(reading) == "Accept":
        accepted += 1
print(accepted)
print(classify(20), classify(21))
