# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Ranking deviations with an explicit tie rule
# Source: Week 12 · Original program study

reference = 10
records = [('S1', 12), ('S2', 9), ('S3', 8), ('S4', 11)]
ranked = sorted(enumerate(records), key=lambda pair: (abs(pair[1][1] - reference), pair[0]))
print([record[0] for index, record in ranked])
print([abs(record[1] - reference) for index, record in ranked])

# Selected regression checks; keep assertions enabled.
assert [record for _, record in ranked][0] == ('S2', 9)
