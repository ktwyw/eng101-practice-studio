# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# A test that detects unintended mutation
# Source: Week 7 · Original program study

def middle_value(values):
    ordered = sorted(values)
    return ordered[len(ordered) // 2]

data = [7, 1, 5]
before = data.copy()
result = middle_value(data)
print('Middle:', result)
print('Input unchanged:', data == before)
print('Distinct snapshot:', before is not data)

# Selected regression checks; keep assertions enabled.
assert middle_value([4]) == 4
assert data == [7, 1, 5]
