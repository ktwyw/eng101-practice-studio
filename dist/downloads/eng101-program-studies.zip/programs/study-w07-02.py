# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# Relative and absolute tolerances near zero
# Source: Week 7 · Original program study

import math

print(math.isclose(1e-12, 0.0, rel_tol=1e-6))
print(math.isclose(1e-12, 0.0, rel_tol=1e-6, abs_tol=1e-11))
print(math.isclose(1000.0001, 1000.0, rel_tol=1e-6))

# Selected regression checks; keep assertions enabled.
assert not math.isclose(1e-8, 0, abs_tol=1e-11)
assert math.isclose(-1e-12, 0, abs_tol=1e-11)
