# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# Integer guess and check
# Source: Mock A · A08

target = 50
guess = 0
checks = 0
while guess * guess < target:
    guess += 1
    checks += 1
if guess * guess == target:
    print("Exact", guess)
else:
    print("Not exact", guess)
print(checks)
