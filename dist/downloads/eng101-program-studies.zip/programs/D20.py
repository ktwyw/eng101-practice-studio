# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Grouping samples in dictionary lists
# Source: Mock D · D20

samples = [("Cu", 2), ("Al", 3), ("Cu", 5), ("Fe", 1), ("Al", 4)]
groups = {}
for metal, mass in samples:
    if metal not in groups:
        groups[metal] = []
    groups[metal].append(mass)
print(groups["Cu"])
print(list(groups.keys()))
print(sum(groups["Al"]))
print(len(groups), len(samples))
