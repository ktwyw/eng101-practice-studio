# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# A time-weighted mean does not bridge missing intervals
# Source: Week 14 · Original program study

measurements = [(0, 2), (1, None), (2, 4), (3, 6)]
integral = 0.0
covered_s = 0.0
for (left_t, left), (right_t, right) in zip(measurements, measurements[1:]):
    if left is None or right is None:
        continue
    duration = right_t - left_t
    integral += (left + right) / 2 * duration
    covered_s += duration
total_s = measurements[-1][0] - measurements[0][0]
mean = integral / covered_s if covered_s else None
print(f'Integrated reading: {integral:.1f} value*s')
print(f'Coverage: {covered_s:.1f} / {total_s:.1f} s')
print('Covered-interval mean:', mean)

# Selected regression checks; keep assertions enabled.
assert covered_s == 1.0
assert integral == 5.0
assert mean == 5.0
