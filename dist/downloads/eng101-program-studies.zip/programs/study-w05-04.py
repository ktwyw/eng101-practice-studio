# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Replacing a service-log interval
# Source: Week 5 · Original program study

events = ['start', 'warm', 'check', 'hold', 'stop']
removed = events[1:4]
events[1:4] = ['ready', 'run']
events[2:2] = ['sample']
print('Removed:', removed)
print('Current:', events)
print('Count:', len(events))

# Selected regression checks; keep assertions enabled.
assert removed == ['warm', 'check', 'hold']
assert events[-1] == 'stop'
