# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Fibonacci and base cases
# Source: Week 6 · Example 04

# ENG 101 - Programming for Engineers | Week 6 | Example 04
# Fibonacci: two base cases and repeated work
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 34-41; Notes Sections 2.1-2.4 (pp. 22-25).
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

def fibonacci(n):
    # WEEK 6 SLIDE CONVENTION: F(0) = F(1) = 1.
    # Mock Test A, Program 17 instead starts with 0 and 1.
    if n == 0 or n == 1:
        return 1
    return fibonacci(n - 1) + fibonacci(n - 2)


def fibonacci_iterative(n):
    if n == 0 or n == 1:
        return 1
    previous = 1
    current = 1
    for index in range(2, n + 1):
        # Both right-hand expressions use the OLD values.
        previous, current = current, previous + current
    return current


# Independently written values for the lecture's recurrence.
expected_values = [1, 1, 2, 3, 5, 8, 13]
print("n | recursive | iterative | expected | passed")
for n in range(len(expected_values)):
    recursive_value = fibonacci(n)
    iterative_value = fibonacci_iterative(n)
    expected = expected_values[n]
    passed = (recursive_value == expected
              and iterative_value == expected)
    print(n, recursive_value, iterative_value, expected, passed,
          sep=" | ")
