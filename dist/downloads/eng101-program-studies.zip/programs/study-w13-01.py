# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# Floor division compared with truncation toward zero
# Source: Week 13 · Original program study

def truncated_divmod(a, b):
    quotient = abs(a) // abs(b)
    if (a < 0) != (b < 0):
        quotient = -quotient
    return quotient, a - quotient * b

a, b = -7, 2
print('Python floor:', a // b, a % b)
print('Truncation model:', *truncated_divmod(a, b))

# Selected regression checks; keep assertions enabled.
assert truncated_divmod(7, -2) == (-3, 1)
assert truncated_divmod(-7, -2) == (3, -1)
