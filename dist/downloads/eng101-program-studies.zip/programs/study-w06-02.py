# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Removing obsolete keys through a snapshot
# Source: Week 6 · Original program study

stock = {'A': 0, 'B': 3, 'C': 0, 'D': 2}
removed = []
for key in list(stock):
    if stock[key] == 0:
        removed.append(key)
        del stock[key]
print('Removed:', removed)
print('Remaining:', stock)
print('Total:', sum(stock.values()))

# Selected regression checks; keep assertions enabled.
assert stock == {'B': 3, 'D': 2}
assert removed == ['A', 'C']
