# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Calculating a weighted practice score
# Source: Mock C · C01

quiz = 14
lab = 19
score = (quiz + 3 * lab) / 4
whole = int(score)
passed = score >= 18
print(score, whole)
print(passed)
