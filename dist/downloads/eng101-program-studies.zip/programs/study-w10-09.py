# ENG 101 Program study - Week 10
# Instructor: Prof. Yanwei Wang
# Doubling until a threshold is reached
# Source: Week 10 · Original program study

limit = 10
capacity = 1
growths = 0
visited = [capacity]
while capacity < limit:
    capacity *= 2
    growths += 1
    visited.append(capacity)
print(visited)
print('Growths:', growths)
print('Final capacity:', capacity)

# Selected regression checks; keep assertions enabled.
assert capacity >= limit
assert capacity // 2 < limit
