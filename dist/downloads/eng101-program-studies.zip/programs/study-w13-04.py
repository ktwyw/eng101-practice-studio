# ENG 101 Program study - Week 13
# Instructor: Prof. Yanwei Wang
# Elementwise products and a dot product are different results
# Source: Week 13 · Original program study

left = [2, 3, 4]
right = [5, 6, 7]
products = [a * b for a, b in zip(left, right, strict=True)]
dot_product = sum(products)
print('Elementwise:', products)
print('Dot product:', dot_product)
print('Entries:', len(products))

# Selected regression checks; keep assertions enabled.
assert dot_product == 2 * 5 + 3 * 6 + 4 * 7
