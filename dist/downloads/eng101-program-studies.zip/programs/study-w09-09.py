# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# A public method protects a bounded balance
# Source: Week 9 · Original program study

class Balance:
    def __init__(self, initial):
        if initial < 0:
            raise ValueError('negative initial balance')
        self._amount = initial

    def remove(self, amount):
        if amount < 0 or amount > self._amount:
            raise ValueError('invalid removal')
        self._amount -= amount

    @property
    def amount(self):
        return self._amount

balance = Balance(10)
balance.remove(4)
try:
    balance.remove(9)
except ValueError:
    print('Removal rejected')
print(balance.amount)

# Selected regression checks; keep assertions enabled.
balance.remove(6)
assert balance.amount == 0
