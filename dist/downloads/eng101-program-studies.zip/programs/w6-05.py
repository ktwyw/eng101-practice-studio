# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Palindromes and string cleaning
# Source: Week 6 · Example 05

# ENG 101 - Programming for Engineers | Week 6 | Example 05
# String recursion: palindrome testing and cleaning
# Instructor: Prof. Yanwei Wang
# Source: Slides PDF pp. 43-50 and 56-57; Notes Sections 2.6-2.9 and 2.12.
# Teaching adaptation: see the source map in the companion guide.
# Run this file independently; no external packages are required.

def is_palindrome(text):
    # Check BOTH terminal lengths before indexing the string.
    if len(text) <= 1:
        return True
    # A mismatch skips the recursive call because and short-circuits.
    return (text[0] == text[-1]
            and is_palindrome(text[1:-1]))


def letters_only_lower(text):
    cleaned = ""
    for character in text.lower():
        if character.isalpha():
            cleaned += character
    return cleaned


def is_phrase_palindrome(text):
    cleaned = letters_only_lower(text)
    return is_palindrome(cleaned)


tests = ["", "x", "abba", "level", "Level", "sensor",
         "Never odd or even", "123!"]
print("INPUT -> EXACT TEST | PHRASE TEST")
for text in tests:
    print(repr(text), "->", is_palindrome(text), "|",
          is_phrase_palindrome(text))

phrase = "Never odd or even"
print("Cleaned phrase:", letters_only_lower(phrase))
print("Original phrase:", phrase)
