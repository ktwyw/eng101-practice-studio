# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# A FIFO queue behind a small interface
# Source: Week 8 · Original program study

from collections import deque

class SampleQueue:
    def __init__(self):
        self._items = deque()

    def add(self, label):
        self._items.append(label)

    def take(self):
        return self._items.popleft()

    def pending(self):
        return tuple(self._items)

queue = SampleQueue()
queue.add('S1')
queue.add('S2')
print(queue.take())
queue.add('S3')
print(queue.pending())

# Selected regression checks; keep assertions enabled.
assert queue.take() == 'S2'
assert queue.pending() == ('S3',)
