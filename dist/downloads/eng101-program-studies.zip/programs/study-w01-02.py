# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Electricity use and a displayed bill
# Source: Week 1 · Original program study

power_w = 1200
duration_h = 3
price_per_kwh = 0.15
energy_kwh = power_w / 1000 * duration_h
cost = energy_kwh * price_per_kwh
print(f'Energy: {energy_kwh:.2f} kWh')
print(f'Cost: {cost:.2f} currency units')
