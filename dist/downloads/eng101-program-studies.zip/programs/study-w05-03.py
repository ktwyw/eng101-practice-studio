# ENG 101 Program study - Week 5
# Instructor: Prof. Yanwei Wang
# Copying each row of a measurement matrix
# Source: Week 5 · Original program study

original = [[1, 2], [3, 4]]
outer_copy = original.copy()
row_copies = [row.copy() for row in original]
outer_copy[0][1] = 9
row_copies[1][0] = 8
print(original)
print(outer_copy)
print(row_copies)

# Selected regression checks; keep assertions enabled.
assert outer_copy is not original
assert outer_copy[0] is original[0]
assert row_copies[0] is not original[0]
