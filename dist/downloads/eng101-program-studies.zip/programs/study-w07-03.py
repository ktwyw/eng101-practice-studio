# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# A boundary fixture table for classification
# Source: Week 7 · Original program study

def band(value):
    if value < 10:
        return 'low'
    if value <= 20:
        return 'middle'
    return 'high'

fixtures = [(9, 'low'), (10, 'middle'), (20, 'middle'), (21, 'high')]
for value, expected in fixtures:
    actual = band(value)
    print(value, actual, actual == expected)

# Selected regression checks; keep assertions enabled.
assert all(band(x) == expected for x, expected in fixtures)
