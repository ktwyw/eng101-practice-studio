# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# A controller with two switching thresholds
# Source: Week 2 · Original program study

on = False
for temperature in [19, 22, 21, 18, 20]:
    if temperature >= 22:
        on = True
    elif temperature <= 19:
        on = False
    print(temperature, 'ON' if on else 'OFF')
