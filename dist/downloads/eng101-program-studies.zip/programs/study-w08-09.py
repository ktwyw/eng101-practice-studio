# ENG 101 Program study - Week 8
# Instructor: Prof. Yanwei Wang
# Vector addition returns a new object
# Source: Week 8 · Original program study

class Vector:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)

    def __repr__(self):
        return f'Vector({self.x}, {self.y})'

left, right = Vector(1, 2), Vector(3, -1)
result = left + right
print(result)
print(left, right)
print(result is left)

# Selected regression checks; keep assertions enabled.
assert (left + right).x == 4
assert left.y == 2 and right.y == -1
