# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# A lower bound also works when the target is absent
# Source: Week 12 · Original program study

def lower_bound(values, target):
    low, high = 0, len(values)
    while low < high:
        middle = (low + high) // 2
        if values[middle] < target:
            low = middle + 1
        else:
            high = middle
    return low

data = [2, 4, 4, 7]
for target in [1, 4, 6, 9]:
    index = lower_bound(data, target)
    present = index < len(data) and data[index] == target
    print(target, index, present)

# Selected regression checks; keep assertions enabled.
assert lower_bound([], 2) == 0
assert lower_bound([2, 2], 2) == 0
