# ENG 101 Program study - Week 1
# Instructor: Prof. Yanwei Wang
# Negative values and operator precedence
# Source: Mock C · C02

a = -7
b = 4
quotient = a // b
remainder = a % b
rebuilt = quotient * b + remainder
print(quotient, remainder)
print(rebuilt)
print(-2 ** 2, (-2) ** 2)
print(a / b)
