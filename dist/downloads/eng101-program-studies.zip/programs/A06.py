# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# While loops and a stopping digit
# Source: Mock A · A06

digits = "314052"
index = 0
total = 0
while index < len(digits):
    digit = int(digits[index])
    index += 1
    if digit == 0:
        break
    total += digit
print(total, index)
print(digits[index:])
