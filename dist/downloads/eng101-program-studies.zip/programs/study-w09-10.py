# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# Readable text and a debugging representation
# Source: Week 9 · Original program study

class Sample:
    def __init__(self, label, value):
        self.label, self.value = label, value

    def __str__(self):
        return f'{self.label}: {self.value} V'

    def __repr__(self):
        return f'Sample({self.label!r}, {self.value!r})'

sample = Sample('S1', 12)
print(sample)
print(repr(sample))
print([sample])

# Selected regression checks; keep assertions enabled.
assert str(sample) == 'S1: 12 V'
assert repr(sample).startswith('Sample(')
