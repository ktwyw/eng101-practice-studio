# ENG 101 Program study - Week 3
# Instructor: Prof. Yanwei Wang
# A weighted check digit for a serial number
# Source: Week 3 · Original program study

serial = '2041'
weighted_total = 0
for position, digit in enumerate(serial, start=1):
    weighted_total += position * int(digit)
check_digit = weighted_total % 10
print('Weighted total:', weighted_total)
print('Identifier:', serial + '-' + str(check_digit))
