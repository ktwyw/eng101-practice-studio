# ENG 101 Program study - Week 2
# Instructor: Prof. Yanwei Wang
# Counting rises in a digit sequence
# Source: Mock C · C05

digits = "24153"
rises = 0
largest_jump = 0
for i in range(1, len(digits)):
    jump = int(digits[i]) - int(digits[i - 1])
    if jump > 0:
        rises += 1
    if jump > largest_jump:
        largest_jump = jump
print(rises, largest_jump)
print(i)
