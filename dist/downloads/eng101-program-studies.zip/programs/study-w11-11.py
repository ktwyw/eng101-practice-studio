# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# Stable deduplication with a membership index
# Source: Week 11 · Original program study

labels = ['Cu', 'Al', 'Cu', 'Fe', 'Al']
seen = set()
unique = []
duplicates = 0
for label in labels:
    if label in seen:
        duplicates += 1
    else:
        seen.add(label)
        unique.append(label)
print(unique)
print('Repeated occurrences:', duplicates)

# Selected regression checks; keep assertions enabled.
assert len(unique) + duplicates == len(labels)
assert set(unique) == set(labels)
