# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Choosing a cheapest feasible candidate
# Source: Week 12 · Original program study

def choose(candidates, required_capacity):
    feasible = [row for row in candidates if row['capacity'] >= required_capacity]
    if not feasible:
        return None
    return min(feasible, key=lambda row: (row['cost'], row['name']))['name']

candidates = [
    {'name': 'A', 'capacity': 4, 'cost': 3},
    {'name': 'B', 'capacity': 8, 'cost': 6},
    {'name': 'C', 'capacity': 9, 'cost': 6},
]
print(choose(candidates, 7))
print(choose(candidates, 10))

# Selected regression checks; keep assertions enabled.
assert choose(candidates, 4) == 'A'
assert choose([], 1) is None
