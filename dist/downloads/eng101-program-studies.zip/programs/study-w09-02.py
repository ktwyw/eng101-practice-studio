# ENG 101 Program study - Week 9
# Instructor: Prof. Yanwei Wang
# An override extends inherited initialization and behavior
# Source: Week 9 · Original program study

class Sensor:
    def __init__(self, raw):
        self.raw = raw

    def read(self):
        return self.raw

class OffsetSensor(Sensor):
    def __init__(self, raw, offset):
        super().__init__(raw)
        self.offset = offset

    def read(self):
        return super().read() + self.offset

sensor = OffsetSensor(8, 2)
print(sensor.read())
print(sensor.raw)
print(isinstance(sensor, Sensor))

# Selected regression checks; keep assertions enabled.
assert OffsetSensor(0, 3).read() == 3
assert sensor.raw == 8
