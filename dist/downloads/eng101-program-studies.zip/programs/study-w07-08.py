# ENG 101 Program study - Week 7
# Instructor: Prof. Yanwei Wang
# Tracing try, except, else and finally
# Source: Week 7 · Original program study

def trace(denominator):
    events = []
    try:
        result = 8 / denominator
    except ZeroDivisionError:
        events.append('handled')
    else:
        events.append(f'result={result:.1f}')
    finally:
        events.append('cleanup')
    return events

print(trace(2))
print(trace(0))

# Selected regression checks; keep assertions enabled.
assert trace(4) == ['result=2.0', 'cleanup']
assert trace(0)[-1] == 'cleanup'
