# ENG 101 Program study - Week 11
# Instructor: Prof. Yanwei Wang
# A cache key includes every numeric parameter
# Source: Week 11 · Original program study

cache = {}

def scaled(value, factor):
    key = (value, factor)
    if key not in cache:
        cache[key] = value * factor
    return cache[key]

print([scaled(2, 3), scaled(2, 4), scaled(2, 3)])
print('Cache entries:', len(cache))
print(sorted(cache))

# Selected regression checks; keep assertions enabled.
assert scaled(3, 4) == 12
assert scaled(3, 5) == 15
