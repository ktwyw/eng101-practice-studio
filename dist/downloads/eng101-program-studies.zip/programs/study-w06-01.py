# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Finding leaves with their nested index paths
# Source: Week 6 · Original program study

def leaves(values, path=()):
    result = []
    for index, value in enumerate(values):
        current = path + (index,)
        if isinstance(value, list):
            result.extend(leaves(value, current))
        else:
            result.append((current, value))
    return result

print(leaves([4, [7, [9]], []]))

# Selected regression checks; keep assertions enabled.
assert leaves([]) == []
assert leaves([[2]]) == [((0, 0), 2)]
