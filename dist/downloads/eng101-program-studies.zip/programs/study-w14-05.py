# ENG 101 Program study - Week 14
# Instructor: Prof. Yanwei Wang
# An Euler cooling model stops at a sampled threshold
# Source: Week 14 · Original program study

temperature = 28.0
ambient = 20.0
rate = 1.0
step_h = 0.5
threshold = 21.0
history = [temperature]
steps = 0
while temperature > threshold and steps < 20:
    temperature += -rate * (temperature - ambient) * step_h
    history.append(temperature)
    steps += 1
print(history)
print('Steps:', steps)
print(f'Sampled stopping time: {steps * step_h:.2f} h')
print('Threshold reached:', temperature <= threshold)

# Selected regression checks; keep assertions enabled.
assert steps == 3
assert all(history[i + 1] <= history[i] for i in range(len(history) - 1))
assert history[-1] >= ambient
