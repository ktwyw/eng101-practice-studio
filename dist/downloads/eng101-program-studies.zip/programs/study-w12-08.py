# ENG 101 Program study - Week 12
# Instructor: Prof. Yanwei Wang
# Stable sorting can be composed in two passes
# Source: Week 12 · Original program study

records = [('Z', 2), ('B', 1), ('A', 2), ('C', 1)]
by_name = sorted(records, key=lambda row: row[0])
by_priority = sorted(by_name, key=lambda row: row[1])
print(by_name)
print(by_priority)
print(by_priority == sorted(records, key=lambda row: (row[1], row[0])))

# Selected regression checks; keep assertions enabled.
assert by_priority[0] == ('B', 1)
assert by_priority[-1] == ('Z', 2)
