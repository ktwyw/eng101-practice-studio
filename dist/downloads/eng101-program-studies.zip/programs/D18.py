# ENG 101 Program study - Week 6
# Instructor: Prof. Yanwei Wang
# Recursively compressing repeated characters
# Source: Mock D · D18

def compress(text):
    if len(text) < 2:
        return text
    tail = compress(text[1:])
    if text[0] == tail[0]:
        return tail
    return text[0] + tail

word = "AAABBCCA"
print(compress(word))
print(word)
print(compress(""))
