ENG 101 Program Studies
Instructor: Prof. Yanwei Wang

200 complete course programs: the earlier 62 Mock A-D programs and ten Week 6
teaching examples, plus 128 original studies covering Weeks 1-14. The separate
400 Reading examples are not duplicated in this archive.

Run one file at a time with Python 3.10 or later. The course programs use only
the standard library. Complete printed reference outputs are supplied in the
outputs folder and expected-output.json. Leading spaces can matter.

Predict the output before running. Read the explanation and modification prompt
in catalog.csv, then change one input and predict again. Where supplied, selected
regression assertions follow the worked program. Assertions should be enabled.
Earlier Mock A-D programs have related MCQs and explanations on the website;
catalog.csv includes their question IDs and a direct link to each program.

Week 10-11 operation counts use their stated classroom cost models; they are not
elapsed-time benchmarks. Week 13 studies execute Python demonstrations of
language differences, not native MATLAB, C++ or Java code. Engineering data and
models are illustrative and are not certified equipment or design guidance.

These are ungraded practice activities. Website progress stays in the current
browser tab; running these files does not submit work or update Moodle grades.
